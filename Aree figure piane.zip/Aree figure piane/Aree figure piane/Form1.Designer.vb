﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form esegue l'override del metodo Dispose per pulire l'elenco dei componenti.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Richiesto da Progettazione Windows Form
    Private components As System.ComponentModel.IContainer

    'NOTA: la procedura che segue è richiesta da Progettazione Windows Form
    'Può essere modificata in Progettazione Windows Form.  
    'Non modificarla nell'editor del codice.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.chkrettangolo = New System.Windows.Forms.CheckBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.lbldiagonale1 = New System.Windows.Forms.Label()
        Me.lbldiagonale = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lblperimetro1 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lblarea = New System.Windows.Forms.Label()
        Me.chkquadrato = New System.Windows.Forms.CheckBox()
        Me.btncancella = New System.Windows.Forms.Button()
        Me.lblperimetro = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtlato2 = New System.Windows.Forms.TextBox()
        Me.lblrisultato = New System.Windows.Forms.Label()
        Me.txtlato1 = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.lblarea1 = New System.Windows.Forms.Label()
        Me.lblperimetro2 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.txtlato4 = New System.Windows.Forms.TextBox()
        Me.txtlato3 = New System.Windows.Forms.TextBox()
        Me.txtaltezza = New System.Windows.Forms.TextBox()
        Me.txtbase = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.chkscaleno = New System.Windows.Forms.CheckBox()
        Me.chkisoscele = New System.Windows.Forms.CheckBox()
        Me.chkequilatero = New System.Windows.Forms.CheckBox()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.btnstampa = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.lblarea2 = New System.Windows.Forms.Label()
        Me.lblperimetro3 = New System.Windows.Forms.Label()
        Me.lbldiagonale2 = New System.Windows.Forms.Label()
        Me.txtlatoobliquo2 = New System.Windows.Forms.TextBox()
        Me.txtlatoobliquo1 = New System.Windows.Forms.TextBox()
        Me.txttaltezza = New System.Windows.Forms.TextBox()
        Me.txtbaseminore = New System.Windows.Forms.TextBox()
        Me.txtbasemaggiore = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.chktrettangolo = New System.Windows.Forms.CheckBox()
        Me.chktisoscele = New System.Windows.Forms.CheckBox()
        Me.chktrapezio = New System.Windows.Forms.CheckBox()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.lblperimetropoligono = New System.Windows.Forms.Label()
        Me.lblareapoligono = New System.Windows.Forms.Label()
        Me.lbldecagono = New System.Windows.Forms.Label()
        Me.lblennagono = New System.Windows.Forms.Label()
        Me.lblottagono = New System.Windows.Forms.Label()
        Me.lblettagono = New System.Windows.Forms.Label()
        Me.lblesagono = New System.Windows.Forms.Label()
        Me.lblpentagono = New System.Windows.Forms.Label()
        Me.lblquadrato = New System.Windows.Forms.Label()
        Me.lbltriangolo = New System.Windows.Forms.Label()
        Me.chkdecagono = New System.Windows.Forms.CheckBox()
        Me.chkennagono = New System.Windows.Forms.CheckBox()
        Me.chkottagono = New System.Windows.Forms.CheckBox()
        Me.chkettagono = New System.Windows.Forms.CheckBox()
        Me.chkesagono = New System.Windows.Forms.CheckBox()
        Me.chkpentagono = New System.Windows.Forms.CheckBox()
        Me.chkquadrato1 = New System.Windows.Forms.CheckBox()
        Me.chktriangolo = New System.Windows.Forms.CheckBox()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.txtnumerolati = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.txtlatopoligono = New System.Windows.Forms.TextBox()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.lblperimetrocorona = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.lblcorona = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.lblsettore = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.btncancelladati = New System.Windows.Forms.Button()
        Me.lbllunghezzaarco = New System.Windows.Forms.Label()
        Me.lblareacirconferenza = New System.Windows.Forms.Label()
        Me.lblcirconferenza = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.txtraggioesterno = New System.Windows.Forms.TextBox()
        Me.txtraggiointerno = New System.Windows.Forms.TextBox()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.txtarco = New System.Windows.Forms.TextBox()
        Me.txtangolo = New System.Windows.Forms.TextBox()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.chkcorona = New System.Windows.Forms.CheckBox()
        Me.chksettorecircolare = New System.Windows.Forms.CheckBox()
        Me.chkcirconferenza = New System.Windows.Forms.CheckBox()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.txtraggio = New System.Windows.Forms.TextBox()
        Me.btncerchio = New System.Windows.Forms.Button()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.CheckBox2 = New System.Windows.Forms.CheckBox()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.lblperimetroellisse = New System.Windows.Forms.Label()
        Me.lblareaellisse = New System.Windows.Forms.Label()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.txtsemiassemaggiore = New System.Windows.Forms.TextBox()
        Me.txtsemiasseminore = New System.Windows.Forms.TextBox()
        Me.lblperimetrorombo = New System.Windows.Forms.Label()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.lblarearombo = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.lbllato = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.txtdiagonale2 = New System.Windows.Forms.TextBox()
        Me.txtdiagonale1 = New System.Windows.Forms.TextBox()
        Me.chkellisse = New System.Windows.Forms.CheckBox()
        Me.chkrombo = New System.Windows.Forms.CheckBox()
        Me.PrintForm2 = New Microsoft.VisualBasic.PowerPacks.Printing.PrintForm(Me.components)
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel1.Controls.Add(Me.chkrettangolo)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.lbldiagonale1)
        Me.Panel1.Controls.Add(Me.lbldiagonale)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.lblperimetro1)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.lblarea)
        Me.Panel1.Controls.Add(Me.chkquadrato)
        Me.Panel1.Controls.Add(Me.btncancella)
        Me.Panel1.Controls.Add(Me.lblperimetro)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.txtlato2)
        Me.Panel1.Controls.Add(Me.lblrisultato)
        Me.Panel1.Controls.Add(Me.txtlato1)
        Me.Panel1.Controls.Add(Me.Button1)
        Me.Panel1.Location = New System.Drawing.Point(14, 11)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(289, 277)
        Me.Panel1.TabIndex = 0
        '
        'chkrettangolo
        '
        Me.chkrettangolo.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.chkrettangolo.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkrettangolo.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.chkrettangolo.Location = New System.Drawing.Point(35, 53)
        Me.chkrettangolo.Name = "chkrettangolo"
        Me.chkrettangolo.Size = New System.Drawing.Size(94, 17)
        Me.chkrettangolo.TabIndex = 19
        Me.chkrettangolo.Text = "Rettangolo"
        Me.chkrettangolo.UseVisualStyleBackColor = False
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Red
        Me.Label7.Location = New System.Drawing.Point(136, 183)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(21, 21)
        Me.Label7.TabIndex = 18
        Me.Label7.Text = "D"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbldiagonale1
        '
        Me.lbldiagonale1.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.lbldiagonale1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbldiagonale1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbldiagonale1.ForeColor = System.Drawing.Color.Red
        Me.lbldiagonale1.Location = New System.Drawing.Point(177, 183)
        Me.lbldiagonale1.Name = "lbldiagonale1"
        Me.lbldiagonale1.Size = New System.Drawing.Size(86, 21)
        Me.lbldiagonale1.TabIndex = 17
        Me.lbldiagonale1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbldiagonale
        '
        Me.lbldiagonale.BackColor = System.Drawing.Color.Yellow
        Me.lbldiagonale.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbldiagonale.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbldiagonale.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lbldiagonale.Location = New System.Drawing.Point(177, 155)
        Me.lbldiagonale.Name = "lbldiagonale"
        Me.lbldiagonale.Size = New System.Drawing.Size(85, 21)
        Me.lbldiagonale.TabIndex = 16
        Me.lbldiagonale.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.Yellow
        Me.Label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label4.Location = New System.Drawing.Point(136, 155)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(21, 21)
        Me.Label4.TabIndex = 15
        Me.Label4.Text = "D"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblperimetro1
        '
        Me.lblperimetro1.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.lblperimetro1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblperimetro1.ForeColor = System.Drawing.Color.Red
        Me.lblperimetro1.Location = New System.Drawing.Point(177, 243)
        Me.lblperimetro1.Name = "lblperimetro1"
        Me.lblperimetro1.Size = New System.Drawing.Size(86, 17)
        Me.lblperimetro1.TabIndex = 14
        Me.lblperimetro1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Red
        Me.Label6.Location = New System.Drawing.Point(36, 243)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(93, 17)
        Me.Label6.TabIndex = 12
        Me.Label6.Text = "Perimetro"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Red
        Me.Label5.Location = New System.Drawing.Point(36, 215)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(93, 17)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "AREA"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblarea
        '
        Me.lblarea.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.lblarea.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblarea.ForeColor = System.Drawing.Color.Red
        Me.lblarea.Location = New System.Drawing.Point(177, 214)
        Me.lblarea.Name = "lblarea"
        Me.lblarea.Size = New System.Drawing.Size(86, 18)
        Me.lblarea.TabIndex = 10
        Me.lblarea.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'chkquadrato
        '
        Me.chkquadrato.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.chkquadrato.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkquadrato.ForeColor = System.Drawing.Color.Red
        Me.chkquadrato.Location = New System.Drawing.Point(35, 183)
        Me.chkquadrato.Name = "chkquadrato"
        Me.chkquadrato.Size = New System.Drawing.Size(94, 21)
        Me.chkquadrato.TabIndex = 9
        Me.chkquadrato.Text = "Quadrato"
        Me.chkquadrato.UseVisualStyleBackColor = False
        '
        'btncancella
        '
        Me.btncancella.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btncancella.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncancella.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btncancella.Location = New System.Drawing.Point(35, 154)
        Me.btncancella.Name = "btncancella"
        Me.btncancella.Size = New System.Drawing.Size(94, 22)
        Me.btncancella.TabIndex = 8
        Me.btncancella.Text = "&CANCELLA"
        Me.btncancella.UseVisualStyleBackColor = False
        '
        'lblperimetro
        '
        Me.lblperimetro.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.lblperimetro.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblperimetro.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblperimetro.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblperimetro.Location = New System.Drawing.Point(175, 127)
        Me.lblperimetro.Name = "lblperimetro"
        Me.lblperimetro.Size = New System.Drawing.Size(86, 22)
        Me.lblperimetro.TabIndex = 7
        Me.lblperimetro.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label3.Location = New System.Drawing.Point(175, 103)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(89, 17)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Perimetro"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.Yellow
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(175, 53)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(86, 17)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "AREA"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(36, 78)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(93, 17)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "DATI:  - LATI"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtlato2
        '
        Me.txtlato2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.txtlato2.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtlato2.ForeColor = System.Drawing.Color.Red
        Me.txtlato2.Location = New System.Drawing.Point(35, 131)
        Me.txtlato2.Name = "txtlato2"
        Me.txtlato2.Size = New System.Drawing.Size(94, 18)
        Me.txtlato2.TabIndex = 3
        '
        'lblrisultato
        '
        Me.lblrisultato.BackColor = System.Drawing.Color.Yellow
        Me.lblrisultato.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblrisultato.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblrisultato.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblrisultato.Location = New System.Drawing.Point(175, 78)
        Me.lblrisultato.Name = "lblrisultato"
        Me.lblrisultato.Size = New System.Drawing.Size(87, 18)
        Me.lblrisultato.TabIndex = 2
        Me.lblrisultato.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtlato1
        '
        Me.txtlato1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.txtlato1.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtlato1.ForeColor = System.Drawing.Color.Red
        Me.txtlato1.Location = New System.Drawing.Point(35, 103)
        Me.txtlato1.Name = "txtlato1"
        Me.txtlato1.Size = New System.Drawing.Size(94, 18)
        Me.txtlato1.TabIndex = 1
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Button1.Location = New System.Drawing.Point(35, 18)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(229, 22)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "RETTANGOLO - QUADRATO"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel2.Controls.Add(Me.Button3)
        Me.Panel2.Controls.Add(Me.lblarea1)
        Me.Panel2.Controls.Add(Me.lblperimetro2)
        Me.Panel2.Controls.Add(Me.Label13)
        Me.Panel2.Controls.Add(Me.Label8)
        Me.Panel2.Controls.Add(Me.Button2)
        Me.Panel2.Controls.Add(Me.txtlato4)
        Me.Panel2.Controls.Add(Me.txtlato3)
        Me.Panel2.Controls.Add(Me.txtaltezza)
        Me.Panel2.Controls.Add(Me.txtbase)
        Me.Panel2.Controls.Add(Me.Label12)
        Me.Panel2.Controls.Add(Me.Label11)
        Me.Panel2.Controls.Add(Me.Label10)
        Me.Panel2.Controls.Add(Me.Label9)
        Me.Panel2.Controls.Add(Me.chkscaleno)
        Me.Panel2.Controls.Add(Me.chkisoscele)
        Me.Panel2.Controls.Add(Me.chkequilatero)
        Me.Panel2.Location = New System.Drawing.Point(310, 11)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(275, 277)
        Me.Panel2.TabIndex = 1
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.Yellow
        Me.Button3.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.ForeColor = System.Drawing.Color.Blue
        Me.Button3.Location = New System.Drawing.Point(19, 232)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(79, 30)
        Me.Button3.TabIndex = 17
        Me.Button3.Text = "CANCELLA"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'lblarea1
        '
        Me.lblarea1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.lblarea1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblarea1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblarea1.Location = New System.Drawing.Point(107, 212)
        Me.lblarea1.Name = "lblarea1"
        Me.lblarea1.Size = New System.Drawing.Size(83, 17)
        Me.lblarea1.TabIndex = 16
        Me.lblarea1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblperimetro2
        '
        Me.lblperimetro2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.lblperimetro2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblperimetro2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblperimetro2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblperimetro2.Location = New System.Drawing.Point(18, 212)
        Me.lblperimetro2.Name = "lblperimetro2"
        Me.lblperimetro2.Size = New System.Drawing.Size(78, 17)
        Me.lblperimetro2.TabIndex = 15
        Me.lblperimetro2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label13
        '
        Me.Label13.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label13.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label13.Location = New System.Drawing.Point(107, 189)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(83, 14)
        Me.Label13.TabIndex = 14
        Me.Label13.Text = "AREA"
        Me.Label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label8.Location = New System.Drawing.Point(18, 189)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(78, 14)
        Me.Label8.TabIndex = 13
        Me.Label8.Text = "PERIMETRO"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.Yellow
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Button2.Location = New System.Drawing.Point(22, 18)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(227, 23)
        Me.Button2.TabIndex = 12
        Me.Button2.Text = "TRIANGOLI"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'txtlato4
        '
        Me.txtlato4.BackColor = System.Drawing.Color.Yellow
        Me.txtlato4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtlato4.Location = New System.Drawing.Point(108, 160)
        Me.txtlato4.Name = "txtlato4"
        Me.txtlato4.Size = New System.Drawing.Size(81, 18)
        Me.txtlato4.TabIndex = 11
        '
        'txtlato3
        '
        Me.txtlato3.BackColor = System.Drawing.Color.Yellow
        Me.txtlato3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtlato3.Location = New System.Drawing.Point(19, 160)
        Me.txtlato3.Name = "txtlato3"
        Me.txtlato3.Size = New System.Drawing.Size(79, 18)
        Me.txtlato3.TabIndex = 10
        '
        'txtaltezza
        '
        Me.txtaltezza.BackColor = System.Drawing.Color.Yellow
        Me.txtaltezza.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtaltezza.Location = New System.Drawing.Point(110, 101)
        Me.txtaltezza.Name = "txtaltezza"
        Me.txtaltezza.Size = New System.Drawing.Size(80, 18)
        Me.txtaltezza.TabIndex = 9
        '
        'txtbase
        '
        Me.txtbase.BackColor = System.Drawing.Color.Yellow
        Me.txtbase.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtbase.Location = New System.Drawing.Point(19, 101)
        Me.txtbase.Name = "txtbase"
        Me.txtbase.Size = New System.Drawing.Size(76, 18)
        Me.txtbase.TabIndex = 8
        '
        'Label12
        '
        Me.Label12.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label12.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label12.Location = New System.Drawing.Point(108, 138)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(82, 14)
        Me.Label12.TabIndex = 7
        Me.Label12.Text = "Lato2"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label11
        '
        Me.Label11.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label11.Location = New System.Drawing.Point(112, 83)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(78, 14)
        Me.Label11.TabIndex = 6
        Me.Label11.Text = "Altezza"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label10
        '
        Me.Label10.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label10.Location = New System.Drawing.Point(19, 138)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(77, 14)
        Me.Label10.TabIndex = 5
        Me.Label10.Text = "Lato1"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label9
        '
        Me.Label9.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label9.Location = New System.Drawing.Point(19, 84)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(77, 14)
        Me.Label9.TabIndex = 4
        Me.Label9.Text = "Base"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'chkscaleno
        '
        Me.chkscaleno.AutoSize = True
        Me.chkscaleno.BackColor = System.Drawing.Color.Yellow
        Me.chkscaleno.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkscaleno.ForeColor = System.Drawing.Color.Blue
        Me.chkscaleno.Location = New System.Drawing.Point(183, 54)
        Me.chkscaleno.Name = "chkscaleno"
        Me.chkscaleno.Size = New System.Drawing.Size(57, 16)
        Me.chkscaleno.TabIndex = 3
        Me.chkscaleno.Text = "Scaleno"
        Me.chkscaleno.UseVisualStyleBackColor = False
        '
        'chkisoscele
        '
        Me.chkisoscele.AutoSize = True
        Me.chkisoscele.BackColor = System.Drawing.Color.Yellow
        Me.chkisoscele.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkisoscele.ForeColor = System.Drawing.Color.Blue
        Me.chkisoscele.Location = New System.Drawing.Point(107, 54)
        Me.chkisoscele.Name = "chkisoscele"
        Me.chkisoscele.Size = New System.Drawing.Size(59, 16)
        Me.chkisoscele.TabIndex = 2
        Me.chkisoscele.Text = "Isoscele"
        Me.chkisoscele.UseVisualStyleBackColor = False
        '
        'chkequilatero
        '
        Me.chkequilatero.AutoSize = True
        Me.chkequilatero.BackColor = System.Drawing.Color.Yellow
        Me.chkequilatero.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkequilatero.ForeColor = System.Drawing.Color.Blue
        Me.chkequilatero.Location = New System.Drawing.Point(24, 54)
        Me.chkequilatero.Name = "chkequilatero"
        Me.chkequilatero.Size = New System.Drawing.Size(65, 16)
        Me.chkequilatero.TabIndex = 1
        Me.chkequilatero.Text = "Equilatero"
        Me.chkequilatero.UseVisualStyleBackColor = False
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel3.Controls.Add(Me.btnstampa)
        Me.Panel3.Controls.Add(Me.Button5)
        Me.Panel3.Controls.Add(Me.lblarea2)
        Me.Panel3.Controls.Add(Me.lblperimetro3)
        Me.Panel3.Controls.Add(Me.lbldiagonale2)
        Me.Panel3.Controls.Add(Me.txtlatoobliquo2)
        Me.Panel3.Controls.Add(Me.txtlatoobliquo1)
        Me.Panel3.Controls.Add(Me.txttaltezza)
        Me.Panel3.Controls.Add(Me.txtbaseminore)
        Me.Panel3.Controls.Add(Me.txtbasemaggiore)
        Me.Panel3.Controls.Add(Me.Label21)
        Me.Panel3.Controls.Add(Me.Label20)
        Me.Panel3.Controls.Add(Me.Label19)
        Me.Panel3.Controls.Add(Me.Label18)
        Me.Panel3.Controls.Add(Me.Label17)
        Me.Panel3.Controls.Add(Me.Label16)
        Me.Panel3.Controls.Add(Me.Label15)
        Me.Panel3.Controls.Add(Me.Label14)
        Me.Panel3.Controls.Add(Me.chktrettangolo)
        Me.Panel3.Controls.Add(Me.chktisoscele)
        Me.Panel3.Controls.Add(Me.chktrapezio)
        Me.Panel3.Controls.Add(Me.Button4)
        Me.Panel3.Location = New System.Drawing.Point(593, 11)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(290, 277)
        Me.Panel3.TabIndex = 2
        '
        'btnstampa
        '
        Me.btnstampa.BackColor = System.Drawing.Color.Yellow
        Me.btnstampa.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnstampa.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnstampa.Location = New System.Drawing.Point(164, 235)
        Me.btnstampa.Name = "btnstampa"
        Me.btnstampa.Size = New System.Drawing.Size(98, 26)
        Me.btnstampa.TabIndex = 22
        Me.btnstampa.Text = "STAMPA"
        Me.btnstampa.UseVisualStyleBackColor = False
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.Color.Yellow
        Me.Button5.ForeColor = System.Drawing.Color.Blue
        Me.Button5.Location = New System.Drawing.Point(15, 235)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(96, 26)
        Me.Button5.TabIndex = 21
        Me.Button5.Text = "CANCELLA"
        Me.Button5.UseVisualStyleBackColor = False
        '
        'lblarea2
        '
        Me.lblarea2.BackColor = System.Drawing.Color.Yellow
        Me.lblarea2.ForeColor = System.Drawing.Color.Blue
        Me.lblarea2.Location = New System.Drawing.Point(103, 211)
        Me.lblarea2.Name = "lblarea2"
        Me.lblarea2.Size = New System.Drawing.Size(76, 15)
        Me.lblarea2.TabIndex = 20
        '
        'lblperimetro3
        '
        Me.lblperimetro3.BackColor = System.Drawing.Color.Yellow
        Me.lblperimetro3.ForeColor = System.Drawing.Color.Blue
        Me.lblperimetro3.Location = New System.Drawing.Point(103, 189)
        Me.lblperimetro3.Name = "lblperimetro3"
        Me.lblperimetro3.Size = New System.Drawing.Size(76, 15)
        Me.lblperimetro3.TabIndex = 19
        '
        'lbldiagonale2
        '
        Me.lbldiagonale2.BackColor = System.Drawing.Color.Yellow
        Me.lbldiagonale2.ForeColor = System.Drawing.Color.Blue
        Me.lbldiagonale2.Location = New System.Drawing.Point(103, 173)
        Me.lbldiagonale2.Name = "lbldiagonale2"
        Me.lbldiagonale2.Size = New System.Drawing.Size(76, 15)
        Me.lbldiagonale2.TabIndex = 18
        '
        'txtlatoobliquo2
        '
        Me.txtlatoobliquo2.BackColor = System.Drawing.Color.Yellow
        Me.txtlatoobliquo2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtlatoobliquo2.Location = New System.Drawing.Point(101, 150)
        Me.txtlatoobliquo2.Name = "txtlatoobliquo2"
        Me.txtlatoobliquo2.Size = New System.Drawing.Size(76, 18)
        Me.txtlatoobliquo2.TabIndex = 17
        '
        'txtlatoobliquo1
        '
        Me.txtlatoobliquo1.BackColor = System.Drawing.Color.Yellow
        Me.txtlatoobliquo1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtlatoobliquo1.Location = New System.Drawing.Point(16, 151)
        Me.txtlatoobliquo1.Name = "txtlatoobliquo1"
        Me.txtlatoobliquo1.Size = New System.Drawing.Size(76, 18)
        Me.txtlatoobliquo1.TabIndex = 16
        '
        'txttaltezza
        '
        Me.txttaltezza.BackColor = System.Drawing.Color.Yellow
        Me.txttaltezza.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txttaltezza.Location = New System.Drawing.Point(183, 102)
        Me.txttaltezza.Name = "txttaltezza"
        Me.txttaltezza.Size = New System.Drawing.Size(80, 18)
        Me.txttaltezza.TabIndex = 15
        '
        'txtbaseminore
        '
        Me.txtbaseminore.BackColor = System.Drawing.Color.Yellow
        Me.txtbaseminore.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtbaseminore.Location = New System.Drawing.Point(99, 102)
        Me.txtbaseminore.Name = "txtbaseminore"
        Me.txtbaseminore.Size = New System.Drawing.Size(76, 18)
        Me.txtbaseminore.TabIndex = 14
        '
        'txtbasemaggiore
        '
        Me.txtbasemaggiore.BackColor = System.Drawing.Color.Yellow
        Me.txtbasemaggiore.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtbasemaggiore.Location = New System.Drawing.Point(15, 102)
        Me.txtbasemaggiore.Name = "txtbasemaggiore"
        Me.txtbasemaggiore.Size = New System.Drawing.Size(76, 18)
        Me.txtbasemaggiore.TabIndex = 13
        '
        'Label21
        '
        Me.Label21.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label21.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label21.Location = New System.Drawing.Point(15, 212)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(78, 14)
        Me.Label21.TabIndex = 12
        Me.Label21.Text = "AREA"
        Me.Label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label20
        '
        Me.Label20.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label20.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label20.Location = New System.Drawing.Point(15, 189)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(78, 15)
        Me.Label20.TabIndex = 11
        Me.Label20.Text = "PERIMETRO"
        Me.Label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label19
        '
        Me.Label19.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label19.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label19.Location = New System.Drawing.Point(101, 126)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(75, 21)
        Me.Label19.TabIndex = 10
        Me.Label19.Text = "Lato obliquo 2"
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label18
        '
        Me.Label18.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label18.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label18.Location = New System.Drawing.Point(15, 127)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(78, 21)
        Me.Label18.TabIndex = 9
        Me.Label18.Text = "Lato obliquo 1"
        Me.Label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label17
        '
        Me.Label17.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label17.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label17.Location = New System.Drawing.Point(15, 173)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(78, 15)
        Me.Label17.TabIndex = 8
        Me.Label17.Text = "Diagonale"
        Me.Label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label16
        '
        Me.Label16.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label16.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label16.Location = New System.Drawing.Point(185, 77)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(78, 20)
        Me.Label16.TabIndex = 7
        Me.Label16.Text = "Altezza"
        Me.Label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label15
        '
        Me.Label15.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label15.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label15.Location = New System.Drawing.Point(99, 77)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(77, 21)
        Me.Label15.TabIndex = 6
        Me.Label15.Text = "Base minore"
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label14
        '
        Me.Label14.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label14.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label14.Location = New System.Drawing.Point(15, 76)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(77, 22)
        Me.Label14.TabIndex = 5
        Me.Label14.Text = "Base maggiore"
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'chktrettangolo
        '
        Me.chktrettangolo.BackColor = System.Drawing.Color.Yellow
        Me.chktrettangolo.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chktrettangolo.ForeColor = System.Drawing.Color.Blue
        Me.chktrettangolo.Location = New System.Drawing.Point(183, 54)
        Me.chktrettangolo.Name = "chktrettangolo"
        Me.chktrettangolo.Size = New System.Drawing.Size(80, 15)
        Me.chktrettangolo.TabIndex = 3
        Me.chktrettangolo.Text = "Rettangolo"
        Me.chktrettangolo.UseVisualStyleBackColor = False
        '
        'chktisoscele
        '
        Me.chktisoscele.BackColor = System.Drawing.Color.Yellow
        Me.chktisoscele.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chktisoscele.ForeColor = System.Drawing.Color.Blue
        Me.chktisoscele.Location = New System.Drawing.Point(101, 54)
        Me.chktisoscele.Name = "chktisoscele"
        Me.chktisoscele.Size = New System.Drawing.Size(75, 15)
        Me.chktisoscele.TabIndex = 2
        Me.chktisoscele.Text = "Isoscele"
        Me.chktisoscele.UseVisualStyleBackColor = False
        '
        'chktrapezio
        '
        Me.chktrapezio.BackColor = System.Drawing.Color.Yellow
        Me.chktrapezio.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chktrapezio.ForeColor = System.Drawing.Color.Blue
        Me.chktrapezio.Location = New System.Drawing.Point(17, 54)
        Me.chktrapezio.Name = "chktrapezio"
        Me.chktrapezio.Size = New System.Drawing.Size(75, 15)
        Me.chktrapezio.TabIndex = 1
        Me.chktrapezio.Text = "Trapezio"
        Me.chktrapezio.UseVisualStyleBackColor = False
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.Yellow
        Me.Button4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.ForeColor = System.Drawing.Color.Blue
        Me.Button4.Location = New System.Drawing.Point(17, 18)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(246, 23)
        Me.Button4.TabIndex = 0
        Me.Button4.Text = "TRAPEZI"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel4.Controls.Add(Me.Button8)
        Me.Panel4.Controls.Add(Me.Label33)
        Me.Panel4.Controls.Add(Me.lblperimetropoligono)
        Me.Panel4.Controls.Add(Me.lblareapoligono)
        Me.Panel4.Controls.Add(Me.lbldecagono)
        Me.Panel4.Controls.Add(Me.lblennagono)
        Me.Panel4.Controls.Add(Me.lblottagono)
        Me.Panel4.Controls.Add(Me.lblettagono)
        Me.Panel4.Controls.Add(Me.lblesagono)
        Me.Panel4.Controls.Add(Me.lblpentagono)
        Me.Panel4.Controls.Add(Me.lblquadrato)
        Me.Panel4.Controls.Add(Me.lbltriangolo)
        Me.Panel4.Controls.Add(Me.chkdecagono)
        Me.Panel4.Controls.Add(Me.chkennagono)
        Me.Panel4.Controls.Add(Me.chkottagono)
        Me.Panel4.Controls.Add(Me.chkettagono)
        Me.Panel4.Controls.Add(Me.chkesagono)
        Me.Panel4.Controls.Add(Me.chkpentagono)
        Me.Panel4.Controls.Add(Me.chkquadrato1)
        Me.Panel4.Controls.Add(Me.chktriangolo)
        Me.Panel4.Controls.Add(Me.Label32)
        Me.Panel4.Controls.Add(Me.Label31)
        Me.Panel4.Controls.Add(Me.Label30)
        Me.Panel4.Controls.Add(Me.Label29)
        Me.Panel4.Controls.Add(Me.Label28)
        Me.Panel4.Controls.Add(Me.Label27)
        Me.Panel4.Controls.Add(Me.Label26)
        Me.Panel4.Controls.Add(Me.Label25)
        Me.Panel4.Controls.Add(Me.Button6)
        Me.Panel4.Controls.Add(Me.Label24)
        Me.Panel4.Controls.Add(Me.Label23)
        Me.Panel4.Controls.Add(Me.txtnumerolati)
        Me.Panel4.Controls.Add(Me.Label22)
        Me.Panel4.Controls.Add(Me.txtlatopoligono)
        Me.Panel4.Location = New System.Drawing.Point(15, 294)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(288, 331)
        Me.Panel4.TabIndex = 3
        '
        'Button8
        '
        Me.Button8.BackColor = System.Drawing.Color.Yellow
        Me.Button8.Location = New System.Drawing.Point(34, 289)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(106, 23)
        Me.Button8.TabIndex = 31
        Me.Button8.Text = "CANCELLA"
        Me.Button8.UseVisualStyleBackColor = False
        '
        'Label33
        '
        Me.Label33.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label33.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label33.Location = New System.Drawing.Point(36, 240)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(105, 21)
        Me.Label33.TabIndex = 30
        Me.Label33.Text = "PERIMETRO"
        Me.Label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblperimetropoligono
        '
        Me.lblperimetropoligono.BackColor = System.Drawing.Color.Yellow
        Me.lblperimetropoligono.Location = New System.Drawing.Point(37, 264)
        Me.lblperimetropoligono.Name = "lblperimetropoligono"
        Me.lblperimetropoligono.Size = New System.Drawing.Size(103, 21)
        Me.lblperimetropoligono.TabIndex = 29
        '
        'lblareapoligono
        '
        Me.lblareapoligono.BackColor = System.Drawing.Color.Yellow
        Me.lblareapoligono.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblareapoligono.Location = New System.Drawing.Point(176, 264)
        Me.lblareapoligono.Name = "lblareapoligono"
        Me.lblareapoligono.Size = New System.Drawing.Size(97, 21)
        Me.lblareapoligono.TabIndex = 28
        Me.lblareapoligono.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbldecagono
        '
        Me.lbldecagono.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lbldecagono.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbldecagono.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lbldecagono.Location = New System.Drawing.Point(185, 219)
        Me.lbldecagono.Name = "lbldecagono"
        Me.lbldecagono.Size = New System.Drawing.Size(77, 15)
        Me.lbldecagono.TabIndex = 27
        '
        'lblennagono
        '
        Me.lblennagono.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblennagono.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblennagono.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblennagono.Location = New System.Drawing.Point(185, 205)
        Me.lblennagono.Name = "lblennagono"
        Me.lblennagono.Size = New System.Drawing.Size(77, 15)
        Me.lblennagono.TabIndex = 26
        '
        'lblottagono
        '
        Me.lblottagono.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblottagono.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblottagono.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblottagono.Location = New System.Drawing.Point(185, 190)
        Me.lblottagono.Name = "lblottagono"
        Me.lblottagono.Size = New System.Drawing.Size(77, 15)
        Me.lblottagono.TabIndex = 25
        '
        'lblettagono
        '
        Me.lblettagono.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblettagono.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblettagono.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblettagono.Location = New System.Drawing.Point(185, 175)
        Me.lblettagono.Name = "lblettagono"
        Me.lblettagono.Size = New System.Drawing.Size(77, 15)
        Me.lblettagono.TabIndex = 24
        '
        'lblesagono
        '
        Me.lblesagono.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblesagono.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblesagono.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblesagono.Location = New System.Drawing.Point(185, 161)
        Me.lblesagono.Name = "lblesagono"
        Me.lblesagono.Size = New System.Drawing.Size(77, 15)
        Me.lblesagono.TabIndex = 23
        '
        'lblpentagono
        '
        Me.lblpentagono.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblpentagono.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblpentagono.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblpentagono.Location = New System.Drawing.Point(185, 146)
        Me.lblpentagono.Name = "lblpentagono"
        Me.lblpentagono.Size = New System.Drawing.Size(77, 15)
        Me.lblpentagono.TabIndex = 22
        '
        'lblquadrato
        '
        Me.lblquadrato.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblquadrato.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblquadrato.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lblquadrato.Location = New System.Drawing.Point(185, 131)
        Me.lblquadrato.Name = "lblquadrato"
        Me.lblquadrato.Size = New System.Drawing.Size(77, 15)
        Me.lblquadrato.TabIndex = 21
        '
        'lbltriangolo
        '
        Me.lbltriangolo.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lbltriangolo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbltriangolo.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lbltriangolo.Location = New System.Drawing.Point(185, 116)
        Me.lbltriangolo.Name = "lbltriangolo"
        Me.lbltriangolo.Size = New System.Drawing.Size(77, 15)
        Me.lbltriangolo.TabIndex = 4
        '
        'chkdecagono
        '
        Me.chkdecagono.BackColor = System.Drawing.Color.Yellow
        Me.chkdecagono.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkdecagono.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.chkdecagono.Location = New System.Drawing.Point(139, 221)
        Me.chkdecagono.Name = "chkdecagono"
        Me.chkdecagono.Size = New System.Drawing.Size(36, 16)
        Me.chkdecagono.TabIndex = 20
        Me.chkdecagono.Text = "De"
        Me.chkdecagono.UseVisualStyleBackColor = False
        '
        'chkennagono
        '
        Me.chkennagono.BackColor = System.Drawing.Color.Yellow
        Me.chkennagono.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkennagono.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.chkennagono.Location = New System.Drawing.Point(139, 204)
        Me.chkennagono.Name = "chkennagono"
        Me.chkennagono.Size = New System.Drawing.Size(36, 16)
        Me.chkennagono.TabIndex = 19
        Me.chkennagono.Text = "En"
        Me.chkennagono.UseVisualStyleBackColor = False
        '
        'chkottagono
        '
        Me.chkottagono.BackColor = System.Drawing.Color.Yellow
        Me.chkottagono.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkottagono.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.chkottagono.Location = New System.Drawing.Point(139, 190)
        Me.chkottagono.Name = "chkottagono"
        Me.chkottagono.Size = New System.Drawing.Size(36, 16)
        Me.chkottagono.TabIndex = 18
        Me.chkottagono.Text = "Ot"
        Me.chkottagono.UseVisualStyleBackColor = False
        '
        'chkettagono
        '
        Me.chkettagono.BackColor = System.Drawing.Color.Yellow
        Me.chkettagono.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkettagono.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.chkettagono.Location = New System.Drawing.Point(139, 174)
        Me.chkettagono.Name = "chkettagono"
        Me.chkettagono.Size = New System.Drawing.Size(36, 16)
        Me.chkettagono.TabIndex = 17
        Me.chkettagono.Text = "Et"
        Me.chkettagono.UseVisualStyleBackColor = False
        '
        'chkesagono
        '
        Me.chkesagono.BackColor = System.Drawing.Color.Yellow
        Me.chkesagono.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkesagono.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.chkesagono.Location = New System.Drawing.Point(139, 161)
        Me.chkesagono.Name = "chkesagono"
        Me.chkesagono.Size = New System.Drawing.Size(36, 16)
        Me.chkesagono.TabIndex = 16
        Me.chkesagono.Text = "Es"
        Me.chkesagono.UseVisualStyleBackColor = False
        '
        'chkpentagono
        '
        Me.chkpentagono.BackColor = System.Drawing.Color.Yellow
        Me.chkpentagono.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkpentagono.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.chkpentagono.Location = New System.Drawing.Point(139, 144)
        Me.chkpentagono.Name = "chkpentagono"
        Me.chkpentagono.Size = New System.Drawing.Size(36, 16)
        Me.chkpentagono.TabIndex = 15
        Me.chkpentagono.Text = "Pe"
        Me.chkpentagono.UseVisualStyleBackColor = False
        '
        'chkquadrato1
        '
        Me.chkquadrato1.BackColor = System.Drawing.Color.Yellow
        Me.chkquadrato1.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkquadrato1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.chkquadrato1.Location = New System.Drawing.Point(139, 129)
        Me.chkquadrato1.Name = "chkquadrato1"
        Me.chkquadrato1.Size = New System.Drawing.Size(36, 16)
        Me.chkquadrato1.TabIndex = 14
        Me.chkquadrato1.Text = "Qu"
        Me.chkquadrato1.UseVisualStyleBackColor = False
        '
        'chktriangolo
        '
        Me.chktriangolo.BackColor = System.Drawing.Color.Yellow
        Me.chktriangolo.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chktriangolo.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.chktriangolo.Location = New System.Drawing.Point(139, 116)
        Me.chktriangolo.Name = "chktriangolo"
        Me.chktriangolo.Size = New System.Drawing.Size(36, 16)
        Me.chktriangolo.TabIndex = 4
        Me.chktriangolo.Text = "Tr"
        Me.chktriangolo.UseVisualStyleBackColor = False
        '
        'Label32
        '
        Me.Label32.BackColor = System.Drawing.Color.Yellow
        Me.Label32.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label32.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label32.Location = New System.Drawing.Point(36, 218)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(105, 15)
        Me.Label32.TabIndex = 13
        Me.Label32.Text = "Decagono"
        Me.Label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label31
        '
        Me.Label31.BackColor = System.Drawing.Color.Yellow
        Me.Label31.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label31.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label31.Location = New System.Drawing.Point(36, 203)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(105, 15)
        Me.Label31.TabIndex = 12
        Me.Label31.Text = "Ennagono"
        Me.Label31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label30
        '
        Me.Label30.BackColor = System.Drawing.Color.Yellow
        Me.Label30.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label30.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label30.Location = New System.Drawing.Point(36, 188)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(105, 15)
        Me.Label30.TabIndex = 11
        Me.Label30.Text = "Ottagono"
        Me.Label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label29
        '
        Me.Label29.BackColor = System.Drawing.Color.Yellow
        Me.Label29.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label29.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label29.Location = New System.Drawing.Point(36, 174)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(105, 15)
        Me.Label29.TabIndex = 10
        Me.Label29.Text = "Ettagono"
        Me.Label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label28
        '
        Me.Label28.BackColor = System.Drawing.Color.Yellow
        Me.Label28.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label28.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label28.Location = New System.Drawing.Point(36, 159)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(105, 15)
        Me.Label28.TabIndex = 9
        Me.Label28.Text = "Esagono"
        Me.Label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label27
        '
        Me.Label27.BackColor = System.Drawing.Color.Yellow
        Me.Label27.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label27.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label27.Location = New System.Drawing.Point(36, 144)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(105, 15)
        Me.Label27.TabIndex = 8
        Me.Label27.Text = "Pentagono"
        Me.Label27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label26
        '
        Me.Label26.BackColor = System.Drawing.Color.Yellow
        Me.Label26.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label26.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label26.Location = New System.Drawing.Point(36, 129)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(105, 15)
        Me.Label26.TabIndex = 7
        Me.Label26.Text = "Quadrato"
        Me.Label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label25
        '
        Me.Label25.BackColor = System.Drawing.Color.Yellow
        Me.Label25.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label25.Location = New System.Drawing.Point(36, 114)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(105, 15)
        Me.Label25.TabIndex = 6
        Me.Label25.Text = "Triangolo"
        Me.Label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Button6
        '
        Me.Button6.BackColor = System.Drawing.Color.Yellow
        Me.Button6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Button6.Location = New System.Drawing.Point(36, 14)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(231, 21)
        Me.Button6.TabIndex = 5
        Me.Button6.Text = "POLIGONI REGOLARI"
        Me.Button6.UseVisualStyleBackColor = False
        '
        'Label24
        '
        Me.Label24.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label24.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label24.Location = New System.Drawing.Point(176, 240)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(97, 21)
        Me.Label24.TabIndex = 4
        Me.Label24.Text = "AREA"
        Me.Label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label23
        '
        Me.Label23.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label23.Location = New System.Drawing.Point(176, 48)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(97, 21)
        Me.Label23.TabIndex = 3
        Me.Label23.Text = "Numero lati"
        Me.Label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtnumerolati
        '
        Me.txtnumerolati.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtnumerolati.ForeColor = System.Drawing.Color.Blue
        Me.txtnumerolati.Location = New System.Drawing.Point(174, 72)
        Me.txtnumerolati.Name = "txtnumerolati"
        Me.txtnumerolati.Size = New System.Drawing.Size(99, 18)
        Me.txtnumerolati.TabIndex = 2
        '
        'Label22
        '
        Me.Label22.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label22.Location = New System.Drawing.Point(36, 48)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(104, 21)
        Me.Label22.TabIndex = 1
        Me.Label22.Text = "Lato poligono"
        Me.Label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtlatopoligono
        '
        Me.txtlatopoligono.BackColor = System.Drawing.Color.Yellow
        Me.txtlatopoligono.ForeColor = System.Drawing.Color.Blue
        Me.txtlatopoligono.Location = New System.Drawing.Point(36, 72)
        Me.txtlatopoligono.Name = "txtlatopoligono"
        Me.txtlatopoligono.Size = New System.Drawing.Size(104, 18)
        Me.txtlatopoligono.TabIndex = 0
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel5.Controls.Add(Me.lblperimetrocorona)
        Me.Panel5.Controls.Add(Me.Label44)
        Me.Panel5.Controls.Add(Me.lblcorona)
        Me.Panel5.Controls.Add(Me.Label43)
        Me.Panel5.Controls.Add(Me.lblsettore)
        Me.Panel5.Controls.Add(Me.Label42)
        Me.Panel5.Controls.Add(Me.btncancelladati)
        Me.Panel5.Controls.Add(Me.lbllunghezzaarco)
        Me.Panel5.Controls.Add(Me.lblareacirconferenza)
        Me.Panel5.Controls.Add(Me.lblcirconferenza)
        Me.Panel5.Controls.Add(Me.Label41)
        Me.Panel5.Controls.Add(Me.txtraggioesterno)
        Me.Panel5.Controls.Add(Me.txtraggiointerno)
        Me.Panel5.Controls.Add(Me.Label40)
        Me.Panel5.Controls.Add(Me.Label39)
        Me.Panel5.Controls.Add(Me.txtarco)
        Me.Panel5.Controls.Add(Me.txtangolo)
        Me.Panel5.Controls.Add(Me.Label38)
        Me.Panel5.Controls.Add(Me.Label37)
        Me.Panel5.Controls.Add(Me.chkcorona)
        Me.Panel5.Controls.Add(Me.chksettorecircolare)
        Me.Panel5.Controls.Add(Me.chkcirconferenza)
        Me.Panel5.Controls.Add(Me.Label36)
        Me.Panel5.Controls.Add(Me.Label35)
        Me.Panel5.Controls.Add(Me.txtraggio)
        Me.Panel5.Controls.Add(Me.btncerchio)
        Me.Panel5.Controls.Add(Me.Label34)
        Me.Panel5.Location = New System.Drawing.Point(310, 295)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(275, 330)
        Me.Panel5.TabIndex = 4
        '
        'lblperimetrocorona
        '
        Me.lblperimetrocorona.BackColor = System.Drawing.Color.Yellow
        Me.lblperimetrocorona.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblperimetrocorona.ForeColor = System.Drawing.Color.Blue
        Me.lblperimetrocorona.Location = New System.Drawing.Point(187, 158)
        Me.lblperimetrocorona.Name = "lblperimetrocorona"
        Me.lblperimetrocorona.Size = New System.Drawing.Size(76, 18)
        Me.lblperimetrocorona.TabIndex = 37
        '
        'Label44
        '
        Me.Label44.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label44.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label44.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label44.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label44.Location = New System.Drawing.Point(186, 130)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(77, 22)
        Me.Label44.TabIndex = 36
        Me.Label44.Text = "Perimetro cor."
        Me.Label44.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblcorona
        '
        Me.lblcorona.BackColor = System.Drawing.Color.Yellow
        Me.lblcorona.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblcorona.ForeColor = System.Drawing.Color.Blue
        Me.lblcorona.Location = New System.Drawing.Point(104, 266)
        Me.lblcorona.Name = "lblcorona"
        Me.lblcorona.Size = New System.Drawing.Size(76, 24)
        Me.lblcorona.TabIndex = 35
        '
        'Label43
        '
        Me.Label43.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label43.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label43.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label43.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label43.Location = New System.Drawing.Point(103, 240)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(77, 22)
        Me.Label43.TabIndex = 34
        Me.Label43.Text = "Area corona"
        Me.Label43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblsettore
        '
        Me.lblsettore.BackColor = System.Drawing.Color.Yellow
        Me.lblsettore.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblsettore.ForeColor = System.Drawing.Color.Blue
        Me.lblsettore.Location = New System.Drawing.Point(187, 266)
        Me.lblsettore.Name = "lblsettore"
        Me.lblsettore.Size = New System.Drawing.Size(76, 24)
        Me.lblsettore.TabIndex = 33
        '
        'Label42
        '
        Me.Label42.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label42.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label42.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label42.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label42.Location = New System.Drawing.Point(186, 238)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(77, 22)
        Me.Label42.TabIndex = 32
        Me.Label42.Text = "Area settore"
        Me.Label42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btncancelladati
        '
        Me.btncancelladati.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btncancelladati.ForeColor = System.Drawing.Color.Blue
        Me.btncancelladati.Location = New System.Drawing.Point(18, 239)
        Me.btncancelladati.Name = "btncancelladati"
        Me.btncancelladati.Size = New System.Drawing.Size(80, 26)
        Me.btncancelladati.TabIndex = 31
        Me.btncancelladati.Text = "CANCELLA"
        Me.btncancelladati.UseVisualStyleBackColor = False
        '
        'lbllunghezzaarco
        '
        Me.lbllunghezzaarco.BackColor = System.Drawing.Color.Yellow
        Me.lbllunghezzaarco.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbllunghezzaarco.ForeColor = System.Drawing.Color.Blue
        Me.lbllunghezzaarco.Location = New System.Drawing.Point(187, 205)
        Me.lbllunghezzaarco.Name = "lbllunghezzaarco"
        Me.lbllunghezzaarco.Size = New System.Drawing.Size(76, 27)
        Me.lbllunghezzaarco.TabIndex = 30
        '
        'lblareacirconferenza
        '
        Me.lblareacirconferenza.BackColor = System.Drawing.Color.Yellow
        Me.lblareacirconferenza.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblareacirconferenza.ForeColor = System.Drawing.Color.Blue
        Me.lblareacirconferenza.Location = New System.Drawing.Point(105, 205)
        Me.lblareacirconferenza.Name = "lblareacirconferenza"
        Me.lblareacirconferenza.Size = New System.Drawing.Size(81, 27)
        Me.lblareacirconferenza.TabIndex = 29
        '
        'lblcirconferenza
        '
        Me.lblcirconferenza.BackColor = System.Drawing.Color.Yellow
        Me.lblcirconferenza.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblcirconferenza.ForeColor = System.Drawing.Color.Blue
        Me.lblcirconferenza.Location = New System.Drawing.Point(18, 205)
        Me.lblcirconferenza.Name = "lblcirconferenza"
        Me.lblcirconferenza.Size = New System.Drawing.Size(78, 27)
        Me.lblcirconferenza.TabIndex = 28
        '
        'Label41
        '
        Me.Label41.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label41.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label41.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label41.Location = New System.Drawing.Point(186, 179)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(77, 22)
        Me.Label41.TabIndex = 27
        Me.Label41.Text = "lungh.  arco"
        Me.Label41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtraggioesterno
        '
        Me.txtraggioesterno.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtraggioesterno.Location = New System.Drawing.Point(105, 158)
        Me.txtraggioesterno.Name = "txtraggioesterno"
        Me.txtraggioesterno.Size = New System.Drawing.Size(79, 18)
        Me.txtraggioesterno.TabIndex = 26
        '
        'txtraggiointerno
        '
        Me.txtraggiointerno.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtraggiointerno.Location = New System.Drawing.Point(18, 158)
        Me.txtraggiointerno.Name = "txtraggiointerno"
        Me.txtraggiointerno.Size = New System.Drawing.Size(80, 18)
        Me.txtraggiointerno.TabIndex = 25
        '
        'Label40
        '
        Me.Label40.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label40.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label40.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label40.Location = New System.Drawing.Point(105, 131)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(77, 22)
        Me.Label40.TabIndex = 24
        Me.Label40.Text = "Raggio est."
        Me.Label40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label39
        '
        Me.Label39.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label39.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label39.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label39.Location = New System.Drawing.Point(19, 131)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(77, 22)
        Me.Label39.TabIndex = 23
        Me.Label39.Text = "Raggio int."
        Me.Label39.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtarco
        '
        Me.txtarco.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtarco.Location = New System.Drawing.Point(186, 110)
        Me.txtarco.Name = "txtarco"
        Me.txtarco.Size = New System.Drawing.Size(77, 18)
        Me.txtarco.TabIndex = 22
        '
        'txtangolo
        '
        Me.txtangolo.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtangolo.Location = New System.Drawing.Point(105, 109)
        Me.txtangolo.Name = "txtangolo"
        Me.txtangolo.Size = New System.Drawing.Size(77, 18)
        Me.txtangolo.TabIndex = 21
        '
        'Label38
        '
        Me.Label38.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label38.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label38.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label38.Location = New System.Drawing.Point(186, 85)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(77, 22)
        Me.Label38.TabIndex = 20
        Me.Label38.Text = "lungh.  arco"
        Me.Label38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label37
        '
        Me.Label37.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label37.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label37.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label37.Location = New System.Drawing.Point(105, 85)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(77, 22)
        Me.Label37.TabIndex = 19
        Me.Label37.Text = "Angolo settore"
        Me.Label37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'chkcorona
        '
        Me.chkcorona.BackColor = System.Drawing.Color.Yellow
        Me.chkcorona.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkcorona.ForeColor = System.Drawing.Color.Blue
        Me.chkcorona.Location = New System.Drawing.Point(186, 47)
        Me.chkcorona.Name = "chkcorona"
        Me.chkcorona.Size = New System.Drawing.Size(72, 15)
        Me.chkcorona.TabIndex = 18
        Me.chkcorona.Text = "Corona circ."
        Me.chkcorona.UseVisualStyleBackColor = False
        '
        'chksettorecircolare
        '
        Me.chksettorecircolare.BackColor = System.Drawing.Color.Yellow
        Me.chksettorecircolare.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chksettorecircolare.ForeColor = System.Drawing.Color.Blue
        Me.chksettorecircolare.Location = New System.Drawing.Point(100, 47)
        Me.chksettorecircolare.Name = "chksettorecircolare"
        Me.chksettorecircolare.Size = New System.Drawing.Size(82, 15)
        Me.chksettorecircolare.TabIndex = 17
        Me.chksettorecircolare.Text = "Settorecircolare"
        Me.chksettorecircolare.UseVisualStyleBackColor = False
        '
        'chkcirconferenza
        '
        Me.chkcirconferenza.BackColor = System.Drawing.Color.Yellow
        Me.chkcirconferenza.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkcirconferenza.ForeColor = System.Drawing.Color.Blue
        Me.chkcirconferenza.Location = New System.Drawing.Point(19, 47)
        Me.chkcirconferenza.Name = "chkcirconferenza"
        Me.chkcirconferenza.Size = New System.Drawing.Size(75, 15)
        Me.chkcirconferenza.TabIndex = 16
        Me.chkcirconferenza.Text = "Circonferenza"
        Me.chkcirconferenza.UseVisualStyleBackColor = False
        '
        'Label36
        '
        Me.Label36.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label36.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label36.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label36.Location = New System.Drawing.Point(105, 180)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(80, 21)
        Me.Label36.TabIndex = 15
        Me.Label36.Text = "AREA"
        Me.Label36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label35
        '
        Me.Label35.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label35.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label35.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label35.Location = New System.Drawing.Point(18, 181)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(80, 21)
        Me.Label35.TabIndex = 9
        Me.Label35.Text = "Circonferenza"
        Me.Label35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtraggio
        '
        Me.txtraggio.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtraggio.ForeColor = System.Drawing.Color.Blue
        Me.txtraggio.Location = New System.Drawing.Point(18, 110)
        Me.txtraggio.Name = "txtraggio"
        Me.txtraggio.Size = New System.Drawing.Size(77, 18)
        Me.txtraggio.TabIndex = 8
        '
        'btncerchio
        '
        Me.btncerchio.BackColor = System.Drawing.Color.Yellow
        Me.btncerchio.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btncerchio.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btncerchio.Location = New System.Drawing.Point(18, 13)
        Me.btncerchio.Name = "btncerchio"
        Me.btncerchio.Size = New System.Drawing.Size(240, 21)
        Me.btncerchio.TabIndex = 7
        Me.btncerchio.Text = "CIRCONFERENZA CERCHIO"
        Me.btncerchio.UseVisualStyleBackColor = False
        '
        'Label34
        '
        Me.Label34.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label34.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label34.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label34.Location = New System.Drawing.Point(18, 85)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(77, 22)
        Me.Label34.TabIndex = 6
        Me.Label34.Text = "Raggio"
        Me.Label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Panel6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel6.Controls.Add(Me.CheckBox2)
        Me.Panel6.Controls.Add(Me.CheckBox1)
        Me.Panel6.Controls.Add(Me.Button10)
        Me.Panel6.Controls.Add(Me.Button9)
        Me.Panel6.Controls.Add(Me.Label53)
        Me.Panel6.Controls.Add(Me.Label52)
        Me.Panel6.Controls.Add(Me.lblperimetroellisse)
        Me.Panel6.Controls.Add(Me.lblareaellisse)
        Me.Panel6.Controls.Add(Me.Label51)
        Me.Panel6.Controls.Add(Me.Label50)
        Me.Panel6.Controls.Add(Me.txtsemiassemaggiore)
        Me.Panel6.Controls.Add(Me.txtsemiasseminore)
        Me.Panel6.Controls.Add(Me.lblperimetrorombo)
        Me.Panel6.Controls.Add(Me.Label49)
        Me.Panel6.Controls.Add(Me.lblarearombo)
        Me.Panel6.Controls.Add(Me.Label46)
        Me.Panel6.Controls.Add(Me.Label48)
        Me.Panel6.Controls.Add(Me.Label47)
        Me.Panel6.Controls.Add(Me.lbllato)
        Me.Panel6.Controls.Add(Me.Label45)
        Me.Panel6.Controls.Add(Me.txtdiagonale2)
        Me.Panel6.Controls.Add(Me.txtdiagonale1)
        Me.Panel6.Location = New System.Drawing.Point(593, 294)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(290, 331)
        Me.Panel6.TabIndex = 5
        '
        'CheckBox2
        '
        Me.CheckBox2.AutoSize = True
        Me.CheckBox2.BackColor = System.Drawing.Color.Yellow
        Me.CheckBox2.Location = New System.Drawing.Point(160, 43)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(58, 16)
        Me.CheckBox2.TabIndex = 26
        Me.CheckBox2.Text = "Ellisse"
        Me.CheckBox2.UseVisualStyleBackColor = False
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.BackColor = System.Drawing.Color.Yellow
        Me.CheckBox1.Location = New System.Drawing.Point(34, 43)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(59, 16)
        Me.CheckBox1.TabIndex = 25
        Me.CheckBox1.Text = "Rombo"
        Me.CheckBox1.UseVisualStyleBackColor = False
        '
        'Button10
        '
        Me.Button10.BackColor = System.Drawing.Color.Yellow
        Me.Button10.Location = New System.Drawing.Point(32, 13)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(226, 24)
        Me.Button10.TabIndex = 23
        Me.Button10.Text = "ROMBO - ELLISSE"
        Me.Button10.UseVisualStyleBackColor = False
        '
        'Button9
        '
        Me.Button9.BackColor = System.Drawing.Color.Yellow
        Me.Button9.Location = New System.Drawing.Point(32, 180)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(98, 23)
        Me.Button9.TabIndex = 22
        Me.Button9.Text = "CANCELLA"
        Me.Button9.UseVisualStyleBackColor = False
        '
        'Label53
        '
        Me.Label53.BackColor = System.Drawing.Color.Yellow
        Me.Label53.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label53.Location = New System.Drawing.Point(32, 245)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(97, 21)
        Me.Label53.TabIndex = 21
        Me.Label53.Text = "Area ellisse"
        Me.Label53.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label52
        '
        Me.Label52.BackColor = System.Drawing.Color.Yellow
        Me.Label52.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label52.Location = New System.Drawing.Point(158, 245)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(100, 21)
        Me.Label52.TabIndex = 20
        Me.Label52.Text = "Perimetro ellisse"
        Me.Label52.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblperimetroellisse
        '
        Me.lblperimetroellisse.BackColor = System.Drawing.Color.Yellow
        Me.lblperimetroellisse.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblperimetroellisse.Location = New System.Drawing.Point(160, 270)
        Me.lblperimetroellisse.Name = "lblperimetroellisse"
        Me.lblperimetroellisse.Size = New System.Drawing.Size(98, 21)
        Me.lblperimetroellisse.TabIndex = 19
        Me.lblperimetroellisse.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblareaellisse
        '
        Me.lblareaellisse.BackColor = System.Drawing.Color.Yellow
        Me.lblareaellisse.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblareaellisse.Location = New System.Drawing.Point(32, 270)
        Me.lblareaellisse.Name = "lblareaellisse"
        Me.lblareaellisse.Size = New System.Drawing.Size(98, 21)
        Me.lblareaellisse.TabIndex = 18
        Me.lblareaellisse.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label51
        '
        Me.Label51.BackColor = System.Drawing.Color.Yellow
        Me.Label51.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label51.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label51.Location = New System.Drawing.Point(158, 206)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(97, 18)
        Me.Label51.TabIndex = 17
        Me.Label51.Text = "Semiasse maggiore"
        Me.Label51.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label50
        '
        Me.Label50.BackColor = System.Drawing.Color.Yellow
        Me.Label50.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label50.Location = New System.Drawing.Point(34, 205)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(95, 18)
        Me.Label50.TabIndex = 16
        Me.Label50.Text = "Semiasse minore"
        Me.Label50.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtsemiassemaggiore
        '
        Me.txtsemiassemaggiore.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtsemiassemaggiore.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtsemiassemaggiore.Location = New System.Drawing.Point(158, 227)
        Me.txtsemiassemaggiore.Name = "txtsemiassemaggiore"
        Me.txtsemiassemaggiore.Size = New System.Drawing.Size(97, 18)
        Me.txtsemiassemaggiore.TabIndex = 15
        '
        'txtsemiasseminore
        '
        Me.txtsemiasseminore.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtsemiasseminore.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtsemiasseminore.Location = New System.Drawing.Point(32, 224)
        Me.txtsemiasseminore.Name = "txtsemiasseminore"
        Me.txtsemiasseminore.Size = New System.Drawing.Size(98, 18)
        Me.txtsemiasseminore.TabIndex = 14
        '
        'lblperimetrorombo
        '
        Me.lblperimetrorombo.BackColor = System.Drawing.Color.Yellow
        Me.lblperimetrorombo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblperimetrorombo.Location = New System.Drawing.Point(158, 185)
        Me.lblperimetrorombo.Name = "lblperimetrorombo"
        Me.lblperimetrorombo.Size = New System.Drawing.Size(100, 21)
        Me.lblperimetrorombo.TabIndex = 13
        Me.lblperimetrorombo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label49
        '
        Me.Label49.BackColor = System.Drawing.Color.Yellow
        Me.Label49.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label49.Location = New System.Drawing.Point(160, 159)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(98, 21)
        Me.Label49.TabIndex = 12
        Me.Label49.Text = "PERIMETRO"
        Me.Label49.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblarearombo
        '
        Me.lblarearombo.BackColor = System.Drawing.Color.Yellow
        Me.lblarearombo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblarearombo.Location = New System.Drawing.Point(158, 132)
        Me.lblarearombo.Name = "lblarearombo"
        Me.lblarearombo.Size = New System.Drawing.Size(100, 21)
        Me.lblarearombo.TabIndex = 11
        Me.lblarearombo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label46
        '
        Me.Label46.BackColor = System.Drawing.Color.Yellow
        Me.Label46.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label46.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label46.Location = New System.Drawing.Point(158, 65)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(100, 20)
        Me.Label46.TabIndex = 10
        Me.Label46.Text = "Diagonale maggiore"
        Me.Label46.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label48
        '
        Me.Label48.BackColor = System.Drawing.Color.Yellow
        Me.Label48.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label48.Location = New System.Drawing.Point(158, 112)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(100, 16)
        Me.Label48.TabIndex = 9
        Me.Label48.Text = "AREA"
        Me.Label48.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label47
        '
        Me.Label47.BackColor = System.Drawing.Color.Yellow
        Me.Label47.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label47.Location = New System.Drawing.Point(34, 113)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(96, 18)
        Me.Label47.TabIndex = 8
        Me.Label47.Text = "LATO"
        Me.Label47.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbllato
        '
        Me.lbllato.BackColor = System.Drawing.Color.Yellow
        Me.lbllato.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbllato.Location = New System.Drawing.Point(34, 133)
        Me.lbllato.Name = "lbllato"
        Me.lbllato.Size = New System.Drawing.Size(96, 21)
        Me.lbllato.TabIndex = 7
        Me.lbllato.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label45
        '
        Me.Label45.BackColor = System.Drawing.Color.Yellow
        Me.Label45.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label45.Location = New System.Drawing.Point(34, 65)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(95, 20)
        Me.Label45.TabIndex = 5
        Me.Label45.Text = "Diagonale minore"
        Me.Label45.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtdiagonale2
        '
        Me.txtdiagonale2.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtdiagonale2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtdiagonale2.Location = New System.Drawing.Point(158, 90)
        Me.txtdiagonale2.Name = "txtdiagonale2"
        Me.txtdiagonale2.Size = New System.Drawing.Size(100, 18)
        Me.txtdiagonale2.TabIndex = 4
        '
        'txtdiagonale1
        '
        Me.txtdiagonale1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtdiagonale1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.txtdiagonale1.Location = New System.Drawing.Point(34, 90)
        Me.txtdiagonale1.Name = "txtdiagonale1"
        Me.txtdiagonale1.Size = New System.Drawing.Size(96, 18)
        Me.txtdiagonale1.TabIndex = 3
        '
        'chkellisse
        '
        Me.chkellisse.AutoSize = True
        Me.chkellisse.BackColor = System.Drawing.Color.Yellow
        Me.chkellisse.Location = New System.Drawing.Point(200, 41)
        Me.chkellisse.Name = "chkellisse"
        Me.chkellisse.Size = New System.Drawing.Size(58, 16)
        Me.chkellisse.TabIndex = 2
        Me.chkellisse.Text = "Ellisse"
        Me.chkellisse.UseVisualStyleBackColor = False
        '
        'chkrombo
        '
        Me.chkrombo.AutoSize = True
        Me.chkrombo.BackColor = System.Drawing.Color.Yellow
        Me.chkrombo.Location = New System.Drawing.Point(32, 46)
        Me.chkrombo.Name = "chkrombo"
        Me.chkrombo.Size = New System.Drawing.Size(59, 16)
        Me.chkrombo.TabIndex = 1
        Me.chkrombo.Text = "Rombo"
        Me.chkrombo.UseVisualStyleBackColor = False
        '
        'PrintForm2
        '
        Me.PrintForm2.DocumentName = "document"
        Me.PrintForm2.Form = Me
        Me.PrintForm2.PrintAction = System.Drawing.Printing.PrintAction.PrintToPrinter
        Me.PrintForm2.PrinterSettings = CType(resources.GetObject("PrintForm2.PrinterSettings"), System.Drawing.Printing.PrinterSettings)
        Me.PrintForm2.PrintFileName = Nothing
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(902, 637)
        Me.Controls.Add(Me.Panel6)
        Me.Controls.Add(Me.Panel5)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Name = "Form1"
        Me.Text = "AREE FIGURE PIANE"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents lblrisultato As System.Windows.Forms.Label
    Friend WithEvents txtlato1 As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents txtlato2 As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents lblperimetro As System.Windows.Forms.Label
    Friend WithEvents btncancella As System.Windows.Forms.Button
    Friend WithEvents chkquadrato As System.Windows.Forms.CheckBox
    Friend WithEvents lblperimetro1 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents lblarea As System.Windows.Forms.Label
    Friend WithEvents lbldiagonale As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents lbldiagonale1 As System.Windows.Forms.Label
    Friend WithEvents chkrettangolo As System.Windows.Forms.CheckBox
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents txtlato4 As System.Windows.Forms.TextBox
    Friend WithEvents txtlato3 As System.Windows.Forms.TextBox
    Friend WithEvents txtaltezza As System.Windows.Forms.TextBox
    Friend WithEvents txtbase As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents chkscaleno As System.Windows.Forms.CheckBox
    Friend WithEvents chkisoscele As System.Windows.Forms.CheckBox
    Friend WithEvents chkequilatero As System.Windows.Forms.CheckBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents lblarea1 As System.Windows.Forms.Label
    Friend WithEvents lblperimetro2 As System.Windows.Forms.Label
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents lblarea2 As System.Windows.Forms.Label
    Friend WithEvents lblperimetro3 As System.Windows.Forms.Label
    Friend WithEvents lbldiagonale2 As System.Windows.Forms.Label
    Friend WithEvents txtlatoobliquo2 As System.Windows.Forms.TextBox
    Friend WithEvents txtlatoobliquo1 As System.Windows.Forms.TextBox
    Friend WithEvents txttaltezza As System.Windows.Forms.TextBox
    Friend WithEvents txtbaseminore As System.Windows.Forms.TextBox
    Friend WithEvents txtbasemaggiore As System.Windows.Forms.TextBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents chktrettangolo As System.Windows.Forms.CheckBox
    Friend WithEvents chktisoscele As System.Windows.Forms.CheckBox
    Friend WithEvents chktrapezio As System.Windows.Forms.CheckBox
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents btnstampa As System.Windows.Forms.Button
    Friend WithEvents PrintForm1 As Microsoft.VisualBasic.Devices.ComputerInfo
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents txtlatopoligono As System.Windows.Forms.TextBox
    Friend WithEvents lbldecagono As System.Windows.Forms.Label
    Friend WithEvents lblennagono As System.Windows.Forms.Label
    Friend WithEvents lblottagono As System.Windows.Forms.Label
    Friend WithEvents lblettagono As System.Windows.Forms.Label
    Friend WithEvents lblesagono As System.Windows.Forms.Label
    Friend WithEvents lblpentagono As System.Windows.Forms.Label
    Friend WithEvents lblquadrato As System.Windows.Forms.Label
    Friend WithEvents lbltriangolo As System.Windows.Forms.Label
    Friend WithEvents chkdecagono As System.Windows.Forms.CheckBox
    Friend WithEvents chkennagono As System.Windows.Forms.CheckBox
    Friend WithEvents chkottagono As System.Windows.Forms.CheckBox
    Friend WithEvents chkettagono As System.Windows.Forms.CheckBox
    Friend WithEvents chkesagono As System.Windows.Forms.CheckBox
    Friend WithEvents chkpentagono As System.Windows.Forms.CheckBox
    Friend WithEvents chkquadrato1 As System.Windows.Forms.CheckBox
    Friend WithEvents chktriangolo As System.Windows.Forms.CheckBox
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents txtnumerolati As System.Windows.Forms.TextBox
    Friend WithEvents lblareapoligono As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents lblperimetropoligono As System.Windows.Forms.Label
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents btncerchio As System.Windows.Forms.Button
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents btncancelladati As System.Windows.Forms.Button
    Friend WithEvents lbllunghezzaarco As System.Windows.Forms.Label
    Friend WithEvents lblareacirconferenza As System.Windows.Forms.Label
    Friend WithEvents lblcirconferenza As System.Windows.Forms.Label
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents txtraggioesterno As System.Windows.Forms.TextBox
    Friend WithEvents txtraggiointerno As System.Windows.Forms.TextBox
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents txtarco As System.Windows.Forms.TextBox
    Friend WithEvents txtangolo As System.Windows.Forms.TextBox
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents chkcorona As System.Windows.Forms.CheckBox
    Friend WithEvents chksettorecircolare As System.Windows.Forms.CheckBox
    Friend WithEvents chkcirconferenza As System.Windows.Forms.CheckBox
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents txtraggio As System.Windows.Forms.TextBox
    Friend WithEvents lblsettore As System.Windows.Forms.Label
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents lblcorona As System.Windows.Forms.Label
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents lblperimetrocorona As System.Windows.Forms.Label
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents lblperimetrorombo As System.Windows.Forms.Label
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents lblarearombo As System.Windows.Forms.Label
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents lbllato As System.Windows.Forms.Label
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents txtdiagonale2 As System.Windows.Forms.TextBox
    Friend WithEvents txtdiagonale1 As System.Windows.Forms.TextBox
    Friend WithEvents chkellisse As System.Windows.Forms.CheckBox
    Friend WithEvents chkrombo As System.Windows.Forms.CheckBox
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents lblperimetroellisse As System.Windows.Forms.Label
    Friend WithEvents lblareaellisse As System.Windows.Forms.Label
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents txtsemiassemaggiore As System.Windows.Forms.TextBox
    Friend WithEvents txtsemiasseminore As System.Windows.Forms.TextBox
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents PrintForm2 As PowerPacks.Printing.PrintForm
    Friend WithEvents Button10 As Button
    Friend WithEvents CheckBox2 As CheckBox
    Friend WithEvents CheckBox1 As CheckBox
End Class
