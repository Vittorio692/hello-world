﻿Imports System.Drawing.Printing

Public Class Form1

    'Area e perimetri rettangolo - quadrato
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim lato1 As Double
        Dim lato2 As Double
        Dim risultato As Double
        Dim perimetro As Double
        Dim area As Double
        Dim perimetro1 As Double
        Dim diagonale As Double
        Dim diagonale1 As Double
        Double.TryParse(txtlato1.Text, lato1)
        Double.TryParse(txtlato2.Text, lato2)
        If chkrettangolo.Checked = True Then
            risultato = lato1 * lato2
            perimetro = 2 * (lato1 + lato2)
            lblrisultato.Text = risultato.ToString("N2")
            lblperimetro.Text = perimetro.ToString("N2")
            diagonale = Math.Sqrt(lato1 ^ 2 + lato2 ^ 2)
            lbldiagonale.Text = diagonale.ToString("N2")
        End If
        If chkquadrato.Checked = True Then
            area = lato1 ^ 2
            perimetro1 = lato1 * 4
            lblarea.Text = area.ToString("N2")
            lblperimetro1.Text = perimetro1.ToString("N2")
            diagonale1 = Math.Sqrt(2) * lato1
            lbldiagonale1.Text = diagonale1.ToString("N2")
        End If
    End Sub

    Private Sub btncancella_Click(sender As Object, e As EventArgs) Handles btncancella.Click
        txtlato1.Clear()
        txtlato2.Clear()
        lblrisultato.Text = String.Empty
        lblperimetro.Text = String.Empty
        lbldiagonale.Text = String.Empty
        lblarea.Text = String.Empty
        lblperimetro1.Text = String.Empty
        lbldiagonale1.Text = String.Empty
        chkrettangolo.Checked = False
        chkquadrato.Checked = False
        txtlato1.Focus()
    End Sub

    'Area e perimetri triangoli
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim base As Double
        Dim lato3 As Double
        Dim lato4 As Double
        Dim altezza As Double
        Dim perimetro2 As Double
        Dim area1 As Double
        Double.TryParse(txtbase.Text, base)
        Double.TryParse(txtlato3.Text, lato3)
        Double.TryParse(txtlato4.Text, lato4)
        Double.TryParse(txtaltezza.Text, altezza)
        'Equilatero
        If chkequilatero.Checked = True Then
            perimetro2 = base + base + base
            area1 = (base * altezza) / 2
            lblperimetro2.Text = perimetro2.ToString("N2")
            lblarea1.Text = area1.ToString("N2")
        End If
        'Isoscele
        If chkisoscele.Checked = True Then
            perimetro2 = base + (lato3 * 2)
            area1 = (base * altezza) / 2
            lblperimetro2.Text = perimetro2.ToString("N2")
            lblarea1.Text = area1.ToString("N2")
        End If
        'Scaleno
        If chkscaleno.Checked = True Then
            perimetro2 = base + lato3 + lato4
            area1 = (base * altezza) / 2
            lblperimetro2.Text = perimetro2.ToString("N2")
            lblarea1.Text = area1.ToString("N2")
        End If
    End Sub


    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        txtbase.Clear()
        txtlato3.Clear()
        txtlato4.Clear()
        txtaltezza.Clear()
        lblperimetro2.Text = String.Empty
        lblarea1.Text = String.Empty
        chkequilatero.Checked = False
        chkisoscele.Checked = False
        chkscaleno.Checked = False
        txtbase.Focus()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim basemaggiore As Double
        Dim baseminore As Double
        Dim taltezza As Double
        Dim latoobliquo1 As Double
        Dim latoobliquo2 As Double
        Dim diagonale2 As Double
        Dim perimetro3 As Double
        Dim area2 As Double
        Double.TryParse(txtbasemaggiore.Text, basemaggiore)
        Double.TryParse(txtbaseminore.Text, baseminore)
        Double.TryParse(txttaltezza.Text, taltezza)
        Double.TryParse(txtlatoobliquo1.Text, latoobliquo1)
        Double.TryParse(txtlatoobliquo2.Text, latoobliquo2)
        'Trapezio
        If chktrapezio.Checked = True Then
            perimetro3 = basemaggiore + baseminore + latoobliquo1 + latoobliquo2
            area2 = ((basemaggiore + baseminore) * taltezza) / 2
            diagonale2 = Math.Sqrt((taltezza ^ 2 + (basemaggiore + baseminore / 2) ^ 2))
            lblperimetro3.Text = perimetro3.ToString("N2")
            lblarea2.Text = area2.ToString("N2")
            lbldiagonale2.Text = diagonale2.ToString("N2")
        End If
        'Trapezio isoscele
        If chktisoscele.Checked = True Then
            perimetro3 = basemaggiore + baseminore + 2 * (latoobliquo1)
            area2 = ((basemaggiore + baseminore) * taltezza) / 2
            diagonale2 = Math.Sqrt((taltezza ^ 2 + (basemaggiore + baseminore / 2) ^ 2))
            lblperimetro3.Text = perimetro3.ToString("N2")
            lblarea2.Text = area2.ToString("N2")
            lbldiagonale2.Text = diagonale2.ToString("N2")
        End If
        'Trapezio rettangolo
        If chktrettangolo.Checked = True Then
            perimetro3 = basemaggiore + baseminore + taltezza + latoobliquo1
            area2 = ((basemaggiore + baseminore) * taltezza) / 2
            diagonale2 = Math.Sqrt(taltezza ^ 2 + basemaggiore ^ 2)
            lblperimetro3.Text = perimetro3.ToString("N2")
            lblarea2.Text = area2.ToString("N2")
            lbldiagonale2.Text = diagonale2.ToString("N2")
        End If
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        txtbasemaggiore.Clear()
        txtbaseminore.Clear()
        txttaltezza.Clear()
        txtlatoobliquo1.Clear()
        txtlatoobliquo2.Clear()
        lblperimetro3.Text = String.Empty
        lblarea2.Text = String.Empty
        lbldiagonale2.Text = String.Empty
        chktrapezio.Checked = False
        chktisoscele.Checked = False
        chktrettangolo.Checked = False
        txtbasemaggiore.Focus()
    End Sub



    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles txtlatopoligono.TextChanged

    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Dim latopoligono As Double
        Dim numerolati As Double
        Dim areapoligono As Double
        Dim perimetropoligono As Double
        Dim triangolo As Double
        Dim quadrato As Double
        Dim pentagono As Double
        Dim esagono As Double
        Dim ettagono As Double
        Dim ottagono As Double
        Dim ennagono As Double
        Dim decagono As Double
        Double.TryParse(txtlatopoligono.Text, latopoligono)
        Double.TryParse(txtnumerolati.Text, numerolati)
        'Poligoni regolari
        If chktriangolo.Checked = True Then
            areapoligono = (latopoligono ^ 2) * 0.433
            perimetropoligono = numerolati * latopoligono
            triangolo = (latopoligono ^ 2) * 0.433
            lblperimetropoligono.Text = perimetropoligono.ToString("N2")
            lblareapoligono.Text = areapoligono.ToString("N2")
            lbltriangolo.Text = triangolo.ToString("N2")
        End If
        If chkquadrato1.Checked = True Then
            areapoligono = (latopoligono ^ 2) * 1
            perimetropoligono = numerolati * latopoligono
            quadrato = (latopoligono ^ 2) * 1
            lblperimetropoligono.Text = perimetropoligono.ToString("N2")
            lblareapoligono.Text = areapoligono.ToString("N2")
            lblquadrato.Text = quadrato.ToString("N2")
        End If
        If chkpentagono.Checked = True Then
            areapoligono = (latopoligono ^ 2) * 1.72
            perimetropoligono = numerolati * latopoligono
            pentagono = (latopoligono ^ 2) * 1.72
            lblperimetropoligono.Text = perimetropoligono.ToString("N2")
            lblareapoligono.Text = areapoligono.ToString("N2")
            lblpentagono.Text = pentagono.ToString("N2")
        End If
        If chkesagono.Checked = True Then
            areapoligono = (latopoligono ^ 2) * 2.598
            perimetropoligono = numerolati * latopoligono
            esagono = (latopoligono ^ 2) * 2.598
            lblperimetropoligono.Text = perimetropoligono.ToString("N2")
            lblareapoligono.Text = areapoligono.ToString("N2")
            lblesagono.Text = esagono.ToString("N2")
        End If
        If chkettagono.Checked = True Then
            areapoligono = (latopoligono ^ 2) * 3.634
            perimetropoligono = numerolati * latopoligono
            ettagono = (latopoligono ^ 2) * 3.634
            lblperimetropoligono.Text = perimetropoligono.ToString("N2")
            lblareapoligono.Text = areapoligono.ToString("N2")
            lblettagono.Text = ettagono.ToString("N2")
        End If
        If chkottagono.Checked = True Then
            areapoligono = (latopoligono ^ 2) * 4.828
            perimetropoligono = numerolati * latopoligono
            ottagono = (latopoligono ^ 2) * 4.828
            lblperimetropoligono.Text = perimetropoligono.ToString("N2")
            lblareapoligono.Text = areapoligono.ToString("N2")
            lblottagono.Text = ottagono.ToString("N2")
        End If
        If chkennagono.Checked = True Then
            areapoligono = (latopoligono ^ 2) * 6.182
            perimetropoligono = numerolati * latopoligono
            ennagono = (latopoligono ^ 2) * 6.182
            lblperimetropoligono.Text = perimetropoligono.ToString("N2")
            lblareapoligono.Text = areapoligono.ToString("N2")
            lblennagono.Text = ennagono.ToString("N2")
        End If
        If chkdecagono.Checked = True Then
            areapoligono = (latopoligono ^ 2) * 7.694
            perimetropoligono = numerolati * latopoligono
            decagono = (latopoligono ^ 2) * 7.694
            lblperimetropoligono.Text = perimetropoligono.ToString("N2")
            lblareapoligono.Text = areapoligono.ToString("N2")
            lbldecagono.Text = decagono.ToString("N2")
        End If
    End Sub

    Private Sub btncerchio_Click(sender As Object, e As EventArgs) Handles btncerchio.Click
        Dim raggio As Double
        Dim angolo As Double
        Dim arco As Double
        Dim raggiointerno As Double
        Dim raggioesterno As Double
        Dim circonferenza As Double
        Dim areacirconferenza As Double
        Dim lunghezzaarco As Double
        Dim settore As Double
        Dim corona As Double
        Dim perimetrocorona As Double
        Double.TryParse(txtraggio.Text, raggio)
        Double.TryParse(txtangolo.Text, angolo)
        Double.TryParse(txtarco.Text, arco)
        Double.TryParse(txtraggiointerno.Text, raggiointerno)
        Double.TryParse(txtraggioesterno.Text, raggioesterno)
        If chkcirconferenza.Checked = True Then
            circonferenza = 2 * 3.14 * raggio
            areacirconferenza = 3.14 * (raggio ^ 2)
            lblcirconferenza.Text = circonferenza.ToString("N2")
            lblareacirconferenza.Text = areacirconferenza.ToString("N2")
        End If
        If chksettorecircolare.Checked = True Then
            settore = ((3.14 * (raggio ^ 2) * angolo)) / 360
            lunghezzaarco = (3.14 * raggio * angolo) / 180
            lblsettore.Text = settore.ToString("N2")
            lbllunghezzaarco.Text = lunghezzaarco.ToString("N2")
        End If
        If chkcorona.Checked = True Then
            perimetrocorona = 2 * 3.14 * (raggioesterno + raggiointerno)
            corona = 3.14 * (raggioesterno ^ 2 - raggiointerno ^ 2)
            lblperimetrocorona.Text = perimetrocorona.ToString("N2")
            lblcorona.Text = corona.ToString("N2")
        End If

    End Sub

    Private Sub btncancelladati_Click(sender As Object, e As EventArgs) Handles btncancelladati.Click
        txtraggio.Clear()
        txtangolo.Clear()
        txtarco.Clear()
        txtraggioesterno.Clear()
        txtraggiointerno.Clear()
        lblcirconferenza.Text = String.Empty
        lblareacirconferenza.Text = String.Empty
        lblsettore.Text = String.Empty
        lbllunghezzaarco.Text = String.Empty
        lblperimetrocorona.Text = String.Empty
        lblcorona.Text = String.Empty
        chkcirconferenza.Checked = False
        chksettorecircolare.Checked = False
        chkcorona.Checked = False
        txtraggio.Focus()
    End Sub



    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        txtlatopoligono.Clear()
        txtnumerolati.Clear()
        lblperimetropoligono.Text = String.Empty
        lblareapoligono.Text = String.Empty
        lbltriangolo.Text = String.Empty
        lblquadrato.Text = String.Empty
        lblpentagono.Text = String.Empty
        lblesagono.Text = String.Empty
        lblettagono.Text = String.Empty
        lblottagono.Text = String.Empty
        lblennagono.Text = String.Empty
        lbldecagono.Text = String.Empty
        chktriangolo.Checked = False
        chkquadrato1.Checked = False
        chkpentagono.Checked = False
        chkesagono.Checked = False
        chkettagono.Checked = False
        chkottagono.Checked = False
        chkennagono.Checked = False
        chkdecagono.Checked = False
        txtlatopoligono.Focus()
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        txtdiagonale1.Clear()
        txtdiagonale2.Clear()
        txtsemiassemaggiore.Clear()
        txtsemiasseminore.Clear()
        lblperimetrorombo.Text = String.Empty
        lblarearombo.Text = String.Empty
        lbllato.Text = String.Empty
        lblareaellisse.Text = String.Empty
        lblperimetroellisse.Text = String.Empty
        CheckBox1.Checked = False
        CheckBox2.Checked = False
        txtdiagonale1.Focus()
    End Sub

    Private Sub btnstampa_Click(sender As Object, e As EventArgs) Handles btnstampa.Click
        PrintForm2.PrintAction = Printing.PrintAction.PrintToPreview
        PrintForm2.Print()
    End Sub

    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        If CheckBox1.Checked = True Then
            Dim diagonale1 As Double
            Dim diagonale2 As Double
            Dim diag1 As Double
            Dim diag2 As Double
            Dim arearombo As Double
            Dim lato As Double
            Dim perimetrorombo As Double
            Double.TryParse(txtdiagonale1.Text, diagonale1)
            Double.TryParse(txtdiagonale2.Text, diagonale2)
            diag1 = (diagonale1 / 2) ^ 2
            diag2 = (diagonale2 / 2) ^ 2
            lato = Math.Sqrt((diag1) + (diag2))
            arearombo = (diagonale1 * diagonale2) / 2
            perimetrorombo = lato * 4
            lblperimetrorombo.Text = perimetrorombo.ToString("N2")
            lblarearombo.Text = arearombo.ToString("N2")
            lbllato.Text = lato.ToString("N2")
        End If
        If CheckBox2.Checked = True Then
            Dim semiasseminore As Double
            Dim semiassemaggiore As Double
            Dim areaellisse As Double
            Dim perimetroellisse As Double
            Double.TryParse(txtsemiasseminore.Text, semiasseminore)
            Double.TryParse(txtsemiassemaggiore.Text, semiassemaggiore)
            areaellisse = 3.14 * semiassemaggiore * semiasseminore
            perimetroellisse = 2 * 3.14 * Math.Sqrt(semiassemaggiore + semiasseminore) / 2
            lblareaellisse.Text = areaellisse.ToString("N2")
            lblperimetroellisse.Text = perimetroellisse.ToString("N2")
        End If
    End Sub
End Class
