﻿namespace Stima_comparativa_prospetto_A
{
    partial class Form1
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.Label88 = new System.Windows.Forms.Label();
            this.Label79 = new System.Windows.Forms.Label();
            this.btncancella4 = new System.Windows.Forms.Button();
            this.txtman4sogg = new System.Windows.Forms.TextBox();
            this.txtscc4sogg = new System.Windows.Forms.TextBox();
            this.txtagg43 = new System.Windows.Forms.TextBox();
            this.txtprzmarg43 = new System.Windows.Forms.TextBox();
            this.txtdiffcar43 = new System.Windows.Forms.TextBox();
            this.txtpass43 = new System.Windows.Forms.TextBox();
            this.txtspunit10car43 = new System.Windows.Forms.TextBox();
            this.txtman43 = new System.Windows.Forms.TextBox();
            this.txtscc43 = new System.Windows.Forms.TextBox();
            this.txtprzcar43 = new System.Windows.Forms.TextBox();
            this.Label89 = new System.Windows.Forms.Label();
            this.Label81 = new System.Windows.Forms.Label();
            this.btncancella5 = new System.Windows.Forms.Button();
            this.txtruvpcar5sogg = new System.Windows.Forms.TextBox();
            this.txtpuntcar5sogg = new System.Windows.Forms.TextBox();
            this.txtorientcar5sogg = new System.Windows.Forms.TextBox();
            this.txtagg53 = new System.Windows.Forms.TextBox();
            this.txtdiff53 = new System.Windows.Forms.TextBox();
            this.txtorient53 = new System.Windows.Forms.TextBox();
            this.txtruvpcar53 = new System.Windows.Forms.TextBox();
            this.txtrupncar53 = new System.Windows.Forms.TextBox();
            this.txtKcar53 = new System.Windows.Forms.TextBox();
            this.Panel5 = new System.Windows.Forms.Panel();
            this.txtrvpocar53 = new System.Windows.Forms.TextBox();
            this.txtpuntcar53 = new System.Windows.Forms.TextBox();
            this.txtorientcar53 = new System.Windows.Forms.TextBox();
            this.txtprunitcar53 = new System.Windows.Forms.TextBox();
            this.txtagg52 = new System.Windows.Forms.TextBox();
            this.txtdiff52 = new System.Windows.Forms.TextBox();
            this.txtorient52 = new System.Windows.Forms.TextBox();
            this.txtruvpcar52 = new System.Windows.Forms.TextBox();
            this.txtrupncar52 = new System.Windows.Forms.TextBox();
            this.txtKcar52 = new System.Windows.Forms.TextBox();
            this.txtrvpocar52 = new System.Windows.Forms.TextBox();
            this.txtpuntcar52 = new System.Windows.Forms.TextBox();
            this.txtorientcar52 = new System.Windows.Forms.TextBox();
            this.txtprunitcar52 = new System.Windows.Forms.TextBox();
            this.txtagg51 = new System.Windows.Forms.TextBox();
            this.txtdiff51 = new System.Windows.Forms.TextBox();
            this.txtorient51 = new System.Windows.Forms.TextBox();
            this.txtruvpcar51 = new System.Windows.Forms.TextBox();
            this.txtrupncar51 = new System.Windows.Forms.TextBox();
            this.txtKcar51 = new System.Windows.Forms.TextBox();
            this.txtrvpocar51 = new System.Windows.Forms.TextBox();
            this.txtpuntcar51 = new System.Windows.Forms.TextBox();
            this.txtorientcar51 = new System.Windows.Forms.TextBox();
            this.txtprunitcar51 = new System.Windows.Forms.TextBox();
            this.Calcola5 = new System.Windows.Forms.Button();
            this.Label23 = new System.Windows.Forms.Label();
            this.Label65 = new System.Windows.Forms.Label();
            this.Label66 = new System.Windows.Forms.Label();
            this.Label67 = new System.Windows.Forms.Label();
            this.Label68 = new System.Windows.Forms.Label();
            this.Label69 = new System.Windows.Forms.Label();
            this.Label70 = new System.Windows.Forms.Label();
            this.Label71 = new System.Windows.Forms.Label();
            this.Label72 = new System.Windows.Forms.Label();
            this.Label73 = new System.Windows.Forms.Label();
            this.Label74 = new System.Windows.Forms.Label();
            this.Label75 = new System.Windows.Forms.Label();
            this.Label76 = new System.Windows.Forms.Label();
            this.Label77 = new System.Windows.Forms.Label();
            this.Label80 = new System.Windows.Forms.Label();
            this.txtagg42 = new System.Windows.Forms.TextBox();
            this.txtprzmarg42 = new System.Windows.Forms.TextBox();
            this.txtdiffcar42 = new System.Windows.Forms.TextBox();
            this.txtpass42 = new System.Windows.Forms.TextBox();
            this.txtspunit10car42 = new System.Windows.Forms.TextBox();
            this.txtman41 = new System.Windows.Forms.TextBox();
            this.txtspunit10car41 = new System.Windows.Forms.TextBox();
            this.txtman42 = new System.Windows.Forms.TextBox();
            this.txtpass41 = new System.Windows.Forms.TextBox();
            this.txtprzcar42 = new System.Windows.Forms.TextBox();
            this.txtagg41 = new System.Windows.Forms.TextBox();
            this.txtprzmarg41 = new System.Windows.Forms.TextBox();
            this.txtdiffcar41 = new System.Windows.Forms.TextBox();
            this.txtscc42 = new System.Windows.Forms.TextBox();
            this.Panel2 = new System.Windows.Forms.Panel();
            this.Label86 = new System.Windows.Forms.Label();
            this.Label63 = new System.Windows.Forms.Label();
            this.btncancella2 = new System.Windows.Forms.Button();
            this.Label28 = new System.Windows.Forms.Label();
            this.txtsaggio = new System.Windows.Forms.TextBox();
            this.txtrendita2 = new System.Windows.Forms.TextBox();
            this.txtrendita1 = new System.Windows.Forms.TextBox();
            this.btnsaggio = new System.Windows.Forms.Button();
            this.txtsaggcarsogg = new System.Windows.Forms.TextBox();
            this.txtdatacarsogg = new System.Windows.Forms.TextBox();
            this.txtscccarsogg = new System.Windows.Forms.TextBox();
            this.txtagg23 = new System.Windows.Forms.TextBox();
            this.txtdiff23 = new System.Windows.Forms.TextBox();
            this.txtprzmarg23 = new System.Windows.Forms.TextBox();
            this.txtagg22 = new System.Windows.Forms.TextBox();
            this.txtdiff22 = new System.Windows.Forms.TextBox();
            this.txtprzmarg22 = new System.Windows.Forms.TextBox();
            this.txtagg21 = new System.Windows.Forms.TextBox();
            this.txtdiff21 = new System.Windows.Forms.TextBox();
            this.txtprzmarg21 = new System.Windows.Forms.TextBox();
            this.txtsaggcar23 = new System.Windows.Forms.TextBox();
            this.txtsaggcar22 = new System.Windows.Forms.TextBox();
            this.txtsaggcar21 = new System.Windows.Forms.TextBox();
            this.txtdatacar23 = new System.Windows.Forms.TextBox();
            this.txtdatacar22 = new System.Windows.Forms.TextBox();
            this.txtdatacar21 = new System.Windows.Forms.TextBox();
            this.txtscccar23 = new System.Windows.Forms.TextBox();
            this.txtscccar22 = new System.Windows.Forms.TextBox();
            this.txtscccar21 = new System.Windows.Forms.TextBox();
            this.txtprzcar23 = new System.Windows.Forms.TextBox();
            this.txtprzcar22 = new System.Windows.Forms.TextBox();
            this.txtprzcar21 = new System.Windows.Forms.TextBox();
            this.Label38 = new System.Windows.Forms.Label();
            this.Calcola2 = new System.Windows.Forms.Button();
            this.Label17 = new System.Windows.Forms.Label();
            this.Label18 = new System.Windows.Forms.Label();
            this.Label19 = new System.Windows.Forms.Label();
            this.Label20 = new System.Windows.Forms.Label();
            this.Label25 = new System.Windows.Forms.Label();
            this.Label26 = new System.Windows.Forms.Label();
            this.Label27 = new System.Windows.Forms.Label();
            this.Label29 = new System.Windows.Forms.Label();
            this.Label30 = new System.Windows.Forms.Label();
            this.Label31 = new System.Windows.Forms.Label();
            this.Label32 = new System.Windows.Forms.Label();
            this.btncancella6 = new System.Windows.Forms.Button();
            this.btncalcola6 = new System.Windows.Forms.Button();
            this.txtoprriass3 = new System.Windows.Forms.TextBox();
            this.txtmanutriass3 = new System.Windows.Forms.TextBox();
            this.txtprzldpriass3 = new System.Windows.Forms.TextBox();
            this.txtprzdatariass3 = new System.Windows.Forms.TextBox();
            this.txtsccriass3 = new System.Windows.Forms.TextBox();
            this.txtprzriass3 = new System.Windows.Forms.TextBox();
            this.txtoprriass2 = new System.Windows.Forms.TextBox();
            this.txtmanutriass2 = new System.Windows.Forms.TextBox();
            this.txtprzldpriass2 = new System.Windows.Forms.TextBox();
            this.txtprzdatariass2 = new System.Windows.Forms.TextBox();
            this.txtsccriass2 = new System.Windows.Forms.TextBox();
            this.txtprzriass2 = new System.Windows.Forms.TextBox();
            this.txtoprriass1 = new System.Windows.Forms.TextBox();
            this.txtmanutriass1 = new System.Windows.Forms.TextBox();
            this.txtprzldpriass1 = new System.Windows.Forms.TextBox();
            this.Panel6 = new System.Windows.Forms.Panel();
            this.txtprzdatariass1 = new System.Windows.Forms.TextBox();
            this.txtsccriass1 = new System.Windows.Forms.TextBox();
            this.txtprzriass1 = new System.Windows.Forms.TextBox();
            this.Label24 = new System.Windows.Forms.Label();
            this.Label82 = new System.Windows.Forms.Label();
            this.Label83 = new System.Windows.Forms.Label();
            this.Label84 = new System.Windows.Forms.Label();
            this.Label90 = new System.Windows.Forms.Label();
            this.Label91 = new System.Windows.Forms.Label();
            this.Label92 = new System.Windows.Forms.Label();
            this.Label93 = new System.Windows.Forms.Label();
            this.Label94 = new System.Windows.Forms.Label();
            this.Label95 = new System.Windows.Forms.Label();
            this.Label96 = new System.Windows.Forms.Label();
            this.txtscc41 = new System.Windows.Forms.TextBox();
            this.Label97 = new System.Windows.Forms.Label();
            this.Label85 = new System.Windows.Forms.Label();
            this.Label58 = new System.Windows.Forms.Label();
            this.Label54 = new System.Windows.Forms.Label();
            this.btncancella1 = new System.Windows.Forms.Button();
            this.txtprunitmax = new System.Windows.Forms.TextBox();
            this.txtprunitmin = new System.Windows.Forms.TextBox();
            this.Label37 = new System.Windows.Forms.Label();
            this.txtprzmcorrsogg = new System.Windows.Forms.TextBox();
            this.txtprzmcorr3 = new System.Windows.Forms.TextBox();
            this.txtprzmcorr2 = new System.Windows.Forms.TextBox();
            this.txtprzmcorr1 = new System.Windows.Forms.TextBox();
            this.txtprzcorr3 = new System.Windows.Forms.TextBox();
            this.txtprzcorr2 = new System.Windows.Forms.TextBox();
            this.txtAgg3 = new System.Windows.Forms.TextBox();
            this.txtAgg2 = new System.Windows.Forms.TextBox();
            this.txtAgg1 = new System.Windows.Forms.TextBox();
            this.txtdiff3 = new System.Windows.Forms.TextBox();
            this.txtdiff2 = new System.Windows.Forms.TextBox();
            this.txtpiano3 = new System.Windows.Forms.TextBox();
            this.Panel3 = new System.Windows.Forms.Panel();
            this.Label87 = new System.Windows.Forms.Label();
            this.Label78 = new System.Windows.Forms.Label();
            this.btncancella3 = new System.Windows.Forms.Button();
            this.txtpiano2 = new System.Windows.Forms.TextBox();
            this.txtpiano1 = new System.Windows.Forms.TextBox();
            this.txtprunitcar3arr3 = new System.Windows.Forms.TextBox();
            this.txtprunitcar3arr2 = new System.Windows.Forms.TextBox();
            this.txtprunitcar3arr1 = new System.Windows.Forms.TextBox();
            this.Label39 = new System.Windows.Forms.Label();
            this.txtsagrvupcar3sogg = new System.Windows.Forms.TextBox();
            this.txtlivccar3sogg = new System.Windows.Forms.TextBox();
            this.txtlivpcar3sogg = new System.Windows.Forms.TextBox();
            this.txtldpdiffcar33 = new System.Windows.Forms.TextBox();
            this.txtldpdiffcar32 = new System.Windows.Forms.TextBox();
            this.txtldpdiffcar31 = new System.Windows.Forms.TextBox();
            this.txtprzmargldpcar33 = new System.Windows.Forms.TextBox();
            this.txtprzmargldpcar32 = new System.Windows.Forms.TextBox();
            this.txtprzmargldpcar31 = new System.Windows.Forms.TextBox();
            this.txtsagrvupcar33 = new System.Windows.Forms.TextBox();
            this.txtsagrvupcar32 = new System.Windows.Forms.TextBox();
            this.txtsagrvupcar31 = new System.Windows.Forms.TextBox();
            this.txtrupncar33 = new System.Windows.Forms.TextBox();
            this.txtrupncar32 = new System.Windows.Forms.TextBox();
            this.txtrupncar31 = new System.Windows.Forms.TextBox();
            this.txtkcar33 = new System.Windows.Forms.TextBox();
            this.txtkcar32 = new System.Windows.Forms.TextBox();
            this.txtkcar31 = new System.Windows.Forms.TextBox();
            this.txtrvppcar33 = new System.Windows.Forms.TextBox();
            this.txtrvppcar32 = new System.Windows.Forms.TextBox();
            this.txtrvppcar31 = new System.Windows.Forms.TextBox();
            this.txtlivccar33 = new System.Windows.Forms.TextBox();
            this.txtlivccar32 = new System.Windows.Forms.TextBox();
            this.txtlivccar31 = new System.Windows.Forms.TextBox();
            this.txtlivpcar33 = new System.Windows.Forms.TextBox();
            this.txtlivpcar32 = new System.Windows.Forms.TextBox();
            this.txtlivpcar31 = new System.Windows.Forms.TextBox();
            this.txtprunitcar33 = new System.Windows.Forms.TextBox();
            this.txtprunitcar32 = new System.Windows.Forms.TextBox();
            this.txtprunitcar31 = new System.Windows.Forms.TextBox();
            this.Calcola3 = new System.Windows.Forms.Button();
            this.Label22 = new System.Windows.Forms.Label();
            this.Label21 = new System.Windows.Forms.Label();
            this.Label33 = new System.Windows.Forms.Label();
            this.Label34 = new System.Windows.Forms.Label();
            this.Label35 = new System.Windows.Forms.Label();
            this.Label36 = new System.Windows.Forms.Label();
            this.Label40 = new System.Windows.Forms.Label();
            this.Label41 = new System.Windows.Forms.Label();
            this.Label42 = new System.Windows.Forms.Label();
            this.Label43 = new System.Windows.Forms.Label();
            this.Label44 = new System.Windows.Forms.Label();
            this.Label45 = new System.Windows.Forms.Label();
            this.Label46 = new System.Windows.Forms.Label();
            this.Label47 = new System.Windows.Forms.Label();
            this.Label48 = new System.Windows.Forms.Label();
            this.txtprzcorr1 = new System.Windows.Forms.TextBox();
            this.Label59 = new System.Windows.Forms.Label();
            this.txtdiff1 = new System.Windows.Forms.TextBox();
            this.Panel1 = new System.Windows.Forms.Panel();
            this.txtprzmarg3 = new System.Windows.Forms.TextBox();
            this.txtprzmarg2 = new System.Windows.Forms.TextBox();
            this.txtprzmarg1 = new System.Windows.Forms.TextBox();
            this.txtrappos3 = new System.Windows.Forms.TextBox();
            this.txtrappos2 = new System.Windows.Forms.TextBox();
            this.txtrappos1 = new System.Windows.Forms.TextBox();
            this.txtmediap3 = new System.Windows.Forms.TextBox();
            this.txtmediap2 = new System.Windows.Forms.TextBox();
            this.txtmediap1 = new System.Windows.Forms.TextBox();
            this.txtprunit3arr = new System.Windows.Forms.TextBox();
            this.txtprunit2arr = new System.Windows.Forms.TextBox();
            this.txtprunit1arr = new System.Windows.Forms.TextBox();
            this.txtprunit3 = new System.Windows.Forms.TextBox();
            this.txtprunit2 = new System.Windows.Forms.TextBox();
            this.txtprunit1 = new System.Windows.Forms.TextBox();
            this.txtsccsogg = new System.Windows.Forms.TextBox();
            this.txtscc3 = new System.Windows.Forms.TextBox();
            this.txtscc2 = new System.Windows.Forms.TextBox();
            this.txtscc1 = new System.Windows.Forms.TextBox();
            this.txtprz3 = new System.Windows.Forms.TextBox();
            this.txtprz2 = new System.Windows.Forms.TextBox();
            this.txtprz1 = new System.Windows.Forms.TextBox();
            this.Calcola1 = new System.Windows.Forms.Button();
            this.Label16 = new System.Windows.Forms.Label();
            this.Label15 = new System.Windows.Forms.Label();
            this.Label14 = new System.Windows.Forms.Label();
            this.Label13 = new System.Windows.Forms.Label();
            this.Label12 = new System.Windows.Forms.Label();
            this.Label11 = new System.Windows.Forms.Label();
            this.Label10 = new System.Windows.Forms.Label();
            this.Label9 = new System.Windows.Forms.Label();
            this.Label8 = new System.Windows.Forms.Label();
            this.Label7 = new System.Windows.Forms.Label();
            this.Label6 = new System.Windows.Forms.Label();
            this.Label5 = new System.Windows.Forms.Label();
            this.Label4 = new System.Windows.Forms.Label();
            this.Label3 = new System.Windows.Forms.Label();
            this.Label2 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.txtprzcar41 = new System.Windows.Forms.TextBox();
            this.Calcola4 = new System.Windows.Forms.Button();
            this.Label49 = new System.Windows.Forms.Label();
            this.Label50 = new System.Windows.Forms.Label();
            this.Label51 = new System.Windows.Forms.Label();
            this.Panel4 = new System.Windows.Forms.Panel();
            this.Label52 = new System.Windows.Forms.Label();
            this.Label53 = new System.Windows.Forms.Label();
            this.Label55 = new System.Windows.Forms.Label();
            this.Label56 = new System.Windows.Forms.Label();
            this.Label57 = new System.Windows.Forms.Label();
            this.Label60 = new System.Windows.Forms.Label();
            this.Label61 = new System.Windows.Forms.Label();
            this.Label62 = new System.Windows.Forms.Label();
            this.Label64 = new System.Windows.Forms.Label();
            this.Panel5.SuspendLayout();
            this.Panel2.SuspendLayout();
            this.Panel6.SuspendLayout();
            this.Panel3.SuspendLayout();
            this.Panel1.SuspendLayout();
            this.Panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // Label88
            // 
            this.Label88.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.Label88.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label88.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label88.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label88.Location = new System.Drawing.Point(486, 175);
            this.Label88.Name = "Label88";
            this.Label88.Size = new System.Drawing.Size(16, 14);
            this.Label88.TabIndex = 83;
            this.Label88.Text = "9";
            // 
            // Label79
            // 
            this.Label79.BackColor = System.Drawing.Color.Yellow;
            this.Label79.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label79.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label79.Location = new System.Drawing.Point(488, 123);
            this.Label79.Name = "Label79";
            this.Label79.Size = new System.Drawing.Size(16, 14);
            this.Label79.TabIndex = 80;
            this.Label79.Text = "4";
            // 
            // btncancella4
            // 
            this.btncancella4.BackColor = System.Drawing.Color.Yellow;
            this.btncancella4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncancella4.ForeColor = System.Drawing.Color.Blue;
            this.btncancella4.Location = new System.Drawing.Point(495, 89);
            this.btncancella4.Name = "btncancella4";
            this.btncancella4.Size = new System.Drawing.Size(88, 31);
            this.btncancella4.TabIndex = 79;
            this.btncancella4.Text = "Cancella";
            this.btncancella4.UseVisualStyleBackColor = false;
            this.btncancella4.Click += new System.EventHandler(this.btncancella4_Click);
            // 
            // txtman4sogg
            // 
            this.txtman4sogg.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtman4sogg.ForeColor = System.Drawing.Color.Blue;
            this.txtman4sogg.Location = new System.Drawing.Point(488, 71);
            this.txtman4sogg.Multiline = true;
            this.txtman4sogg.Name = "txtman4sogg";
            this.txtman4sogg.Size = new System.Drawing.Size(95, 16);
            this.txtman4sogg.TabIndex = 10;
            // 
            // txtscc4sogg
            // 
            this.txtscc4sogg.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtscc4sogg.ForeColor = System.Drawing.Color.Blue;
            this.txtscc4sogg.Location = new System.Drawing.Point(488, 54);
            this.txtscc4sogg.Multiline = true;
            this.txtscc4sogg.Name = "txtscc4sogg";
            this.txtscc4sogg.Size = new System.Drawing.Size(95, 16);
            this.txtscc4sogg.TabIndex = 6;
            // 
            // txtagg43
            // 
            this.txtagg43.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtagg43.ForeColor = System.Drawing.Color.Blue;
            this.txtagg43.Location = new System.Drawing.Point(387, 173);
            this.txtagg43.Multiline = true;
            this.txtagg43.Name = "txtagg43";
            this.txtagg43.Size = new System.Drawing.Size(95, 16);
            this.txtagg43.TabIndex = 25;
            // 
            // txtprzmarg43
            // 
            this.txtprzmarg43.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprzmarg43.ForeColor = System.Drawing.Color.Blue;
            this.txtprzmarg43.Location = new System.Drawing.Point(387, 144);
            this.txtprzmarg43.Multiline = true;
            this.txtprzmarg43.Name = "txtprzmarg43";
            this.txtprzmarg43.Size = new System.Drawing.Size(95, 16);
            this.txtprzmarg43.TabIndex = 22;
            // 
            // txtdiffcar43
            // 
            this.txtdiffcar43.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtdiffcar43.ForeColor = System.Drawing.Color.Blue;
            this.txtdiffcar43.Location = new System.Drawing.Point(387, 120);
            this.txtdiffcar43.Multiline = true;
            this.txtdiffcar43.Name = "txtdiffcar43";
            this.txtdiffcar43.Size = new System.Drawing.Size(95, 16);
            this.txtdiffcar43.TabIndex = 19;
            // 
            // txtpass43
            // 
            this.txtpass43.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtpass43.ForeColor = System.Drawing.Color.Blue;
            this.txtpass43.Location = new System.Drawing.Point(387, 104);
            this.txtpass43.Multiline = true;
            this.txtpass43.Name = "txtpass43";
            this.txtpass43.Size = new System.Drawing.Size(95, 16);
            this.txtpass43.TabIndex = 16;
            // 
            // txtspunit10car43
            // 
            this.txtspunit10car43.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtspunit10car43.ForeColor = System.Drawing.Color.Blue;
            this.txtspunit10car43.Location = new System.Drawing.Point(387, 88);
            this.txtspunit10car43.Multiline = true;
            this.txtspunit10car43.Name = "txtspunit10car43";
            this.txtspunit10car43.Size = new System.Drawing.Size(95, 16);
            this.txtspunit10car43.TabIndex = 13;
            // 
            // txtman43
            // 
            this.txtman43.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtman43.ForeColor = System.Drawing.Color.Blue;
            this.txtman43.Location = new System.Drawing.Point(387, 71);
            this.txtman43.Multiline = true;
            this.txtman43.Name = "txtman43";
            this.txtman43.Size = new System.Drawing.Size(95, 16);
            this.txtman43.TabIndex = 9;
            // 
            // txtscc43
            // 
            this.txtscc43.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtscc43.ForeColor = System.Drawing.Color.Blue;
            this.txtscc43.Location = new System.Drawing.Point(387, 55);
            this.txtscc43.Multiline = true;
            this.txtscc43.Name = "txtscc43";
            this.txtscc43.Size = new System.Drawing.Size(95, 16);
            this.txtscc43.TabIndex = 5;
            // 
            // txtprzcar43
            // 
            this.txtprzcar43.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprzcar43.ForeColor = System.Drawing.Color.Blue;
            this.txtprzcar43.Location = new System.Drawing.Point(387, 36);
            this.txtprzcar43.Multiline = true;
            this.txtprzcar43.Name = "txtprzcar43";
            this.txtprzcar43.Size = new System.Drawing.Size(95, 16);
            this.txtprzcar43.TabIndex = 2;
            // 
            // Label89
            // 
            this.Label89.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.Label89.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label89.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label89.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label89.Location = new System.Drawing.Point(472, 206);
            this.Label89.Name = "Label89";
            this.Label89.Size = new System.Drawing.Size(22, 14);
            this.Label89.TabIndex = 84;
            this.Label89.Text = "10";
            // 
            // Label81
            // 
            this.Label81.BackColor = System.Drawing.Color.Yellow;
            this.Label81.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label81.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label81.Location = new System.Drawing.Point(472, 190);
            this.Label81.Name = "Label81";
            this.Label81.Size = new System.Drawing.Size(16, 14);
            this.Label81.TabIndex = 82;
            this.Label81.Text = "5";
            // 
            // btncancella5
            // 
            this.btncancella5.BackColor = System.Drawing.Color.Yellow;
            this.btncancella5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncancella5.ForeColor = System.Drawing.Color.Blue;
            this.btncancella5.Location = new System.Drawing.Point(494, 93);
            this.btncancella5.Name = "btncancella5";
            this.btncancella5.Size = new System.Drawing.Size(90, 31);
            this.btncancella5.TabIndex = 81;
            this.btncancella5.Text = "Cancella";
            this.btncancella5.UseVisualStyleBackColor = false;
            this.btncancella5.Click += new System.EventHandler(this.btncancella5_Click);
            // 
            // txtruvpcar5sogg
            // 
            this.txtruvpcar5sogg.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtruvpcar5sogg.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.txtruvpcar5sogg.Location = new System.Drawing.Point(494, 142);
            this.txtruvpcar5sogg.Multiline = true;
            this.txtruvpcar5sogg.Name = "txtruvpcar5sogg";
            this.txtruvpcar5sogg.Size = new System.Drawing.Size(93, 16);
            this.txtruvpcar5sogg.TabIndex = 23;
            // 
            // txtpuntcar5sogg
            // 
            this.txtpuntcar5sogg.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtpuntcar5sogg.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.txtpuntcar5sogg.Location = new System.Drawing.Point(494, 62);
            this.txtpuntcar5sogg.Multiline = true;
            this.txtpuntcar5sogg.Name = "txtpuntcar5sogg";
            this.txtpuntcar5sogg.Size = new System.Drawing.Size(93, 16);
            this.txtpuntcar5sogg.TabIndex = 10;
            // 
            // txtorientcar5sogg
            // 
            this.txtorientcar5sogg.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtorientcar5sogg.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.txtorientcar5sogg.Location = new System.Drawing.Point(494, 46);
            this.txtorientcar5sogg.Multiline = true;
            this.txtorientcar5sogg.Name = "txtorientcar5sogg";
            this.txtorientcar5sogg.Size = new System.Drawing.Size(93, 16);
            this.txtorientcar5sogg.TabIndex = 6;
            // 
            // txtagg53
            // 
            this.txtagg53.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtagg53.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.txtagg53.Location = new System.Drawing.Point(379, 204);
            this.txtagg53.Multiline = true;
            this.txtagg53.Name = "txtagg53";
            this.txtagg53.Size = new System.Drawing.Size(87, 16);
            this.txtagg53.TabIndex = 32;
            // 
            // txtdiff53
            // 
            this.txtdiff53.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtdiff53.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.txtdiff53.Location = new System.Drawing.Point(379, 188);
            this.txtdiff53.Multiline = true;
            this.txtdiff53.Name = "txtdiff53";
            this.txtdiff53.Size = new System.Drawing.Size(87, 16);
            this.txtdiff53.TabIndex = 29;
            // 
            // txtorient53
            // 
            this.txtorient53.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtorient53.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.txtorient53.Location = new System.Drawing.Point(379, 172);
            this.txtorient53.Multiline = true;
            this.txtorient53.Name = "txtorient53";
            this.txtorient53.Size = new System.Drawing.Size(87, 16);
            this.txtorient53.TabIndex = 26;
            // 
            // txtruvpcar53
            // 
            this.txtruvpcar53.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtruvpcar53.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.txtruvpcar53.Location = new System.Drawing.Point(379, 140);
            this.txtruvpcar53.Multiline = true;
            this.txtruvpcar53.Name = "txtruvpcar53";
            this.txtruvpcar53.Size = new System.Drawing.Size(88, 16);
            this.txtruvpcar53.TabIndex = 22;
            // 
            // txtrupncar53
            // 
            this.txtrupncar53.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtrupncar53.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.txtrupncar53.Location = new System.Drawing.Point(379, 124);
            this.txtrupncar53.Multiline = true;
            this.txtrupncar53.Name = "txtrupncar53";
            this.txtrupncar53.Size = new System.Drawing.Size(88, 16);
            this.txtrupncar53.TabIndex = 19;
            // 
            // txtKcar53
            // 
            this.txtKcar53.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtKcar53.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.txtKcar53.Location = new System.Drawing.Point(379, 108);
            this.txtKcar53.Multiline = true;
            this.txtKcar53.Name = "txtKcar53";
            this.txtKcar53.Size = new System.Drawing.Size(88, 16);
            this.txtKcar53.TabIndex = 16;
            // 
            // Panel5
            // 
            this.Panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Panel5.Controls.Add(this.Label89);
            this.Panel5.Controls.Add(this.Label81);
            this.Panel5.Controls.Add(this.btncancella5);
            this.Panel5.Controls.Add(this.txtruvpcar5sogg);
            this.Panel5.Controls.Add(this.txtpuntcar5sogg);
            this.Panel5.Controls.Add(this.txtorientcar5sogg);
            this.Panel5.Controls.Add(this.txtagg53);
            this.Panel5.Controls.Add(this.txtdiff53);
            this.Panel5.Controls.Add(this.txtorient53);
            this.Panel5.Controls.Add(this.txtruvpcar53);
            this.Panel5.Controls.Add(this.txtrupncar53);
            this.Panel5.Controls.Add(this.txtKcar53);
            this.Panel5.Controls.Add(this.txtrvpocar53);
            this.Panel5.Controls.Add(this.txtpuntcar53);
            this.Panel5.Controls.Add(this.txtorientcar53);
            this.Panel5.Controls.Add(this.txtprunitcar53);
            this.Panel5.Controls.Add(this.txtagg52);
            this.Panel5.Controls.Add(this.txtdiff52);
            this.Panel5.Controls.Add(this.txtorient52);
            this.Panel5.Controls.Add(this.txtruvpcar52);
            this.Panel5.Controls.Add(this.txtrupncar52);
            this.Panel5.Controls.Add(this.txtKcar52);
            this.Panel5.Controls.Add(this.txtrvpocar52);
            this.Panel5.Controls.Add(this.txtpuntcar52);
            this.Panel5.Controls.Add(this.txtorientcar52);
            this.Panel5.Controls.Add(this.txtprunitcar52);
            this.Panel5.Controls.Add(this.txtagg51);
            this.Panel5.Controls.Add(this.txtdiff51);
            this.Panel5.Controls.Add(this.txtorient51);
            this.Panel5.Controls.Add(this.txtruvpcar51);
            this.Panel5.Controls.Add(this.txtrupncar51);
            this.Panel5.Controls.Add(this.txtKcar51);
            this.Panel5.Controls.Add(this.txtrvpocar51);
            this.Panel5.Controls.Add(this.txtpuntcar51);
            this.Panel5.Controls.Add(this.txtorientcar51);
            this.Panel5.Controls.Add(this.txtprunitcar51);
            this.Panel5.Controls.Add(this.Calcola5);
            this.Panel5.Controls.Add(this.Label23);
            this.Panel5.Controls.Add(this.Label65);
            this.Panel5.Controls.Add(this.Label66);
            this.Panel5.Controls.Add(this.Label67);
            this.Panel5.Controls.Add(this.Label68);
            this.Panel5.Controls.Add(this.Label69);
            this.Panel5.Controls.Add(this.Label70);
            this.Panel5.Controls.Add(this.Label71);
            this.Panel5.Controls.Add(this.Label72);
            this.Panel5.Controls.Add(this.Label73);
            this.Panel5.Controls.Add(this.Label74);
            this.Panel5.Controls.Add(this.Label75);
            this.Panel5.Controls.Add(this.Label76);
            this.Panel5.Controls.Add(this.Label77);
            this.Panel5.Controls.Add(this.Label80);
            this.Panel5.Location = new System.Drawing.Point(29, 496);
            this.Panel5.Name = "Panel5";
            this.Panel5.Size = new System.Drawing.Size(593, 252);
            this.Panel5.TabIndex = 25;
            // 
            // txtrvpocar53
            // 
            this.txtrvpocar53.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtrvpocar53.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.txtrvpocar53.Location = new System.Drawing.Point(378, 84);
            this.txtrvpocar53.Multiline = true;
            this.txtrvpocar53.Name = "txtrvpocar53";
            this.txtrvpocar53.Size = new System.Drawing.Size(89, 16);
            this.txtrvpocar53.TabIndex = 13;
            // 
            // txtpuntcar53
            // 
            this.txtpuntcar53.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtpuntcar53.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.txtpuntcar53.Location = new System.Drawing.Point(377, 62);
            this.txtpuntcar53.Multiline = true;
            this.txtpuntcar53.Name = "txtpuntcar53";
            this.txtpuntcar53.Size = new System.Drawing.Size(90, 16);
            this.txtpuntcar53.TabIndex = 9;
            // 
            // txtorientcar53
            // 
            this.txtorientcar53.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtorientcar53.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.txtorientcar53.Location = new System.Drawing.Point(377, 46);
            this.txtorientcar53.Multiline = true;
            this.txtorientcar53.Name = "txtorientcar53";
            this.txtorientcar53.Size = new System.Drawing.Size(90, 16);
            this.txtorientcar53.TabIndex = 5;
            // 
            // txtprunitcar53
            // 
            this.txtprunitcar53.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprunitcar53.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.txtprunitcar53.Location = new System.Drawing.Point(377, 30);
            this.txtprunitcar53.Multiline = true;
            this.txtprunitcar53.Name = "txtprunitcar53";
            this.txtprunitcar53.Size = new System.Drawing.Size(90, 16);
            this.txtprunitcar53.TabIndex = 2;
            // 
            // txtagg52
            // 
            this.txtagg52.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtagg52.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.txtagg52.Location = new System.Drawing.Point(287, 204);
            this.txtagg52.Multiline = true;
            this.txtagg52.Name = "txtagg52";
            this.txtagg52.Size = new System.Drawing.Size(85, 16);
            this.txtagg52.TabIndex = 31;
            // 
            // txtdiff52
            // 
            this.txtdiff52.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtdiff52.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.txtdiff52.Location = new System.Drawing.Point(287, 188);
            this.txtdiff52.Multiline = true;
            this.txtdiff52.Name = "txtdiff52";
            this.txtdiff52.Size = new System.Drawing.Size(85, 16);
            this.txtdiff52.TabIndex = 28;
            // 
            // txtorient52
            // 
            this.txtorient52.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtorient52.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.txtorient52.Location = new System.Drawing.Point(287, 172);
            this.txtorient52.Multiline = true;
            this.txtorient52.Name = "txtorient52";
            this.txtorient52.Size = new System.Drawing.Size(85, 16);
            this.txtorient52.TabIndex = 25;
            // 
            // txtruvpcar52
            // 
            this.txtruvpcar52.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtruvpcar52.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.txtruvpcar52.Location = new System.Drawing.Point(287, 140);
            this.txtruvpcar52.Multiline = true;
            this.txtruvpcar52.Name = "txtruvpcar52";
            this.txtruvpcar52.Size = new System.Drawing.Size(85, 16);
            this.txtruvpcar52.TabIndex = 21;
            // 
            // txtrupncar52
            // 
            this.txtrupncar52.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtrupncar52.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.txtrupncar52.Location = new System.Drawing.Point(287, 124);
            this.txtrupncar52.Multiline = true;
            this.txtrupncar52.Name = "txtrupncar52";
            this.txtrupncar52.Size = new System.Drawing.Size(85, 16);
            this.txtrupncar52.TabIndex = 18;
            // 
            // txtKcar52
            // 
            this.txtKcar52.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtKcar52.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.txtKcar52.Location = new System.Drawing.Point(287, 108);
            this.txtKcar52.Multiline = true;
            this.txtKcar52.Name = "txtKcar52";
            this.txtKcar52.Size = new System.Drawing.Size(85, 16);
            this.txtKcar52.TabIndex = 15;
            // 
            // txtrvpocar52
            // 
            this.txtrvpocar52.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtrvpocar52.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.txtrvpocar52.Location = new System.Drawing.Point(286, 84);
            this.txtrvpocar52.Multiline = true;
            this.txtrvpocar52.Name = "txtrvpocar52";
            this.txtrvpocar52.Size = new System.Drawing.Size(85, 16);
            this.txtrvpocar52.TabIndex = 12;
            // 
            // txtpuntcar52
            // 
            this.txtpuntcar52.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtpuntcar52.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.txtpuntcar52.Location = new System.Drawing.Point(287, 62);
            this.txtpuntcar52.Multiline = true;
            this.txtpuntcar52.Name = "txtpuntcar52";
            this.txtpuntcar52.Size = new System.Drawing.Size(85, 16);
            this.txtpuntcar52.TabIndex = 8;
            // 
            // txtorientcar52
            // 
            this.txtorientcar52.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtorientcar52.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.txtorientcar52.Location = new System.Drawing.Point(287, 46);
            this.txtorientcar52.Multiline = true;
            this.txtorientcar52.Name = "txtorientcar52";
            this.txtorientcar52.Size = new System.Drawing.Size(85, 16);
            this.txtorientcar52.TabIndex = 4;
            // 
            // txtprunitcar52
            // 
            this.txtprunitcar52.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprunitcar52.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.txtprunitcar52.Location = new System.Drawing.Point(287, 30);
            this.txtprunitcar52.Multiline = true;
            this.txtprunitcar52.Name = "txtprunitcar52";
            this.txtprunitcar52.Size = new System.Drawing.Size(85, 16);
            this.txtprunitcar52.TabIndex = 1;
            // 
            // txtagg51
            // 
            this.txtagg51.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtagg51.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.txtagg51.Location = new System.Drawing.Point(196, 202);
            this.txtagg51.Multiline = true;
            this.txtagg51.Name = "txtagg51";
            this.txtagg51.Size = new System.Drawing.Size(85, 16);
            this.txtagg51.TabIndex = 30;
            // 
            // txtdiff51
            // 
            this.txtdiff51.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtdiff51.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.txtdiff51.Location = new System.Drawing.Point(196, 188);
            this.txtdiff51.Multiline = true;
            this.txtdiff51.Name = "txtdiff51";
            this.txtdiff51.Size = new System.Drawing.Size(85, 16);
            this.txtdiff51.TabIndex = 27;
            // 
            // txtorient51
            // 
            this.txtorient51.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtorient51.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.txtorient51.Location = new System.Drawing.Point(196, 172);
            this.txtorient51.Multiline = true;
            this.txtorient51.Name = "txtorient51";
            this.txtorient51.Size = new System.Drawing.Size(85, 16);
            this.txtorient51.TabIndex = 24;
            // 
            // txtruvpcar51
            // 
            this.txtruvpcar51.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtruvpcar51.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.txtruvpcar51.Location = new System.Drawing.Point(196, 138);
            this.txtruvpcar51.Multiline = true;
            this.txtruvpcar51.Name = "txtruvpcar51";
            this.txtruvpcar51.Size = new System.Drawing.Size(85, 16);
            this.txtruvpcar51.TabIndex = 20;
            // 
            // txtrupncar51
            // 
            this.txtrupncar51.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtrupncar51.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.txtrupncar51.Location = new System.Drawing.Point(196, 124);
            this.txtrupncar51.Multiline = true;
            this.txtrupncar51.Name = "txtrupncar51";
            this.txtrupncar51.Size = new System.Drawing.Size(85, 16);
            this.txtrupncar51.TabIndex = 17;
            // 
            // txtKcar51
            // 
            this.txtKcar51.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtKcar51.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.txtKcar51.Location = new System.Drawing.Point(196, 108);
            this.txtKcar51.Multiline = true;
            this.txtKcar51.Name = "txtKcar51";
            this.txtKcar51.Size = new System.Drawing.Size(85, 16);
            this.txtKcar51.TabIndex = 14;
            // 
            // txtrvpocar51
            // 
            this.txtrvpocar51.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtrvpocar51.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.txtrvpocar51.Location = new System.Drawing.Point(196, 84);
            this.txtrvpocar51.Multiline = true;
            this.txtrvpocar51.Name = "txtrvpocar51";
            this.txtrvpocar51.Size = new System.Drawing.Size(85, 16);
            this.txtrvpocar51.TabIndex = 11;
            // 
            // txtpuntcar51
            // 
            this.txtpuntcar51.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtpuntcar51.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.txtpuntcar51.Location = new System.Drawing.Point(195, 62);
            this.txtpuntcar51.Multiline = true;
            this.txtpuntcar51.Name = "txtpuntcar51";
            this.txtpuntcar51.Size = new System.Drawing.Size(85, 16);
            this.txtpuntcar51.TabIndex = 7;
            // 
            // txtorientcar51
            // 
            this.txtorientcar51.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtorientcar51.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.txtorientcar51.Location = new System.Drawing.Point(195, 46);
            this.txtorientcar51.Multiline = true;
            this.txtorientcar51.Name = "txtorientcar51";
            this.txtorientcar51.Size = new System.Drawing.Size(85, 16);
            this.txtorientcar51.TabIndex = 3;
            // 
            // txtprunitcar51
            // 
            this.txtprunitcar51.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprunitcar51.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.txtprunitcar51.Location = new System.Drawing.Point(195, 30);
            this.txtprunitcar51.Multiline = true;
            this.txtprunitcar51.Name = "txtprunitcar51";
            this.txtprunitcar51.Size = new System.Drawing.Size(85, 16);
            this.txtprunitcar51.TabIndex = 0;
            // 
            // Calcola5
            // 
            this.Calcola5.BackColor = System.Drawing.Color.Yellow;
            this.Calcola5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Calcola5.ForeColor = System.Drawing.Color.Blue;
            this.Calcola5.Location = new System.Drawing.Point(494, 162);
            this.Calcola5.Name = "Calcola5";
            this.Calcola5.Size = new System.Drawing.Size(95, 53);
            this.Calcola5.TabIndex = 17;
            this.Calcola5.Text = "Calcola";
            this.Calcola5.UseVisualStyleBackColor = false;
            this.Calcola5.Click += new System.EventHandler(this.Calcola5_Click);
            // 
            // Label23
            // 
            this.Label23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label23.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label23.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label23.Location = new System.Drawing.Point(6, 140);
            this.Label23.Name = "Label23";
            this.Label23.Size = new System.Drawing.Size(184, 16);
            this.Label23.TabIndex = 16;
            this.Label23.Text = "Rvup - saggio livello";
            // 
            // Label65
            // 
            this.Label65.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label65.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label65.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label65.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label65.Location = new System.Drawing.Point(488, 4);
            this.Label65.Name = "Label65";
            this.Label65.Size = new System.Drawing.Size(95, 16);
            this.Label65.TabIndex = 15;
            this.Label65.Text = "Soggetto";
            this.Label65.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label66
            // 
            this.Label66.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label66.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label66.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label66.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label66.Location = new System.Drawing.Point(375, 6);
            this.Label66.Name = "Label66";
            this.Label66.Size = new System.Drawing.Size(95, 16);
            this.Label66.TabIndex = 14;
            this.Label66.Text = "Comparabile 3";
            this.Label66.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label67
            // 
            this.Label67.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label67.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label67.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label67.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label67.Location = new System.Drawing.Point(286, 5);
            this.Label67.Name = "Label67";
            this.Label67.Size = new System.Drawing.Size(83, 16);
            this.Label67.TabIndex = 13;
            this.Label67.Text = "Comparabile 2";
            this.Label67.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label68
            // 
            this.Label68.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label68.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label68.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label68.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label68.Location = new System.Drawing.Point(196, 6);
            this.Label68.Name = "Label68";
            this.Label68.Size = new System.Drawing.Size(84, 16);
            this.Label68.TabIndex = 12;
            this.Label68.Text = "Comparabile 1";
            this.Label68.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label69
            // 
            this.Label69.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label69.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label69.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label69.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label69.Location = new System.Drawing.Point(4, 204);
            this.Label69.Name = "Label69";
            this.Label69.Size = new System.Drawing.Size(184, 16);
            this.Label69.TabIndex = 11;
            this.Label69.Text = "Aggiustamento orientamento";
            // 
            // Label70
            // 
            this.Label70.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label70.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label70.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label70.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label70.Location = new System.Drawing.Point(4, 188);
            this.Label70.Name = "Label70";
            this.Label70.Size = new System.Drawing.Size(184, 16);
            this.Label70.TabIndex = 10;
            this.Label70.Text = "Differenziale orientamento";
            // 
            // Label71
            // 
            this.Label71.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label71.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label71.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label71.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label71.Location = new System.Drawing.Point(4, 156);
            this.Label71.Name = "Label71";
            this.Label71.Size = new System.Drawing.Size(184, 32);
            this.Label71.TabIndex = 9;
            this.Label71.Text = "Prezzo marginale - orientamento OPR";
            // 
            // Label72
            // 
            this.Label72.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label72.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label72.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label72.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label72.Location = new System.Drawing.Point(6, 124);
            this.Label72.Name = "Label72";
            this.Label72.Size = new System.Drawing.Size(184, 16);
            this.Label72.TabIndex = 8;
            this.Label72.Text = "Rupn";
            // 
            // Label73
            // 
            this.Label73.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label73.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label73.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label73.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label73.Location = new System.Drawing.Point(6, 108);
            this.Label73.Name = "Label73";
            this.Label73.Size = new System.Drawing.Size(184, 16);
            this.Label73.TabIndex = 7;
            this.Label73.Text = "K";
            // 
            // Label74
            // 
            this.Label74.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label74.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label74.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label74.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label74.Location = new System.Drawing.Point(6, 78);
            this.Label74.Name = "Label74";
            this.Label74.Size = new System.Drawing.Size(184, 30);
            this.Label74.TabIndex = 6;
            this.Label74.Text = "Rvpo rapporto mercantile unitario immobili 1-2 e 2-3";
            // 
            // Label75
            // 
            this.Label75.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label75.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label75.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label75.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label75.Location = new System.Drawing.Point(6, 62);
            this.Label75.Name = "Label75";
            this.Label75.Size = new System.Drawing.Size(184, 16);
            this.Label75.TabIndex = 5;
            this.Label75.Text = "Punteggio";
            // 
            // Label76
            // 
            this.Label76.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label76.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label76.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label76.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label76.Location = new System.Drawing.Point(6, 46);
            this.Label76.Name = "Label76";
            this.Label76.Size = new System.Drawing.Size(184, 16);
            this.Label76.TabIndex = 4;
            this.Label76.Text = "Orientamento";
            // 
            // Label77
            // 
            this.Label77.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label77.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label77.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label77.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label77.Location = new System.Drawing.Point(6, 30);
            this.Label77.Name = "Label77";
            this.Label77.Size = new System.Drawing.Size(184, 16);
            this.Label77.TabIndex = 3;
            this.Label77.Text = "Prezzo unitario";
            // 
            // Label80
            // 
            this.Label80.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label80.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label80.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label80.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label80.Location = new System.Drawing.Point(6, 6);
            this.Label80.Name = "Label80";
            this.Label80.Size = new System.Drawing.Size(184, 24);
            this.Label80.TabIndex = 0;
            this.Label80.Text = "Caratteristica 5 : Orientamento prevalente";
            this.Label80.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtagg42
            // 
            this.txtagg42.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtagg42.ForeColor = System.Drawing.Color.Blue;
            this.txtagg42.Location = new System.Drawing.Point(286, 173);
            this.txtagg42.Multiline = true;
            this.txtagg42.Name = "txtagg42";
            this.txtagg42.Size = new System.Drawing.Size(95, 16);
            this.txtagg42.TabIndex = 24;
            // 
            // txtprzmarg42
            // 
            this.txtprzmarg42.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprzmarg42.ForeColor = System.Drawing.Color.Blue;
            this.txtprzmarg42.Location = new System.Drawing.Point(286, 145);
            this.txtprzmarg42.Multiline = true;
            this.txtprzmarg42.Name = "txtprzmarg42";
            this.txtprzmarg42.Size = new System.Drawing.Size(95, 16);
            this.txtprzmarg42.TabIndex = 21;
            // 
            // txtdiffcar42
            // 
            this.txtdiffcar42.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtdiffcar42.ForeColor = System.Drawing.Color.Blue;
            this.txtdiffcar42.Location = new System.Drawing.Point(286, 120);
            this.txtdiffcar42.Multiline = true;
            this.txtdiffcar42.Name = "txtdiffcar42";
            this.txtdiffcar42.Size = new System.Drawing.Size(95, 16);
            this.txtdiffcar42.TabIndex = 18;
            // 
            // txtpass42
            // 
            this.txtpass42.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtpass42.ForeColor = System.Drawing.Color.Blue;
            this.txtpass42.Location = new System.Drawing.Point(286, 103);
            this.txtpass42.Multiline = true;
            this.txtpass42.Name = "txtpass42";
            this.txtpass42.Size = new System.Drawing.Size(95, 16);
            this.txtpass42.TabIndex = 15;
            // 
            // txtspunit10car42
            // 
            this.txtspunit10car42.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtspunit10car42.ForeColor = System.Drawing.Color.Blue;
            this.txtspunit10car42.Location = new System.Drawing.Point(286, 88);
            this.txtspunit10car42.Multiline = true;
            this.txtspunit10car42.Name = "txtspunit10car42";
            this.txtspunit10car42.Size = new System.Drawing.Size(95, 16);
            this.txtspunit10car42.TabIndex = 12;
            // 
            // txtman41
            // 
            this.txtman41.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtman41.ForeColor = System.Drawing.Color.Blue;
            this.txtman41.Location = new System.Drawing.Point(196, 70);
            this.txtman41.Multiline = true;
            this.txtman41.Name = "txtman41";
            this.txtman41.Size = new System.Drawing.Size(84, 17);
            this.txtman41.TabIndex = 7;
            // 
            // txtspunit10car41
            // 
            this.txtspunit10car41.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtspunit10car41.ForeColor = System.Drawing.Color.Blue;
            this.txtspunit10car41.Location = new System.Drawing.Point(196, 87);
            this.txtspunit10car41.Multiline = true;
            this.txtspunit10car41.Name = "txtspunit10car41";
            this.txtspunit10car41.Size = new System.Drawing.Size(84, 17);
            this.txtspunit10car41.TabIndex = 11;
            // 
            // txtman42
            // 
            this.txtman42.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtman42.ForeColor = System.Drawing.Color.Blue;
            this.txtman42.Location = new System.Drawing.Point(286, 71);
            this.txtman42.Multiline = true;
            this.txtman42.Name = "txtman42";
            this.txtman42.Size = new System.Drawing.Size(95, 16);
            this.txtman42.TabIndex = 8;
            // 
            // txtpass41
            // 
            this.txtpass41.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtpass41.ForeColor = System.Drawing.Color.Blue;
            this.txtpass41.Location = new System.Drawing.Point(196, 103);
            this.txtpass41.Multiline = true;
            this.txtpass41.Name = "txtpass41";
            this.txtpass41.Size = new System.Drawing.Size(84, 17);
            this.txtpass41.TabIndex = 14;
            // 
            // txtprzcar42
            // 
            this.txtprzcar42.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprzcar42.ForeColor = System.Drawing.Color.Blue;
            this.txtprzcar42.Location = new System.Drawing.Point(286, 36);
            this.txtprzcar42.Multiline = true;
            this.txtprzcar42.Name = "txtprzcar42";
            this.txtprzcar42.Size = new System.Drawing.Size(95, 16);
            this.txtprzcar42.TabIndex = 1;
            // 
            // txtagg41
            // 
            this.txtagg41.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtagg41.ForeColor = System.Drawing.Color.Blue;
            this.txtagg41.Location = new System.Drawing.Point(196, 172);
            this.txtagg41.Multiline = true;
            this.txtagg41.Name = "txtagg41";
            this.txtagg41.Size = new System.Drawing.Size(84, 17);
            this.txtagg41.TabIndex = 23;
            // 
            // txtprzmarg41
            // 
            this.txtprzmarg41.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprzmarg41.ForeColor = System.Drawing.Color.Blue;
            this.txtprzmarg41.Location = new System.Drawing.Point(196, 144);
            this.txtprzmarg41.Multiline = true;
            this.txtprzmarg41.Name = "txtprzmarg41";
            this.txtprzmarg41.Size = new System.Drawing.Size(84, 17);
            this.txtprzmarg41.TabIndex = 20;
            this.txtprzmarg41.TextChanged += new System.EventHandler(this.txtprzmarg41_TextChanged);
            // 
            // txtdiffcar41
            // 
            this.txtdiffcar41.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtdiffcar41.ForeColor = System.Drawing.Color.Blue;
            this.txtdiffcar41.Location = new System.Drawing.Point(196, 119);
            this.txtdiffcar41.Multiline = true;
            this.txtdiffcar41.Name = "txtdiffcar41";
            this.txtdiffcar41.Size = new System.Drawing.Size(84, 17);
            this.txtdiffcar41.TabIndex = 17;
            // 
            // txtscc42
            // 
            this.txtscc42.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtscc42.ForeColor = System.Drawing.Color.Blue;
            this.txtscc42.Location = new System.Drawing.Point(286, 54);
            this.txtscc42.Multiline = true;
            this.txtscc42.Name = "txtscc42";
            this.txtscc42.Size = new System.Drawing.Size(95, 16);
            this.txtscc42.TabIndex = 4;
            // 
            // Panel2
            // 
            this.Panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Panel2.Controls.Add(this.Label86);
            this.Panel2.Controls.Add(this.Label63);
            this.Panel2.Controls.Add(this.btncancella2);
            this.Panel2.Controls.Add(this.Label28);
            this.Panel2.Controls.Add(this.txtsaggio);
            this.Panel2.Controls.Add(this.txtrendita2);
            this.Panel2.Controls.Add(this.txtrendita1);
            this.Panel2.Controls.Add(this.btnsaggio);
            this.Panel2.Controls.Add(this.txtsaggcarsogg);
            this.Panel2.Controls.Add(this.txtdatacarsogg);
            this.Panel2.Controls.Add(this.txtscccarsogg);
            this.Panel2.Controls.Add(this.txtagg23);
            this.Panel2.Controls.Add(this.txtdiff23);
            this.Panel2.Controls.Add(this.txtprzmarg23);
            this.Panel2.Controls.Add(this.txtagg22);
            this.Panel2.Controls.Add(this.txtdiff22);
            this.Panel2.Controls.Add(this.txtprzmarg22);
            this.Panel2.Controls.Add(this.txtagg21);
            this.Panel2.Controls.Add(this.txtdiff21);
            this.Panel2.Controls.Add(this.txtprzmarg21);
            this.Panel2.Controls.Add(this.txtsaggcar23);
            this.Panel2.Controls.Add(this.txtsaggcar22);
            this.Panel2.Controls.Add(this.txtsaggcar21);
            this.Panel2.Controls.Add(this.txtdatacar23);
            this.Panel2.Controls.Add(this.txtdatacar22);
            this.Panel2.Controls.Add(this.txtdatacar21);
            this.Panel2.Controls.Add(this.txtscccar23);
            this.Panel2.Controls.Add(this.txtscccar22);
            this.Panel2.Controls.Add(this.txtscccar21);
            this.Panel2.Controls.Add(this.txtprzcar23);
            this.Panel2.Controls.Add(this.txtprzcar22);
            this.Panel2.Controls.Add(this.txtprzcar21);
            this.Panel2.Controls.Add(this.Label38);
            this.Panel2.Controls.Add(this.Calcola2);
            this.Panel2.Controls.Add(this.Label17);
            this.Panel2.Controls.Add(this.Label18);
            this.Panel2.Controls.Add(this.Label19);
            this.Panel2.Controls.Add(this.Label20);
            this.Panel2.Controls.Add(this.Label25);
            this.Panel2.Controls.Add(this.Label26);
            this.Panel2.Controls.Add(this.Label27);
            this.Panel2.Controls.Add(this.Label29);
            this.Panel2.Controls.Add(this.Label30);
            this.Panel2.Controls.Add(this.Label31);
            this.Panel2.Controls.Add(this.Label32);
            this.Panel2.Location = new System.Drawing.Point(634, 0);
            this.Panel2.Name = "Panel2";
            this.Panel2.Size = new System.Drawing.Size(708, 239);
            this.Panel2.TabIndex = 21;
            // 
            // Label86
            // 
            this.Label86.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.Label86.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label86.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label86.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label86.Location = new System.Drawing.Point(486, 148);
            this.Label86.Name = "Label86";
            this.Label86.Size = new System.Drawing.Size(16, 14);
            this.Label86.TabIndex = 75;
            this.Label86.Text = "7";
            // 
            // Label63
            // 
            this.Label63.BackColor = System.Drawing.Color.Yellow;
            this.Label63.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label63.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label63.Location = new System.Drawing.Point(587, 52);
            this.Label63.Name = "Label63";
            this.Label63.Size = new System.Drawing.Size(16, 14);
            this.Label63.TabIndex = 74;
            this.Label63.Text = "2";
            // 
            // btncancella2
            // 
            this.btncancella2.BackColor = System.Drawing.Color.Yellow;
            this.btncancella2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncancella2.ForeColor = System.Drawing.Color.Blue;
            this.btncancella2.Location = new System.Drawing.Point(508, 181);
            this.btncancella2.Name = "btncancella2";
            this.btncancella2.Size = new System.Drawing.Size(95, 30);
            this.btncancella2.TabIndex = 73;
            this.btncancella2.Text = "Cancella";
            this.btncancella2.UseVisualStyleBackColor = false;
            this.btncancella2.Click += new System.EventHandler(this.btncancella2_Click);
            // 
            // Label28
            // 
            this.Label28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label28.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label28.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label28.Location = new System.Drawing.Point(602, 7);
            this.Label28.Name = "Label28";
            this.Label28.Size = new System.Drawing.Size(95, 16);
            this.Label28.TabIndex = 72;
            this.Label28.Text = "OMI";
            this.Label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtsaggio
            // 
            this.txtsaggio.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtsaggio.ForeColor = System.Drawing.Color.Blue;
            this.txtsaggio.Location = new System.Drawing.Point(609, 68);
            this.txtsaggio.Multiline = true;
            this.txtsaggio.Name = "txtsaggio";
            this.txtsaggio.Size = new System.Drawing.Size(75, 16);
            this.txtsaggio.TabIndex = 11;
            // 
            // txtrendita2
            // 
            this.txtrendita2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtrendita2.ForeColor = System.Drawing.Color.Blue;
            this.txtrendita2.Location = new System.Drawing.Point(609, 46);
            this.txtrendita2.Multiline = true;
            this.txtrendita2.Name = "txtrendita2";
            this.txtrendita2.Size = new System.Drawing.Size(75, 16);
            this.txtrendita2.TabIndex = 10;
            // 
            // txtrendita1
            // 
            this.txtrendita1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtrendita1.ForeColor = System.Drawing.Color.Blue;
            this.txtrendita1.Location = new System.Drawing.Point(609, 26);
            this.txtrendita1.Multiline = true;
            this.txtrendita1.Name = "txtrendita1";
            this.txtrendita1.Size = new System.Drawing.Size(75, 16);
            this.txtrendita1.TabIndex = 9;
            // 
            // btnsaggio
            // 
            this.btnsaggio.BackColor = System.Drawing.Color.Yellow;
            this.btnsaggio.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsaggio.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnsaggio.Location = new System.Drawing.Point(609, 126);
            this.btnsaggio.Name = "btnsaggio";
            this.btnsaggio.Size = new System.Drawing.Size(88, 51);
            this.btnsaggio.TabIndex = 68;
            this.btnsaggio.Text = "Calcolo saggio di sconto";
            this.btnsaggio.UseVisualStyleBackColor = false;
            this.btnsaggio.Click += new System.EventHandler(this.btnsaggio_Click);
            // 
            // txtsaggcarsogg
            // 
            this.txtsaggcarsogg.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtsaggcarsogg.ForeColor = System.Drawing.Color.Blue;
            this.txtsaggcarsogg.Location = new System.Drawing.Point(488, 68);
            this.txtsaggcarsogg.Multiline = true;
            this.txtsaggcarsogg.Name = "txtsaggcarsogg";
            this.txtsaggcarsogg.Size = new System.Drawing.Size(95, 16);
            this.txtsaggcarsogg.TabIndex = 19;
            // 
            // txtdatacarsogg
            // 
            this.txtdatacarsogg.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtdatacarsogg.ForeColor = System.Drawing.Color.Blue;
            this.txtdatacarsogg.Location = new System.Drawing.Point(488, 52);
            this.txtdatacarsogg.Multiline = true;
            this.txtdatacarsogg.Name = "txtdatacarsogg";
            this.txtdatacarsogg.Size = new System.Drawing.Size(95, 16);
            this.txtdatacarsogg.TabIndex = 15;
            // 
            // txtscccarsogg
            // 
            this.txtscccarsogg.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtscccarsogg.ForeColor = System.Drawing.Color.Blue;
            this.txtscccarsogg.Location = new System.Drawing.Point(488, 36);
            this.txtscccarsogg.Multiline = true;
            this.txtscccarsogg.Name = "txtscccarsogg";
            this.txtscccarsogg.Size = new System.Drawing.Size(95, 16);
            this.txtscccarsogg.TabIndex = 6;
            // 
            // txtagg23
            // 
            this.txtagg23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtagg23.ForeColor = System.Drawing.Color.Blue;
            this.txtagg23.Location = new System.Drawing.Point(387, 146);
            this.txtagg23.Multiline = true;
            this.txtagg23.Name = "txtagg23";
            this.txtagg23.Size = new System.Drawing.Size(95, 16);
            this.txtagg23.TabIndex = 28;
            // 
            // txtdiff23
            // 
            this.txtdiff23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtdiff23.ForeColor = System.Drawing.Color.Blue;
            this.txtdiff23.Location = new System.Drawing.Point(387, 116);
            this.txtdiff23.Multiline = true;
            this.txtdiff23.Name = "txtdiff23";
            this.txtdiff23.Size = new System.Drawing.Size(95, 16);
            this.txtdiff23.TabIndex = 25;
            // 
            // txtprzmarg23
            // 
            this.txtprzmarg23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprzmarg23.ForeColor = System.Drawing.Color.Blue;
            this.txtprzmarg23.Location = new System.Drawing.Point(387, 86);
            this.txtprzmarg23.Multiline = true;
            this.txtprzmarg23.Name = "txtprzmarg23";
            this.txtprzmarg23.Size = new System.Drawing.Size(95, 16);
            this.txtprzmarg23.TabIndex = 22;
            // 
            // txtagg22
            // 
            this.txtagg22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtagg22.ForeColor = System.Drawing.Color.Blue;
            this.txtagg22.Location = new System.Drawing.Point(286, 146);
            this.txtagg22.Multiline = true;
            this.txtagg22.Name = "txtagg22";
            this.txtagg22.Size = new System.Drawing.Size(95, 16);
            this.txtagg22.TabIndex = 27;
            // 
            // txtdiff22
            // 
            this.txtdiff22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtdiff22.ForeColor = System.Drawing.Color.Blue;
            this.txtdiff22.Location = new System.Drawing.Point(286, 116);
            this.txtdiff22.Multiline = true;
            this.txtdiff22.Name = "txtdiff22";
            this.txtdiff22.Size = new System.Drawing.Size(95, 16);
            this.txtdiff22.TabIndex = 24;
            // 
            // txtprzmarg22
            // 
            this.txtprzmarg22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprzmarg22.ForeColor = System.Drawing.Color.Blue;
            this.txtprzmarg22.Location = new System.Drawing.Point(286, 86);
            this.txtprzmarg22.Multiline = true;
            this.txtprzmarg22.Name = "txtprzmarg22";
            this.txtprzmarg22.Size = new System.Drawing.Size(95, 16);
            this.txtprzmarg22.TabIndex = 21;
            // 
            // txtagg21
            // 
            this.txtagg21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtagg21.ForeColor = System.Drawing.Color.Blue;
            this.txtagg21.Location = new System.Drawing.Point(196, 146);
            this.txtagg21.Multiline = true;
            this.txtagg21.Name = "txtagg21";
            this.txtagg21.Size = new System.Drawing.Size(84, 16);
            this.txtagg21.TabIndex = 26;
            // 
            // txtdiff21
            // 
            this.txtdiff21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtdiff21.ForeColor = System.Drawing.Color.Blue;
            this.txtdiff21.Location = new System.Drawing.Point(196, 116);
            this.txtdiff21.Multiline = true;
            this.txtdiff21.Name = "txtdiff21";
            this.txtdiff21.Size = new System.Drawing.Size(84, 16);
            this.txtdiff21.TabIndex = 23;
            // 
            // txtprzmarg21
            // 
            this.txtprzmarg21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprzmarg21.ForeColor = System.Drawing.Color.Blue;
            this.txtprzmarg21.Location = new System.Drawing.Point(196, 86);
            this.txtprzmarg21.Multiline = true;
            this.txtprzmarg21.Name = "txtprzmarg21";
            this.txtprzmarg21.Size = new System.Drawing.Size(84, 16);
            this.txtprzmarg21.TabIndex = 20;
            // 
            // txtsaggcar23
            // 
            this.txtsaggcar23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtsaggcar23.ForeColor = System.Drawing.Color.Blue;
            this.txtsaggcar23.Location = new System.Drawing.Point(387, 68);
            this.txtsaggcar23.Multiline = true;
            this.txtsaggcar23.Name = "txtsaggcar23";
            this.txtsaggcar23.Size = new System.Drawing.Size(95, 16);
            this.txtsaggcar23.TabIndex = 18;
            // 
            // txtsaggcar22
            // 
            this.txtsaggcar22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtsaggcar22.ForeColor = System.Drawing.Color.Blue;
            this.txtsaggcar22.Location = new System.Drawing.Point(286, 70);
            this.txtsaggcar22.Multiline = true;
            this.txtsaggcar22.Name = "txtsaggcar22";
            this.txtsaggcar22.Size = new System.Drawing.Size(95, 16);
            this.txtsaggcar22.TabIndex = 17;
            // 
            // txtsaggcar21
            // 
            this.txtsaggcar21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtsaggcar21.ForeColor = System.Drawing.Color.Blue;
            this.txtsaggcar21.Location = new System.Drawing.Point(196, 70);
            this.txtsaggcar21.Multiline = true;
            this.txtsaggcar21.Name = "txtsaggcar21";
            this.txtsaggcar21.Size = new System.Drawing.Size(84, 16);
            this.txtsaggcar21.TabIndex = 16;
            // 
            // txtdatacar23
            // 
            this.txtdatacar23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtdatacar23.ForeColor = System.Drawing.Color.Blue;
            this.txtdatacar23.Location = new System.Drawing.Point(387, 52);
            this.txtdatacar23.Multiline = true;
            this.txtdatacar23.Name = "txtdatacar23";
            this.txtdatacar23.Size = new System.Drawing.Size(95, 16);
            this.txtdatacar23.TabIndex = 14;
            // 
            // txtdatacar22
            // 
            this.txtdatacar22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtdatacar22.ForeColor = System.Drawing.Color.Blue;
            this.txtdatacar22.Location = new System.Drawing.Point(286, 54);
            this.txtdatacar22.Multiline = true;
            this.txtdatacar22.Name = "txtdatacar22";
            this.txtdatacar22.Size = new System.Drawing.Size(95, 16);
            this.txtdatacar22.TabIndex = 13;
            // 
            // txtdatacar21
            // 
            this.txtdatacar21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtdatacar21.ForeColor = System.Drawing.Color.Blue;
            this.txtdatacar21.Location = new System.Drawing.Point(196, 54);
            this.txtdatacar21.Multiline = true;
            this.txtdatacar21.Name = "txtdatacar21";
            this.txtdatacar21.Size = new System.Drawing.Size(84, 16);
            this.txtdatacar21.TabIndex = 12;
            // 
            // txtscccar23
            // 
            this.txtscccar23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtscccar23.ForeColor = System.Drawing.Color.Blue;
            this.txtscccar23.Location = new System.Drawing.Point(387, 37);
            this.txtscccar23.Multiline = true;
            this.txtscccar23.Name = "txtscccar23";
            this.txtscccar23.Size = new System.Drawing.Size(95, 16);
            this.txtscccar23.TabIndex = 5;
            // 
            // txtscccar22
            // 
            this.txtscccar22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtscccar22.ForeColor = System.Drawing.Color.Blue;
            this.txtscccar22.Location = new System.Drawing.Point(286, 38);
            this.txtscccar22.Multiline = true;
            this.txtscccar22.Name = "txtscccar22";
            this.txtscccar22.Size = new System.Drawing.Size(95, 16);
            this.txtscccar22.TabIndex = 4;
            // 
            // txtscccar21
            // 
            this.txtscccar21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtscccar21.ForeColor = System.Drawing.Color.Blue;
            this.txtscccar21.Location = new System.Drawing.Point(196, 38);
            this.txtscccar21.Multiline = true;
            this.txtscccar21.Name = "txtscccar21";
            this.txtscccar21.Size = new System.Drawing.Size(84, 16);
            this.txtscccar21.TabIndex = 3;
            // 
            // txtprzcar23
            // 
            this.txtprzcar23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprzcar23.ForeColor = System.Drawing.Color.Blue;
            this.txtprzcar23.Location = new System.Drawing.Point(387, 20);
            this.txtprzcar23.Multiline = true;
            this.txtprzcar23.Name = "txtprzcar23";
            this.txtprzcar23.Size = new System.Drawing.Size(95, 16);
            this.txtprzcar23.TabIndex = 2;
            // 
            // txtprzcar22
            // 
            this.txtprzcar22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprzcar22.ForeColor = System.Drawing.Color.Blue;
            this.txtprzcar22.Location = new System.Drawing.Point(286, 20);
            this.txtprzcar22.Multiline = true;
            this.txtprzcar22.Name = "txtprzcar22";
            this.txtprzcar22.Size = new System.Drawing.Size(95, 16);
            this.txtprzcar22.TabIndex = 1;
            // 
            // txtprzcar21
            // 
            this.txtprzcar21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprzcar21.ForeColor = System.Drawing.Color.Blue;
            this.txtprzcar21.Location = new System.Drawing.Point(196, 21);
            this.txtprzcar21.Multiline = true;
            this.txtprzcar21.Name = "txtprzcar21";
            this.txtprzcar21.Size = new System.Drawing.Size(84, 17);
            this.txtprzcar21.TabIndex = 0;
            // 
            // Label38
            // 
            this.Label38.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label38.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label38.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label38.Location = new System.Drawing.Point(6, 139);
            this.Label38.Name = "Label38";
            this.Label38.Size = new System.Drawing.Size(184, 27);
            this.Label38.TabIndex = 17;
            this.Label38.Text = "Aggiustamento data contratto (DAC)";
            this.Label38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Calcola2
            // 
            this.Calcola2.BackColor = System.Drawing.Color.Yellow;
            this.Calcola2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Calcola2.ForeColor = System.Drawing.Color.Blue;
            this.Calcola2.Location = new System.Drawing.Point(508, 126);
            this.Calcola2.Name = "Calcola2";
            this.Calcola2.Size = new System.Drawing.Size(95, 52);
            this.Calcola2.TabIndex = 16;
            this.Calcola2.Text = "Calcola";
            this.Calcola2.UseVisualStyleBackColor = false;
            this.Calcola2.Click += new System.EventHandler(this.Calcola2_Click);
            // 
            // Label17
            // 
            this.Label17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label17.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label17.Location = new System.Drawing.Point(488, 4);
            this.Label17.Name = "Label17";
            this.Label17.Size = new System.Drawing.Size(95, 16);
            this.Label17.TabIndex = 15;
            this.Label17.Text = "Soggetto";
            this.Label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label18
            // 
            this.Label18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label18.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label18.Location = new System.Drawing.Point(387, 5);
            this.Label18.Name = "Label18";
            this.Label18.Size = new System.Drawing.Size(95, 16);
            this.Label18.TabIndex = 14;
            this.Label18.Text = "Comparabile 3";
            this.Label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label19
            // 
            this.Label19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label19.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label19.Location = new System.Drawing.Point(286, 5);
            this.Label19.Name = "Label19";
            this.Label19.Size = new System.Drawing.Size(95, 16);
            this.Label19.TabIndex = 13;
            this.Label19.Text = "Comparabile 2";
            this.Label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label20
            // 
            this.Label20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label20.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label20.Location = new System.Drawing.Point(196, 6);
            this.Label20.Name = "Label20";
            this.Label20.Size = new System.Drawing.Size(84, 16);
            this.Label20.TabIndex = 12;
            this.Label20.Text = "Comparabile 1";
            this.Label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label25
            // 
            this.Label25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label25.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label25.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label25.Location = new System.Drawing.Point(6, 116);
            this.Label25.Name = "Label25";
            this.Label25.Size = new System.Drawing.Size(184, 16);
            this.Label25.TabIndex = 7;
            this.Label25.Text = "Differenziale data";
            // 
            // Label26
            // 
            this.Label26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label26.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label26.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label26.Location = new System.Drawing.Point(6, 89);
            this.Label26.Name = "Label26";
            this.Label26.Size = new System.Drawing.Size(184, 20);
            this.Label26.TabIndex = 6;
            this.Label26.Text = "Prezzo - marginale Data DAC";
            // 
            // Label27
            // 
            this.Label27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label27.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label27.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label27.Location = new System.Drawing.Point(6, 70);
            this.Label27.Name = "Label27";
            this.Label27.Size = new System.Drawing.Size(184, 16);
            this.Label27.TabIndex = 5;
            this.Label27.Text = "Saggio mensile";
            // 
            // Label29
            // 
            this.Label29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label29.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label29.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label29.Location = new System.Drawing.Point(6, 54);
            this.Label29.Name = "Label29";
            this.Label29.Size = new System.Drawing.Size(184, 16);
            this.Label29.TabIndex = 3;
            this.Label29.Text = "Data contratto";
            // 
            // Label30
            // 
            this.Label30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label30.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label30.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label30.Location = new System.Drawing.Point(6, 38);
            this.Label30.Name = "Label30";
            this.Label30.Size = new System.Drawing.Size(184, 16);
            this.Label30.TabIndex = 2;
            this.Label30.Text = "Superficie commerciale - SCC";
            // 
            // Label31
            // 
            this.Label31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label31.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label31.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label31.Location = new System.Drawing.Point(6, 22);
            this.Label31.Name = "Label31";
            this.Label31.Size = new System.Drawing.Size(184, 16);
            this.Label31.TabIndex = 1;
            this.Label31.Text = "Prezzo - PRZ";
            // 
            // Label32
            // 
            this.Label32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label32.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label32.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label32.Location = new System.Drawing.Point(6, 6);
            this.Label32.Name = "Label32";
            this.Label32.Size = new System.Drawing.Size(184, 16);
            this.Label32.TabIndex = 0;
            this.Label32.Text = "Caratteristica 2 : Data Contratto DAC";
            // 
            // btncancella6
            // 
            this.btncancella6.BackColor = System.Drawing.Color.Yellow;
            this.btncancella6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncancella6.ForeColor = System.Drawing.Color.Blue;
            this.btncancella6.Location = new System.Drawing.Point(495, 92);
            this.btncancella6.Name = "btncancella6";
            this.btncancella6.Size = new System.Drawing.Size(90, 31);
            this.btncancella6.TabIndex = 82;
            this.btncancella6.Text = "Cancella";
            this.btncancella6.UseVisualStyleBackColor = false;
            this.btncancella6.Click += new System.EventHandler(this.btncancella6_Click);
            // 
            // btncalcola6
            // 
            this.btncalcola6.BackColor = System.Drawing.Color.Yellow;
            this.btncalcola6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncalcola6.ForeColor = System.Drawing.Color.Blue;
            this.btncalcola6.Location = new System.Drawing.Point(495, 164);
            this.btncalcola6.Name = "btncalcola6";
            this.btncalcola6.Size = new System.Drawing.Size(95, 53);
            this.btncalcola6.TabIndex = 18;
            this.btncalcola6.Text = "Calcola";
            this.btncalcola6.UseVisualStyleBackColor = false;
            this.btncalcola6.Click += new System.EventHandler(this.btncalcola6_Click);
            // 
            // txtoprriass3
            // 
            this.txtoprriass3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtoprriass3.ForeColor = System.Drawing.Color.Blue;
            this.txtoprriass3.Location = new System.Drawing.Point(387, 172);
            this.txtoprriass3.Multiline = true;
            this.txtoprriass3.Name = "txtoprriass3";
            this.txtoprriass3.Size = new System.Drawing.Size(95, 16);
            this.txtoprriass3.TabIndex = 17;
            // 
            // txtmanutriass3
            // 
            this.txtmanutriass3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtmanutriass3.ForeColor = System.Drawing.Color.Blue;
            this.txtmanutriass3.Location = new System.Drawing.Point(388, 140);
            this.txtmanutriass3.Multiline = true;
            this.txtmanutriass3.Name = "txtmanutriass3";
            this.txtmanutriass3.Size = new System.Drawing.Size(95, 16);
            this.txtmanutriass3.TabIndex = 14;
            // 
            // txtprzldpriass3
            // 
            this.txtprzldpriass3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprzldpriass3.ForeColor = System.Drawing.Color.Blue;
            this.txtprzldpriass3.Location = new System.Drawing.Point(387, 108);
            this.txtprzldpriass3.Multiline = true;
            this.txtprzldpriass3.Name = "txtprzldpriass3";
            this.txtprzldpriass3.Size = new System.Drawing.Size(95, 16);
            this.txtprzldpriass3.TabIndex = 11;
            // 
            // txtprzdatariass3
            // 
            this.txtprzdatariass3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprzdatariass3.ForeColor = System.Drawing.Color.Blue;
            this.txtprzdatariass3.Location = new System.Drawing.Point(387, 92);
            this.txtprzdatariass3.Multiline = true;
            this.txtprzdatariass3.Name = "txtprzdatariass3";
            this.txtprzdatariass3.Size = new System.Drawing.Size(95, 16);
            this.txtprzdatariass3.TabIndex = 8;
            // 
            // txtsccriass3
            // 
            this.txtsccriass3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtsccriass3.ForeColor = System.Drawing.Color.Blue;
            this.txtsccriass3.Location = new System.Drawing.Point(387, 78);
            this.txtsccriass3.Multiline = true;
            this.txtsccriass3.Name = "txtsccriass3";
            this.txtsccriass3.Size = new System.Drawing.Size(95, 16);
            this.txtsccriass3.TabIndex = 5;
            // 
            // txtprzriass3
            // 
            this.txtprzriass3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprzriass3.ForeColor = System.Drawing.Color.Blue;
            this.txtprzriass3.Location = new System.Drawing.Point(387, 63);
            this.txtprzriass3.Multiline = true;
            this.txtprzriass3.Name = "txtprzriass3";
            this.txtprzriass3.Size = new System.Drawing.Size(95, 16);
            this.txtprzriass3.TabIndex = 2;
            // 
            // txtoprriass2
            // 
            this.txtoprriass2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtoprriass2.ForeColor = System.Drawing.Color.Blue;
            this.txtoprriass2.Location = new System.Drawing.Point(286, 172);
            this.txtoprriass2.Multiline = true;
            this.txtoprriass2.Name = "txtoprriass2";
            this.txtoprriass2.Size = new System.Drawing.Size(95, 16);
            this.txtoprriass2.TabIndex = 16;
            // 
            // txtmanutriass2
            // 
            this.txtmanutriass2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtmanutriass2.ForeColor = System.Drawing.Color.Blue;
            this.txtmanutriass2.Location = new System.Drawing.Point(287, 140);
            this.txtmanutriass2.Multiline = true;
            this.txtmanutriass2.Name = "txtmanutriass2";
            this.txtmanutriass2.Size = new System.Drawing.Size(95, 16);
            this.txtmanutriass2.TabIndex = 13;
            // 
            // txtprzldpriass2
            // 
            this.txtprzldpriass2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprzldpriass2.ForeColor = System.Drawing.Color.Blue;
            this.txtprzldpriass2.Location = new System.Drawing.Point(286, 108);
            this.txtprzldpriass2.Multiline = true;
            this.txtprzldpriass2.Name = "txtprzldpriass2";
            this.txtprzldpriass2.Size = new System.Drawing.Size(95, 16);
            this.txtprzldpriass2.TabIndex = 10;
            // 
            // txtprzdatariass2
            // 
            this.txtprzdatariass2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprzdatariass2.ForeColor = System.Drawing.Color.Blue;
            this.txtprzdatariass2.Location = new System.Drawing.Point(286, 92);
            this.txtprzdatariass2.Multiline = true;
            this.txtprzdatariass2.Name = "txtprzdatariass2";
            this.txtprzdatariass2.Size = new System.Drawing.Size(95, 16);
            this.txtprzdatariass2.TabIndex = 7;
            // 
            // txtsccriass2
            // 
            this.txtsccriass2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtsccriass2.ForeColor = System.Drawing.Color.Blue;
            this.txtsccriass2.Location = new System.Drawing.Point(286, 78);
            this.txtsccriass2.Multiline = true;
            this.txtsccriass2.Name = "txtsccriass2";
            this.txtsccriass2.Size = new System.Drawing.Size(95, 16);
            this.txtsccriass2.TabIndex = 4;
            // 
            // txtprzriass2
            // 
            this.txtprzriass2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprzriass2.ForeColor = System.Drawing.Color.Blue;
            this.txtprzriass2.Location = new System.Drawing.Point(286, 63);
            this.txtprzriass2.Multiline = true;
            this.txtprzriass2.Name = "txtprzriass2";
            this.txtprzriass2.Size = new System.Drawing.Size(95, 16);
            this.txtprzriass2.TabIndex = 1;
            // 
            // txtoprriass1
            // 
            this.txtoprriass1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtoprriass1.ForeColor = System.Drawing.Color.Blue;
            this.txtoprriass1.Location = new System.Drawing.Point(196, 172);
            this.txtoprriass1.Multiline = true;
            this.txtoprriass1.Name = "txtoprriass1";
            this.txtoprriass1.Size = new System.Drawing.Size(85, 16);
            this.txtoprriass1.TabIndex = 15;
            // 
            // txtmanutriass1
            // 
            this.txtmanutriass1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtmanutriass1.ForeColor = System.Drawing.Color.Blue;
            this.txtmanutriass1.Location = new System.Drawing.Point(196, 140);
            this.txtmanutriass1.Multiline = true;
            this.txtmanutriass1.Name = "txtmanutriass1";
            this.txtmanutriass1.Size = new System.Drawing.Size(85, 16);
            this.txtmanutriass1.TabIndex = 12;
            // 
            // txtprzldpriass1
            // 
            this.txtprzldpriass1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprzldpriass1.ForeColor = System.Drawing.Color.Blue;
            this.txtprzldpriass1.Location = new System.Drawing.Point(196, 106);
            this.txtprzldpriass1.Multiline = true;
            this.txtprzldpriass1.Name = "txtprzldpriass1";
            this.txtprzldpriass1.Size = new System.Drawing.Size(85, 16);
            this.txtprzldpriass1.TabIndex = 9;
            // 
            // Panel6
            // 
            this.Panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Panel6.Controls.Add(this.btncancella6);
            this.Panel6.Controls.Add(this.btncalcola6);
            this.Panel6.Controls.Add(this.txtoprriass3);
            this.Panel6.Controls.Add(this.txtmanutriass3);
            this.Panel6.Controls.Add(this.txtprzldpriass3);
            this.Panel6.Controls.Add(this.txtprzdatariass3);
            this.Panel6.Controls.Add(this.txtsccriass3);
            this.Panel6.Controls.Add(this.txtprzriass3);
            this.Panel6.Controls.Add(this.txtoprriass2);
            this.Panel6.Controls.Add(this.txtmanutriass2);
            this.Panel6.Controls.Add(this.txtprzldpriass2);
            this.Panel6.Controls.Add(this.txtprzdatariass2);
            this.Panel6.Controls.Add(this.txtsccriass2);
            this.Panel6.Controls.Add(this.txtprzriass2);
            this.Panel6.Controls.Add(this.txtoprriass1);
            this.Panel6.Controls.Add(this.txtmanutriass1);
            this.Panel6.Controls.Add(this.txtprzldpriass1);
            this.Panel6.Controls.Add(this.txtprzdatariass1);
            this.Panel6.Controls.Add(this.txtsccriass1);
            this.Panel6.Controls.Add(this.txtprzriass1);
            this.Panel6.Controls.Add(this.Label24);
            this.Panel6.Controls.Add(this.Label82);
            this.Panel6.Controls.Add(this.Label83);
            this.Panel6.Controls.Add(this.Label84);
            this.Panel6.Controls.Add(this.Label90);
            this.Panel6.Controls.Add(this.Label91);
            this.Panel6.Controls.Add(this.Label92);
            this.Panel6.Controls.Add(this.Label93);
            this.Panel6.Controls.Add(this.Label94);
            this.Panel6.Controls.Add(this.Label95);
            this.Panel6.Controls.Add(this.Label96);
            this.Panel6.Location = new System.Drawing.Point(634, 483);
            this.Panel6.Name = "Panel6";
            this.Panel6.Size = new System.Drawing.Size(593, 249);
            this.Panel6.TabIndex = 26;
            // 
            // txtprzdatariass1
            // 
            this.txtprzdatariass1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprzdatariass1.ForeColor = System.Drawing.Color.Blue;
            this.txtprzdatariass1.Location = new System.Drawing.Point(196, 92);
            this.txtprzdatariass1.Multiline = true;
            this.txtprzdatariass1.Name = "txtprzdatariass1";
            this.txtprzdatariass1.Size = new System.Drawing.Size(85, 16);
            this.txtprzdatariass1.TabIndex = 6;
            // 
            // txtsccriass1
            // 
            this.txtsccriass1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtsccriass1.ForeColor = System.Drawing.Color.Blue;
            this.txtsccriass1.Location = new System.Drawing.Point(196, 78);
            this.txtsccriass1.Multiline = true;
            this.txtsccriass1.Name = "txtsccriass1";
            this.txtsccriass1.Size = new System.Drawing.Size(85, 16);
            this.txtsccriass1.TabIndex = 3;
            // 
            // txtprzriass1
            // 
            this.txtprzriass1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprzriass1.ForeColor = System.Drawing.Color.Blue;
            this.txtprzriass1.Location = new System.Drawing.Point(196, 62);
            this.txtprzriass1.Multiline = true;
            this.txtprzriass1.Name = "txtprzriass1";
            this.txtprzriass1.Size = new System.Drawing.Size(85, 16);
            this.txtprzriass1.TabIndex = 0;
            // 
            // Label24
            // 
            this.Label24.BackColor = System.Drawing.Color.Yellow;
            this.Label24.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label24.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label24.Location = new System.Drawing.Point(3, 4);
            this.Label24.Name = "Label24";
            this.Label24.Size = new System.Drawing.Size(580, 30);
            this.Label24.TabIndex = 16;
            this.Label24.Text = "ANALISI RIASSUNTIVA PREZZI MARGINALI";
            this.Label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label82
            // 
            this.Label82.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label82.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label82.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label82.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label82.Location = new System.Drawing.Point(387, 44);
            this.Label82.Name = "Label82";
            this.Label82.Size = new System.Drawing.Size(95, 16);
            this.Label82.TabIndex = 14;
            this.Label82.Text = "Comparabile 3";
            this.Label82.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label83
            // 
            this.Label83.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label83.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label83.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label83.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label83.Location = new System.Drawing.Point(286, 44);
            this.Label83.Name = "Label83";
            this.Label83.Size = new System.Drawing.Size(95, 16);
            this.Label83.TabIndex = 13;
            this.Label83.Text = "Comparabile 2";
            this.Label83.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label84
            // 
            this.Label84.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label84.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label84.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label84.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label84.Location = new System.Drawing.Point(196, 44);
            this.Label84.Name = "Label84";
            this.Label84.Size = new System.Drawing.Size(84, 16);
            this.Label84.TabIndex = 12;
            this.Label84.Text = "Comparabile 1";
            this.Label84.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label90
            // 
            this.Label90.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label90.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label90.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label90.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label90.Location = new System.Drawing.Point(6, 158);
            this.Label90.Name = "Label90";
            this.Label90.Size = new System.Drawing.Size(184, 30);
            this.Label90.TabIndex = 6;
            this.Label90.Text = "Orientamento prevalente (OPR)";
            // 
            // Label91
            // 
            this.Label91.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label91.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label91.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label91.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label91.Location = new System.Drawing.Point(6, 124);
            this.Label91.Name = "Label91";
            this.Label91.Size = new System.Drawing.Size(184, 32);
            this.Label91.TabIndex = 5;
            this.Label91.Text = "Prezzo marginale - manutenzione gen. SMT";
            // 
            // Label92
            // 
            this.Label92.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label92.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label92.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label92.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label92.Location = new System.Drawing.Point(6, 108);
            this.Label92.Name = "Label92";
            this.Label92.Size = new System.Drawing.Size(184, 16);
            this.Label92.TabIndex = 4;
            this.Label92.Text = "Prezzo marginale - LDP";
            // 
            // Label93
            // 
            this.Label93.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label93.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label93.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label93.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label93.Location = new System.Drawing.Point(6, 92);
            this.Label93.Name = "Label93";
            this.Label93.Size = new System.Drawing.Size(184, 16);
            this.Label93.TabIndex = 3;
            this.Label93.Text = "Prezzo - marginale Data DAC €/mese";
            // 
            // Label94
            // 
            this.Label94.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label94.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label94.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label94.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label94.Location = new System.Drawing.Point(6, 76);
            this.Label94.Name = "Label94";
            this.Label94.Size = new System.Drawing.Size(184, 16);
            this.Label94.TabIndex = 2;
            this.Label94.Text = "Superficie commerciale - SCC €/mq.";
            // 
            // Label95
            // 
            this.Label95.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label95.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label95.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label95.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label95.Location = new System.Drawing.Point(6, 60);
            this.Label95.Name = "Label95";
            this.Label95.Size = new System.Drawing.Size(184, 16);
            this.Label95.TabIndex = 1;
            this.Label95.Text = "Prezzo - PRZ";
            // 
            // Label96
            // 
            this.Label96.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label96.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label96.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label96.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label96.Location = new System.Drawing.Point(6, 44);
            this.Label96.Name = "Label96";
            this.Label96.Size = new System.Drawing.Size(184, 16);
            this.Label96.TabIndex = 0;
            this.Label96.Text = "Caratteristica";
            // 
            // txtscc41
            // 
            this.txtscc41.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtscc41.ForeColor = System.Drawing.Color.Blue;
            this.txtscc41.Location = new System.Drawing.Point(196, 55);
            this.txtscc41.Multiline = true;
            this.txtscc41.Name = "txtscc41";
            this.txtscc41.Size = new System.Drawing.Size(84, 17);
            this.txtscc41.TabIndex = 3;
            // 
            // Label97
            // 
            this.Label97.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.Label97.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label97.Location = new System.Drawing.Point(472, 22);
            this.Label97.Name = "Label97";
            this.Label97.Size = new System.Drawing.Size(16, 14);
            this.Label97.TabIndex = 59;
            // 
            // Label85
            // 
            this.Label85.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.Label85.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label85.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label85.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label85.Location = new System.Drawing.Point(471, 168);
            this.Label85.Name = "Label85";
            this.Label85.Size = new System.Drawing.Size(16, 14);
            this.Label85.TabIndex = 58;
            this.Label85.Text = "6";
            // 
            // Label58
            // 
            this.Label58.BackColor = System.Drawing.Color.Yellow;
            this.Label58.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label58.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label58.Location = new System.Drawing.Point(472, 150);
            this.Label58.Name = "Label58";
            this.Label58.Size = new System.Drawing.Size(16, 14);
            this.Label58.TabIndex = 57;
            this.Label58.Text = "1";
            // 
            // Label54
            // 
            this.Label54.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label54.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label54.Location = new System.Drawing.Point(472, 216);
            this.Label54.Name = "Label54";
            this.Label54.Size = new System.Drawing.Size(16, 14);
            this.Label54.TabIndex = 56;
            // 
            // btncancella1
            // 
            this.btncancella1.BackColor = System.Drawing.Color.Yellow;
            this.btncancella1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncancella1.ForeColor = System.Drawing.Color.Blue;
            this.btncancella1.Location = new System.Drawing.Point(493, 179);
            this.btncancella1.Name = "btncancella1";
            this.btncancella1.Size = new System.Drawing.Size(90, 30);
            this.btncancella1.TabIndex = 55;
            this.btncancella1.Text = "Cancella";
            this.btncancella1.UseVisualStyleBackColor = false;
            this.btncancella1.Click += new System.EventHandler(this.btncancella1_Click);
            // 
            // txtprunitmax
            // 
            this.txtprunitmax.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprunitmax.ForeColor = System.Drawing.Color.Blue;
            this.txtprunitmax.Location = new System.Drawing.Point(493, 102);
            this.txtprunitmax.Multiline = true;
            this.txtprunitmax.Name = "txtprunitmax";
            this.txtprunitmax.Size = new System.Drawing.Size(90, 18);
            this.txtprunitmax.TabIndex = 15;
            // 
            // txtprunitmin
            // 
            this.txtprunitmin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprunitmin.ForeColor = System.Drawing.Color.Blue;
            this.txtprunitmin.Location = new System.Drawing.Point(493, 81);
            this.txtprunitmin.Multiline = true;
            this.txtprunitmin.Name = "txtprunitmin";
            this.txtprunitmin.Size = new System.Drawing.Size(90, 18);
            this.txtprunitmin.TabIndex = 14;
            // 
            // Label37
            // 
            this.Label37.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label37.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label37.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label37.Location = new System.Drawing.Point(493, 57);
            this.Label37.Name = "Label37";
            this.Label37.Size = new System.Drawing.Size(90, 21);
            this.Label37.TabIndex = 10;
            this.Label37.Text = "Inserire prezzo unit. min. e max. arrotondati ";
            // 
            // txtprzmcorrsogg
            // 
            this.txtprzmcorrsogg.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprzmcorrsogg.ForeColor = System.Drawing.Color.Blue;
            this.txtprzmcorrsogg.Location = new System.Drawing.Point(493, 215);
            this.txtprzmcorrsogg.Multiline = true;
            this.txtprzmcorrsogg.Name = "txtprzmcorrsogg";
            this.txtprzmcorrsogg.ReadOnly = true;
            this.txtprzmcorrsogg.Size = new System.Drawing.Size(90, 16);
            this.txtprzmcorrsogg.TabIndex = 51;
            // 
            // txtprzmcorr3
            // 
            this.txtprzmcorr3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprzmcorr3.ForeColor = System.Drawing.Color.Blue;
            this.txtprzmcorr3.Location = new System.Drawing.Point(376, 215);
            this.txtprzmcorr3.Multiline = true;
            this.txtprzmcorr3.Name = "txtprzmcorr3";
            this.txtprzmcorr3.ReadOnly = true;
            this.txtprzmcorr3.Size = new System.Drawing.Size(91, 16);
            this.txtprzmcorr3.TabIndex = 36;
            // 
            // txtprzmcorr2
            // 
            this.txtprzmcorr2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprzmcorr2.ForeColor = System.Drawing.Color.Blue;
            this.txtprzmcorr2.Location = new System.Drawing.Point(286, 215);
            this.txtprzmcorr2.Multiline = true;
            this.txtprzmcorr2.Name = "txtprzmcorr2";
            this.txtprzmcorr2.ReadOnly = true;
            this.txtprzmcorr2.Size = new System.Drawing.Size(85, 16);
            this.txtprzmcorr2.TabIndex = 35;
            // 
            // txtprzmcorr1
            // 
            this.txtprzmcorr1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprzmcorr1.ForeColor = System.Drawing.Color.Blue;
            this.txtprzmcorr1.Location = new System.Drawing.Point(196, 215);
            this.txtprzmcorr1.Multiline = true;
            this.txtprzmcorr1.Name = "txtprzmcorr1";
            this.txtprzmcorr1.ReadOnly = true;
            this.txtprzmcorr1.Size = new System.Drawing.Size(84, 16);
            this.txtprzmcorr1.TabIndex = 34;
            // 
            // txtprzcorr3
            // 
            this.txtprzcorr3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprzcorr3.ForeColor = System.Drawing.Color.Blue;
            this.txtprzcorr3.Location = new System.Drawing.Point(377, 192);
            this.txtprzcorr3.Multiline = true;
            this.txtprzcorr3.Name = "txtprzcorr3";
            this.txtprzcorr3.Size = new System.Drawing.Size(91, 19);
            this.txtprzcorr3.TabIndex = 33;
            // 
            // txtprzcorr2
            // 
            this.txtprzcorr2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprzcorr2.ForeColor = System.Drawing.Color.Blue;
            this.txtprzcorr2.Location = new System.Drawing.Point(285, 192);
            this.txtprzcorr2.Multiline = true;
            this.txtprzcorr2.Name = "txtprzcorr2";
            this.txtprzcorr2.Size = new System.Drawing.Size(85, 19);
            this.txtprzcorr2.TabIndex = 32;
            // 
            // txtAgg3
            // 
            this.txtAgg3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtAgg3.ForeColor = System.Drawing.Color.Blue;
            this.txtAgg3.Location = new System.Drawing.Point(377, 166);
            this.txtAgg3.Multiline = true;
            this.txtAgg3.Name = "txtAgg3";
            this.txtAgg3.Size = new System.Drawing.Size(91, 20);
            this.txtAgg3.TabIndex = 30;
            // 
            // txtAgg2
            // 
            this.txtAgg2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtAgg2.ForeColor = System.Drawing.Color.Blue;
            this.txtAgg2.Location = new System.Drawing.Point(285, 166);
            this.txtAgg2.Multiline = true;
            this.txtAgg2.Name = "txtAgg2";
            this.txtAgg2.Size = new System.Drawing.Size(85, 20);
            this.txtAgg2.TabIndex = 29;
            // 
            // txtAgg1
            // 
            this.txtAgg1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtAgg1.ForeColor = System.Drawing.Color.Blue;
            this.txtAgg1.Location = new System.Drawing.Point(195, 166);
            this.txtAgg1.Multiline = true;
            this.txtAgg1.Name = "txtAgg1";
            this.txtAgg1.Size = new System.Drawing.Size(84, 20);
            this.txtAgg1.TabIndex = 28;
            // 
            // txtdiff3
            // 
            this.txtdiff3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtdiff3.ForeColor = System.Drawing.Color.Blue;
            this.txtdiff3.Location = new System.Drawing.Point(377, 148);
            this.txtdiff3.Multiline = true;
            this.txtdiff3.Name = "txtdiff3";
            this.txtdiff3.Size = new System.Drawing.Size(91, 18);
            this.txtdiff3.TabIndex = 27;
            // 
            // txtdiff2
            // 
            this.txtdiff2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtdiff2.ForeColor = System.Drawing.Color.Blue;
            this.txtdiff2.Location = new System.Drawing.Point(286, 148);
            this.txtdiff2.Multiline = true;
            this.txtdiff2.Name = "txtdiff2";
            this.txtdiff2.Size = new System.Drawing.Size(85, 18);
            this.txtdiff2.TabIndex = 26;
            // 
            // txtpiano3
            // 
            this.txtpiano3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtpiano3.ForeColor = System.Drawing.Color.Blue;
            this.txtpiano3.Location = new System.Drawing.Point(377, 207);
            this.txtpiano3.Multiline = true;
            this.txtpiano3.Name = "txtpiano3";
            this.txtpiano3.Size = new System.Drawing.Size(89, 18);
            this.txtpiano3.TabIndex = 34;
            // 
            // Panel3
            // 
            this.Panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Panel3.Controls.Add(this.Label87);
            this.Panel3.Controls.Add(this.Label78);
            this.Panel3.Controls.Add(this.btncancella3);
            this.Panel3.Controls.Add(this.txtpiano3);
            this.Panel3.Controls.Add(this.txtpiano2);
            this.Panel3.Controls.Add(this.txtpiano1);
            this.Panel3.Controls.Add(this.txtprunitcar3arr3);
            this.Panel3.Controls.Add(this.txtprunitcar3arr2);
            this.Panel3.Controls.Add(this.txtprunitcar3arr1);
            this.Panel3.Controls.Add(this.Label39);
            this.Panel3.Controls.Add(this.txtsagrvupcar3sogg);
            this.Panel3.Controls.Add(this.txtlivccar3sogg);
            this.Panel3.Controls.Add(this.txtlivpcar3sogg);
            this.Panel3.Controls.Add(this.txtldpdiffcar33);
            this.Panel3.Controls.Add(this.txtldpdiffcar32);
            this.Panel3.Controls.Add(this.txtldpdiffcar31);
            this.Panel3.Controls.Add(this.txtprzmargldpcar33);
            this.Panel3.Controls.Add(this.txtprzmargldpcar32);
            this.Panel3.Controls.Add(this.txtprzmargldpcar31);
            this.Panel3.Controls.Add(this.txtsagrvupcar33);
            this.Panel3.Controls.Add(this.txtsagrvupcar32);
            this.Panel3.Controls.Add(this.txtsagrvupcar31);
            this.Panel3.Controls.Add(this.txtrupncar33);
            this.Panel3.Controls.Add(this.txtrupncar32);
            this.Panel3.Controls.Add(this.txtrupncar31);
            this.Panel3.Controls.Add(this.txtkcar33);
            this.Panel3.Controls.Add(this.txtkcar32);
            this.Panel3.Controls.Add(this.txtkcar31);
            this.Panel3.Controls.Add(this.txtrvppcar33);
            this.Panel3.Controls.Add(this.txtrvppcar32);
            this.Panel3.Controls.Add(this.txtrvppcar31);
            this.Panel3.Controls.Add(this.txtlivccar33);
            this.Panel3.Controls.Add(this.txtlivccar32);
            this.Panel3.Controls.Add(this.txtlivccar31);
            this.Panel3.Controls.Add(this.txtlivpcar33);
            this.Panel3.Controls.Add(this.txtlivpcar32);
            this.Panel3.Controls.Add(this.txtlivpcar31);
            this.Panel3.Controls.Add(this.txtprunitcar33);
            this.Panel3.Controls.Add(this.txtprunitcar32);
            this.Panel3.Controls.Add(this.txtprunitcar31);
            this.Panel3.Controls.Add(this.Calcola3);
            this.Panel3.Controls.Add(this.Label22);
            this.Panel3.Controls.Add(this.Label21);
            this.Panel3.Controls.Add(this.Label33);
            this.Panel3.Controls.Add(this.Label34);
            this.Panel3.Controls.Add(this.Label35);
            this.Panel3.Controls.Add(this.Label36);
            this.Panel3.Controls.Add(this.Label40);
            this.Panel3.Controls.Add(this.Label41);
            this.Panel3.Controls.Add(this.Label42);
            this.Panel3.Controls.Add(this.Label43);
            this.Panel3.Controls.Add(this.Label44);
            this.Panel3.Controls.Add(this.Label45);
            this.Panel3.Controls.Add(this.Label46);
            this.Panel3.Controls.Add(this.Label47);
            this.Panel3.Controls.Add(this.Label48);
            this.Panel3.Location = new System.Drawing.Point(29, 245);
            this.Panel3.Name = "Panel3";
            this.Panel3.Size = new System.Drawing.Size(593, 232);
            this.Panel3.TabIndex = 23;
            // 
            // Label87
            // 
            this.Label87.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.Label87.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label87.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label87.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label87.Location = new System.Drawing.Point(472, 209);
            this.Label87.Name = "Label87";
            this.Label87.Size = new System.Drawing.Size(16, 14);
            this.Label87.TabIndex = 82;
            this.Label87.Text = "8";
            // 
            // Label78
            // 
            this.Label78.BackColor = System.Drawing.Color.Yellow;
            this.Label78.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label78.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label78.Location = new System.Drawing.Point(472, 187);
            this.Label78.Name = "Label78";
            this.Label78.Size = new System.Drawing.Size(16, 14);
            this.Label78.TabIndex = 81;
            this.Label78.Text = "3";
            // 
            // btncancella3
            // 
            this.btncancella3.BackColor = System.Drawing.Color.Yellow;
            this.btncancella3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncancella3.ForeColor = System.Drawing.Color.Blue;
            this.btncancella3.Location = new System.Drawing.Point(493, 98);
            this.btncancella3.Name = "btncancella3";
            this.btncancella3.Size = new System.Drawing.Size(90, 31);
            this.btncancella3.TabIndex = 80;
            this.btncancella3.Text = "Cancella";
            this.btncancella3.UseVisualStyleBackColor = false;
            this.btncancella3.Click += new System.EventHandler(this.btncancella3_Click);
            // 
            // txtpiano2
            // 
            this.txtpiano2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtpiano2.ForeColor = System.Drawing.Color.Blue;
            this.txtpiano2.Location = new System.Drawing.Point(285, 207);
            this.txtpiano2.Multiline = true;
            this.txtpiano2.Name = "txtpiano2";
            this.txtpiano2.Size = new System.Drawing.Size(83, 18);
            this.txtpiano2.TabIndex = 33;
            // 
            // txtpiano1
            // 
            this.txtpiano1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtpiano1.ForeColor = System.Drawing.Color.Blue;
            this.txtpiano1.Location = new System.Drawing.Point(195, 207);
            this.txtpiano1.Multiline = true;
            this.txtpiano1.Name = "txtpiano1";
            this.txtpiano1.Size = new System.Drawing.Size(83, 18);
            this.txtpiano1.TabIndex = 32;
            // 
            // txtprunitcar3arr3
            // 
            this.txtprunitcar3arr3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprunitcar3arr3.ForeColor = System.Drawing.Color.Blue;
            this.txtprunitcar3arr3.Location = new System.Drawing.Point(373, 34);
            this.txtprunitcar3arr3.Multiline = true;
            this.txtprunitcar3arr3.Name = "txtprunitcar3arr3";
            this.txtprunitcar3arr3.ReadOnly = true;
            this.txtprunitcar3arr3.Size = new System.Drawing.Size(94, 16);
            this.txtprunitcar3arr3.TabIndex = 5;
            // 
            // txtprunitcar3arr2
            // 
            this.txtprunitcar3arr2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprunitcar3arr2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.txtprunitcar3arr2.Location = new System.Drawing.Point(286, 34);
            this.txtprunitcar3arr2.Multiline = true;
            this.txtprunitcar3arr2.Name = "txtprunitcar3arr2";
            this.txtprunitcar3arr2.ReadOnly = true;
            this.txtprunitcar3arr2.Size = new System.Drawing.Size(81, 16);
            this.txtprunitcar3arr2.TabIndex = 4;
            // 
            // txtprunitcar3arr1
            // 
            this.txtprunitcar3arr1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprunitcar3arr1.ForeColor = System.Drawing.Color.Blue;
            this.txtprunitcar3arr1.Location = new System.Drawing.Point(197, 34);
            this.txtprunitcar3arr1.Multiline = true;
            this.txtprunitcar3arr1.Name = "txtprunitcar3arr1";
            this.txtprunitcar3arr1.ReadOnly = true;
            this.txtprunitcar3arr1.Size = new System.Drawing.Size(84, 16);
            this.txtprunitcar3arr1.TabIndex = 3;
            // 
            // Label39
            // 
            this.Label39.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label39.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label39.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label39.Location = new System.Drawing.Point(5, 34);
            this.Label39.Name = "Label39";
            this.Label39.Size = new System.Drawing.Size(184, 16);
            this.Label39.TabIndex = 73;
            this.Label39.Text = "Prezzo unitario arrotondato";
            // 
            // txtsagrvupcar3sogg
            // 
            this.txtsagrvupcar3sogg.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtsagrvupcar3sogg.ForeColor = System.Drawing.Color.Blue;
            this.txtsagrvupcar3sogg.Location = new System.Drawing.Point(493, 144);
            this.txtsagrvupcar3sogg.Multiline = true;
            this.txtsagrvupcar3sogg.Name = "txtsagrvupcar3sogg";
            this.txtsagrvupcar3sogg.Size = new System.Drawing.Size(90, 16);
            this.txtsagrvupcar3sogg.TabIndex = 72;
            // 
            // txtlivccar3sogg
            // 
            this.txtlivccar3sogg.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtlivccar3sogg.ForeColor = System.Drawing.Color.Blue;
            this.txtlivccar3sogg.Location = new System.Drawing.Point(493, 67);
            this.txtlivccar3sogg.Multiline = true;
            this.txtlivccar3sogg.Name = "txtlivccar3sogg";
            this.txtlivccar3sogg.Size = new System.Drawing.Size(90, 16);
            this.txtlivccar3sogg.TabIndex = 13;
            // 
            // txtlivpcar3sogg
            // 
            this.txtlivpcar3sogg.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtlivpcar3sogg.ForeColor = System.Drawing.Color.Blue;
            this.txtlivpcar3sogg.Location = new System.Drawing.Point(493, 50);
            this.txtlivpcar3sogg.Multiline = true;
            this.txtlivpcar3sogg.Name = "txtlivpcar3sogg";
            this.txtlivpcar3sogg.Size = new System.Drawing.Size(90, 16);
            this.txtlivpcar3sogg.TabIndex = 9;
            // 
            // txtldpdiffcar33
            // 
            this.txtldpdiffcar33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtldpdiffcar33.ForeColor = System.Drawing.Color.Blue;
            this.txtldpdiffcar33.Location = new System.Drawing.Point(376, 185);
            this.txtldpdiffcar33.Multiline = true;
            this.txtldpdiffcar33.Name = "txtldpdiffcar33";
            this.txtldpdiffcar33.Size = new System.Drawing.Size(90, 18);
            this.txtldpdiffcar33.TabIndex = 31;
            // 
            // txtldpdiffcar32
            // 
            this.txtldpdiffcar32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtldpdiffcar32.ForeColor = System.Drawing.Color.Blue;
            this.txtldpdiffcar32.Location = new System.Drawing.Point(284, 185);
            this.txtldpdiffcar32.Multiline = true;
            this.txtldpdiffcar32.Name = "txtldpdiffcar32";
            this.txtldpdiffcar32.Size = new System.Drawing.Size(84, 18);
            this.txtldpdiffcar32.TabIndex = 30;
            // 
            // txtldpdiffcar31
            // 
            this.txtldpdiffcar31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtldpdiffcar31.ForeColor = System.Drawing.Color.Blue;
            this.txtldpdiffcar31.Location = new System.Drawing.Point(195, 185);
            this.txtldpdiffcar31.Multiline = true;
            this.txtldpdiffcar31.Name = "txtldpdiffcar31";
            this.txtldpdiffcar31.Size = new System.Drawing.Size(83, 18);
            this.txtldpdiffcar31.TabIndex = 29;
            // 
            // txtprzmargldpcar33
            // 
            this.txtprzmargldpcar33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprzmargldpcar33.ForeColor = System.Drawing.Color.Blue;
            this.txtprzmargldpcar33.Location = new System.Drawing.Point(375, 167);
            this.txtprzmargldpcar33.Multiline = true;
            this.txtprzmargldpcar33.Name = "txtprzmargldpcar33";
            this.txtprzmargldpcar33.Size = new System.Drawing.Size(91, 18);
            this.txtprzmargldpcar33.TabIndex = 28;
            // 
            // txtprzmargldpcar32
            // 
            this.txtprzmargldpcar32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprzmargldpcar32.ForeColor = System.Drawing.Color.Blue;
            this.txtprzmargldpcar32.Location = new System.Drawing.Point(284, 167);
            this.txtprzmargldpcar32.Multiline = true;
            this.txtprzmargldpcar32.Name = "txtprzmargldpcar32";
            this.txtprzmargldpcar32.Size = new System.Drawing.Size(84, 18);
            this.txtprzmargldpcar32.TabIndex = 27;
            // 
            // txtprzmargldpcar31
            // 
            this.txtprzmargldpcar31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprzmargldpcar31.ForeColor = System.Drawing.Color.Blue;
            this.txtprzmargldpcar31.Location = new System.Drawing.Point(195, 167);
            this.txtprzmargldpcar31.Multiline = true;
            this.txtprzmargldpcar31.Name = "txtprzmargldpcar31";
            this.txtprzmargldpcar31.Size = new System.Drawing.Size(84, 18);
            this.txtprzmargldpcar31.TabIndex = 26;
            // 
            // txtsagrvupcar33
            // 
            this.txtsagrvupcar33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtsagrvupcar33.ForeColor = System.Drawing.Color.Blue;
            this.txtsagrvupcar33.Location = new System.Drawing.Point(375, 145);
            this.txtsagrvupcar33.Multiline = true;
            this.txtsagrvupcar33.Name = "txtsagrvupcar33";
            this.txtsagrvupcar33.Size = new System.Drawing.Size(93, 18);
            this.txtsagrvupcar33.TabIndex = 25;
            // 
            // txtsagrvupcar32
            // 
            this.txtsagrvupcar32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtsagrvupcar32.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.txtsagrvupcar32.Location = new System.Drawing.Point(284, 146);
            this.txtsagrvupcar32.Multiline = true;
            this.txtsagrvupcar32.Name = "txtsagrvupcar32";
            this.txtsagrvupcar32.Size = new System.Drawing.Size(84, 18);
            this.txtsagrvupcar32.TabIndex = 24;
            // 
            // txtsagrvupcar31
            // 
            this.txtsagrvupcar31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtsagrvupcar31.ForeColor = System.Drawing.Color.Blue;
            this.txtsagrvupcar31.Location = new System.Drawing.Point(195, 146);
            this.txtsagrvupcar31.Multiline = true;
            this.txtsagrvupcar31.Name = "txtsagrvupcar31";
            this.txtsagrvupcar31.Size = new System.Drawing.Size(84, 18);
            this.txtsagrvupcar31.TabIndex = 23;
            // 
            // txtrupncar33
            // 
            this.txtrupncar33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtrupncar33.ForeColor = System.Drawing.Color.Blue;
            this.txtrupncar33.Location = new System.Drawing.Point(374, 120);
            this.txtrupncar33.Multiline = true;
            this.txtrupncar33.Name = "txtrupncar33";
            this.txtrupncar33.Size = new System.Drawing.Size(94, 18);
            this.txtrupncar33.TabIndex = 22;
            // 
            // txtrupncar32
            // 
            this.txtrupncar32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtrupncar32.Location = new System.Drawing.Point(287, 119);
            this.txtrupncar32.Multiline = true;
            this.txtrupncar32.Name = "txtrupncar32";
            this.txtrupncar32.Size = new System.Drawing.Size(81, 18);
            this.txtrupncar32.TabIndex = 21;
            // 
            // txtrupncar31
            // 
            this.txtrupncar31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtrupncar31.ForeColor = System.Drawing.Color.Blue;
            this.txtrupncar31.Location = new System.Drawing.Point(197, 116);
            this.txtrupncar31.Multiline = true;
            this.txtrupncar31.Name = "txtrupncar31";
            this.txtrupncar31.Size = new System.Drawing.Size(84, 18);
            this.txtrupncar31.TabIndex = 20;
            // 
            // txtkcar33
            // 
            this.txtkcar33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtkcar33.ForeColor = System.Drawing.Color.Blue;
            this.txtkcar33.Location = new System.Drawing.Point(374, 100);
            this.txtkcar33.Multiline = true;
            this.txtkcar33.Name = "txtkcar33";
            this.txtkcar33.Size = new System.Drawing.Size(94, 18);
            this.txtkcar33.TabIndex = 19;
            // 
            // txtkcar32
            // 
            this.txtkcar32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtkcar32.ForeColor = System.Drawing.Color.Blue;
            this.txtkcar32.Location = new System.Drawing.Point(287, 100);
            this.txtkcar32.Multiline = true;
            this.txtkcar32.Name = "txtkcar32";
            this.txtkcar32.Size = new System.Drawing.Size(81, 18);
            this.txtkcar32.TabIndex = 18;
            // 
            // txtkcar31
            // 
            this.txtkcar31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtkcar31.ForeColor = System.Drawing.Color.Blue;
            this.txtkcar31.Location = new System.Drawing.Point(197, 100);
            this.txtkcar31.Multiline = true;
            this.txtkcar31.Name = "txtkcar31";
            this.txtkcar31.Size = new System.Drawing.Size(84, 18);
            this.txtkcar31.TabIndex = 17;
            // 
            // txtrvppcar33
            // 
            this.txtrvppcar33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtrvppcar33.ForeColor = System.Drawing.Color.Blue;
            this.txtrvppcar33.Location = new System.Drawing.Point(374, 85);
            this.txtrvppcar33.Multiline = true;
            this.txtrvppcar33.Name = "txtrvppcar33";
            this.txtrvppcar33.Size = new System.Drawing.Size(94, 16);
            this.txtrvppcar33.TabIndex = 16;
            // 
            // txtrvppcar32
            // 
            this.txtrvppcar32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtrvppcar32.ForeColor = System.Drawing.Color.Blue;
            this.txtrvppcar32.Location = new System.Drawing.Point(287, 83);
            this.txtrvppcar32.Multiline = true;
            this.txtrvppcar32.Name = "txtrvppcar32";
            this.txtrvppcar32.Size = new System.Drawing.Size(81, 16);
            this.txtrvppcar32.TabIndex = 15;
            // 
            // txtrvppcar31
            // 
            this.txtrvppcar31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtrvppcar31.ForeColor = System.Drawing.Color.Blue;
            this.txtrvppcar31.Location = new System.Drawing.Point(197, 83);
            this.txtrvppcar31.Multiline = true;
            this.txtrvppcar31.Name = "txtrvppcar31";
            this.txtrvppcar31.Size = new System.Drawing.Size(84, 16);
            this.txtrvppcar31.TabIndex = 14;
            // 
            // txtlivccar33
            // 
            this.txtlivccar33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtlivccar33.ForeColor = System.Drawing.Color.Blue;
            this.txtlivccar33.Location = new System.Drawing.Point(374, 67);
            this.txtlivccar33.Multiline = true;
            this.txtlivccar33.Name = "txtlivccar33";
            this.txtlivccar33.Size = new System.Drawing.Size(94, 18);
            this.txtlivccar33.TabIndex = 12;
            // 
            // txtlivccar32
            // 
            this.txtlivccar32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtlivccar32.ForeColor = System.Drawing.Color.Blue;
            this.txtlivccar32.Location = new System.Drawing.Point(287, 67);
            this.txtlivccar32.Multiline = true;
            this.txtlivccar32.Name = "txtlivccar32";
            this.txtlivccar32.Size = new System.Drawing.Size(81, 18);
            this.txtlivccar32.TabIndex = 11;
            // 
            // txtlivccar31
            // 
            this.txtlivccar31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtlivccar31.ForeColor = System.Drawing.Color.Blue;
            this.txtlivccar31.Location = new System.Drawing.Point(197, 67);
            this.txtlivccar31.Multiline = true;
            this.txtlivccar31.Name = "txtlivccar31";
            this.txtlivccar31.Size = new System.Drawing.Size(84, 16);
            this.txtlivccar31.TabIndex = 10;
            // 
            // txtlivpcar33
            // 
            this.txtlivpcar33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtlivpcar33.ForeColor = System.Drawing.Color.Blue;
            this.txtlivpcar33.Location = new System.Drawing.Point(374, 52);
            this.txtlivpcar33.Multiline = true;
            this.txtlivpcar33.Name = "txtlivpcar33";
            this.txtlivpcar33.Size = new System.Drawing.Size(94, 16);
            this.txtlivpcar33.TabIndex = 8;
            // 
            // txtlivpcar32
            // 
            this.txtlivpcar32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtlivpcar32.ForeColor = System.Drawing.Color.Blue;
            this.txtlivpcar32.Location = new System.Drawing.Point(287, 52);
            this.txtlivpcar32.Multiline = true;
            this.txtlivpcar32.Name = "txtlivpcar32";
            this.txtlivpcar32.Size = new System.Drawing.Size(81, 16);
            this.txtlivpcar32.TabIndex = 7;
            // 
            // txtlivpcar31
            // 
            this.txtlivpcar31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtlivpcar31.ForeColor = System.Drawing.Color.Blue;
            this.txtlivpcar31.Location = new System.Drawing.Point(197, 50);
            this.txtlivpcar31.Multiline = true;
            this.txtlivpcar31.Name = "txtlivpcar31";
            this.txtlivpcar31.Size = new System.Drawing.Size(84, 16);
            this.txtlivpcar31.TabIndex = 6;
            // 
            // txtprunitcar33
            // 
            this.txtprunitcar33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprunitcar33.ForeColor = System.Drawing.Color.Blue;
            this.txtprunitcar33.Location = new System.Drawing.Point(374, 18);
            this.txtprunitcar33.Multiline = true;
            this.txtprunitcar33.Name = "txtprunitcar33";
            this.txtprunitcar33.ReadOnly = true;
            this.txtprunitcar33.Size = new System.Drawing.Size(93, 16);
            this.txtprunitcar33.TabIndex = 2;
            // 
            // txtprunitcar32
            // 
            this.txtprunitcar32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprunitcar32.ForeColor = System.Drawing.Color.Blue;
            this.txtprunitcar32.Location = new System.Drawing.Point(287, 16);
            this.txtprunitcar32.Multiline = true;
            this.txtprunitcar32.Name = "txtprunitcar32";
            this.txtprunitcar32.ReadOnly = true;
            this.txtprunitcar32.Size = new System.Drawing.Size(82, 16);
            this.txtprunitcar32.TabIndex = 1;
            // 
            // txtprunitcar31
            // 
            this.txtprunitcar31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprunitcar31.ForeColor = System.Drawing.Color.Blue;
            this.txtprunitcar31.Location = new System.Drawing.Point(197, 16);
            this.txtprunitcar31.Multiline = true;
            this.txtprunitcar31.Name = "txtprunitcar31";
            this.txtprunitcar31.ReadOnly = true;
            this.txtprunitcar31.Size = new System.Drawing.Size(84, 16);
            this.txtprunitcar31.TabIndex = 0;
            // 
            // Calcola3
            // 
            this.Calcola3.BackColor = System.Drawing.Color.Yellow;
            this.Calcola3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Calcola3.ForeColor = System.Drawing.Color.Blue;
            this.Calcola3.Location = new System.Drawing.Point(497, 173);
            this.Calcola3.Name = "Calcola3";
            this.Calcola3.Size = new System.Drawing.Size(90, 53);
            this.Calcola3.TabIndex = 18;
            this.Calcola3.Text = "Calcola";
            this.Calcola3.UseVisualStyleBackColor = false;
            this.Calcola3.Click += new System.EventHandler(this.Calcola3_Click);
            // 
            // Label22
            // 
            this.Label22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label22.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label22.Location = new System.Drawing.Point(3, 190);
            this.Label22.Name = "Label22";
            this.Label22.Size = new System.Drawing.Size(184, 16);
            this.Label22.TabIndex = 17;
            this.Label22.Text = "Differenziale di piano";
            // 
            // Label21
            // 
            this.Label21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label21.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label21.Location = new System.Drawing.Point(4, 69);
            this.Label21.Name = "Label21";
            this.Label21.Size = new System.Drawing.Size(184, 16);
            this.Label21.TabIndex = 16;
            this.Label21.Text = "Livello corretto";
            // 
            // Label33
            // 
            this.Label33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label33.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label33.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label33.Location = new System.Drawing.Point(493, 5);
            this.Label33.Name = "Label33";
            this.Label33.Size = new System.Drawing.Size(90, 16);
            this.Label33.TabIndex = 15;
            this.Label33.Text = "Soggetto";
            this.Label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label34
            // 
            this.Label34.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label34.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label34.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label34.Location = new System.Drawing.Point(374, 0);
            this.Label34.Name = "Label34";
            this.Label34.Size = new System.Drawing.Size(94, 16);
            this.Label34.TabIndex = 14;
            this.Label34.Text = "Comparabile 3";
            this.Label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label35
            // 
            this.Label35.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label35.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label35.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label35.Location = new System.Drawing.Point(286, 0);
            this.Label35.Name = "Label35";
            this.Label35.Size = new System.Drawing.Size(84, 16);
            this.Label35.TabIndex = 13;
            this.Label35.Text = "Comparabile 2";
            this.Label35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label36
            // 
            this.Label36.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label36.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label36.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label36.Location = new System.Drawing.Point(196, 0);
            this.Label36.Name = "Label36";
            this.Label36.Size = new System.Drawing.Size(84, 16);
            this.Label36.TabIndex = 12;
            this.Label36.Text = "Comparabile 1";
            this.Label36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label40
            // 
            this.Label40.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label40.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label40.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label40.Location = new System.Drawing.Point(3, 209);
            this.Label40.Name = "Label40";
            this.Label40.Size = new System.Drawing.Size(184, 16);
            this.Label40.TabIndex = 8;
            this.Label40.Text = "Aggiustamento di piano (LDP)";
            // 
            // Label41
            // 
            this.Label41.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label41.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label41.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label41.Location = new System.Drawing.Point(5, 172);
            this.Label41.Name = "Label41";
            this.Label41.Size = new System.Drawing.Size(184, 16);
            this.Label41.TabIndex = 7;
            this.Label41.Text = "Prezzo marginale - LDP";
            // 
            // Label42
            // 
            this.Label42.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label42.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label42.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label42.Location = new System.Drawing.Point(6, 142);
            this.Label42.Name = "Label42";
            this.Label42.Size = new System.Drawing.Size(184, 30);
            this.Label42.TabIndex = 6;
            this.Label42.Text = "saggio livello rvup - rapporto mercantile unitario";
            // 
            // Label43
            // 
            this.Label43.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label43.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label43.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label43.Location = new System.Drawing.Point(3, 120);
            this.Label43.Name = "Label43";
            this.Label43.Size = new System.Drawing.Size(184, 16);
            this.Label43.TabIndex = 5;
            this.Label43.Text = "rupn";
            // 
            // Label44
            // 
            this.Label44.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label44.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label44.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label44.Location = new System.Drawing.Point(3, 102);
            this.Label44.Name = "Label44";
            this.Label44.Size = new System.Drawing.Size(184, 16);
            this.Label44.TabIndex = 4;
            this.Label44.Text = "K";
            // 
            // Label45
            // 
            this.Label45.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label45.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label45.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label45.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label45.Location = new System.Drawing.Point(3, 85);
            this.Label45.Name = "Label45";
            this.Label45.Size = new System.Drawing.Size(184, 16);
            this.Label45.TabIndex = 3;
            this.Label45.Text = "rvpp (immobili 1-2; 2-3)";
            // 
            // Label46
            // 
            this.Label46.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label46.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label46.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label46.Location = new System.Drawing.Point(5, 50);
            this.Label46.Name = "Label46";
            this.Label46.Size = new System.Drawing.Size(182, 18);
            this.Label46.TabIndex = 2;
            this.Label46.Text = "Livello di piano";
            // 
            // Label47
            // 
            this.Label47.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label47.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label47.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label47.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label47.Location = new System.Drawing.Point(5, 16);
            this.Label47.Name = "Label47";
            this.Label47.Size = new System.Drawing.Size(184, 18);
            this.Label47.TabIndex = 1;
            this.Label47.Text = "Prezzo unitario";
            // 
            // Label48
            // 
            this.Label48.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label48.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label48.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label48.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label48.Location = new System.Drawing.Point(6, 0);
            this.Label48.Name = "Label48";
            this.Label48.Size = new System.Drawing.Size(184, 16);
            this.Label48.TabIndex = 0;
            this.Label48.Text = "Caratteristica 3 : Livello di piano";
            // 
            // txtprzcorr1
            // 
            this.txtprzcorr1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprzcorr1.ForeColor = System.Drawing.Color.Blue;
            this.txtprzcorr1.Location = new System.Drawing.Point(195, 192);
            this.txtprzcorr1.Multiline = true;
            this.txtprzcorr1.Name = "txtprzcorr1";
            this.txtprzcorr1.Size = new System.Drawing.Size(84, 19);
            this.txtprzcorr1.TabIndex = 31;
            // 
            // Label59
            // 
            this.Label59.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label59.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label59.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label59.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label59.Location = new System.Drawing.Point(6, 86);
            this.Label59.Name = "Label59";
            this.Label59.Size = new System.Drawing.Size(184, 16);
            this.Label59.TabIndex = 5;
            this.Label59.Text = "Spesa unitaria 10% prezzo unitario medio";
            // 
            // txtdiff1
            // 
            this.txtdiff1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtdiff1.ForeColor = System.Drawing.Color.Blue;
            this.txtdiff1.Location = new System.Drawing.Point(196, 148);
            this.txtdiff1.Multiline = true;
            this.txtdiff1.Name = "txtdiff1";
            this.txtdiff1.Size = new System.Drawing.Size(84, 18);
            this.txtdiff1.TabIndex = 25;
            // 
            // Panel1
            // 
            this.Panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Panel1.Controls.Add(this.Label97);
            this.Panel1.Controls.Add(this.Label85);
            this.Panel1.Controls.Add(this.Label58);
            this.Panel1.Controls.Add(this.Label54);
            this.Panel1.Controls.Add(this.btncancella1);
            this.Panel1.Controls.Add(this.txtprunitmax);
            this.Panel1.Controls.Add(this.txtprunitmin);
            this.Panel1.Controls.Add(this.Label37);
            this.Panel1.Controls.Add(this.txtprzmcorrsogg);
            this.Panel1.Controls.Add(this.txtprzmcorr3);
            this.Panel1.Controls.Add(this.txtprzmcorr2);
            this.Panel1.Controls.Add(this.txtprzmcorr1);
            this.Panel1.Controls.Add(this.txtprzcorr3);
            this.Panel1.Controls.Add(this.txtprzcorr2);
            this.Panel1.Controls.Add(this.txtprzcorr1);
            this.Panel1.Controls.Add(this.txtAgg3);
            this.Panel1.Controls.Add(this.txtAgg2);
            this.Panel1.Controls.Add(this.txtAgg1);
            this.Panel1.Controls.Add(this.txtdiff3);
            this.Panel1.Controls.Add(this.txtdiff2);
            this.Panel1.Controls.Add(this.txtdiff1);
            this.Panel1.Controls.Add(this.txtprzmarg3);
            this.Panel1.Controls.Add(this.txtprzmarg2);
            this.Panel1.Controls.Add(this.txtprzmarg1);
            this.Panel1.Controls.Add(this.txtrappos3);
            this.Panel1.Controls.Add(this.txtrappos2);
            this.Panel1.Controls.Add(this.txtrappos1);
            this.Panel1.Controls.Add(this.txtmediap3);
            this.Panel1.Controls.Add(this.txtmediap2);
            this.Panel1.Controls.Add(this.txtmediap1);
            this.Panel1.Controls.Add(this.txtprunit3arr);
            this.Panel1.Controls.Add(this.txtprunit2arr);
            this.Panel1.Controls.Add(this.txtprunit1arr);
            this.Panel1.Controls.Add(this.txtprunit3);
            this.Panel1.Controls.Add(this.txtprunit2);
            this.Panel1.Controls.Add(this.txtprunit1);
            this.Panel1.Controls.Add(this.txtsccsogg);
            this.Panel1.Controls.Add(this.txtscc3);
            this.Panel1.Controls.Add(this.txtscc2);
            this.Panel1.Controls.Add(this.txtscc1);
            this.Panel1.Controls.Add(this.txtprz3);
            this.Panel1.Controls.Add(this.txtprz2);
            this.Panel1.Controls.Add(this.txtprz1);
            this.Panel1.Controls.Add(this.Calcola1);
            this.Panel1.Controls.Add(this.Label16);
            this.Panel1.Controls.Add(this.Label15);
            this.Panel1.Controls.Add(this.Label14);
            this.Panel1.Controls.Add(this.Label13);
            this.Panel1.Controls.Add(this.Label12);
            this.Panel1.Controls.Add(this.Label11);
            this.Panel1.Controls.Add(this.Label10);
            this.Panel1.Controls.Add(this.Label9);
            this.Panel1.Controls.Add(this.Label8);
            this.Panel1.Controls.Add(this.Label7);
            this.Panel1.Controls.Add(this.Label6);
            this.Panel1.Controls.Add(this.Label5);
            this.Panel1.Controls.Add(this.Label4);
            this.Panel1.Controls.Add(this.Label3);
            this.Panel1.Controls.Add(this.Label2);
            this.Panel1.Controls.Add(this.Label1);
            this.Panel1.Location = new System.Drawing.Point(29, 0);
            this.Panel1.Name = "Panel1";
            this.Panel1.Size = new System.Drawing.Size(593, 240);
            this.Panel1.TabIndex = 22;
            // 
            // txtprzmarg3
            // 
            this.txtprzmarg3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprzmarg3.ForeColor = System.Drawing.Color.Blue;
            this.txtprzmarg3.Location = new System.Drawing.Point(377, 132);
            this.txtprzmarg3.Multiline = true;
            this.txtprzmarg3.Name = "txtprzmarg3";
            this.txtprzmarg3.Size = new System.Drawing.Size(92, 16);
            this.txtprzmarg3.TabIndex = 24;
            // 
            // txtprzmarg2
            // 
            this.txtprzmarg2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprzmarg2.ForeColor = System.Drawing.Color.Blue;
            this.txtprzmarg2.Location = new System.Drawing.Point(286, 132);
            this.txtprzmarg2.Multiline = true;
            this.txtprzmarg2.Name = "txtprzmarg2";
            this.txtprzmarg2.Size = new System.Drawing.Size(85, 16);
            this.txtprzmarg2.TabIndex = 23;
            // 
            // txtprzmarg1
            // 
            this.txtprzmarg1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprzmarg1.ForeColor = System.Drawing.Color.Blue;
            this.txtprzmarg1.Location = new System.Drawing.Point(196, 132);
            this.txtprzmarg1.Multiline = true;
            this.txtprzmarg1.Name = "txtprzmarg1";
            this.txtprzmarg1.Size = new System.Drawing.Size(84, 16);
            this.txtprzmarg1.TabIndex = 22;
            // 
            // txtrappos3
            // 
            this.txtrappos3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtrappos3.ForeColor = System.Drawing.Color.Blue;
            this.txtrappos3.Location = new System.Drawing.Point(376, 108);
            this.txtrappos3.Multiline = true;
            this.txtrappos3.Name = "txtrappos3";
            this.txtrappos3.ReadOnly = true;
            this.txtrappos3.Size = new System.Drawing.Size(93, 18);
            this.txtrappos3.TabIndex = 21;
            // 
            // txtrappos2
            // 
            this.txtrappos2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtrappos2.ForeColor = System.Drawing.Color.Blue;
            this.txtrappos2.Location = new System.Drawing.Point(286, 108);
            this.txtrappos2.Multiline = true;
            this.txtrappos2.Name = "txtrappos2";
            this.txtrappos2.ReadOnly = true;
            this.txtrappos2.Size = new System.Drawing.Size(85, 18);
            this.txtrappos2.TabIndex = 20;
            // 
            // txtrappos1
            // 
            this.txtrappos1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtrappos1.ForeColor = System.Drawing.Color.Blue;
            this.txtrappos1.Location = new System.Drawing.Point(196, 108);
            this.txtrappos1.Multiline = true;
            this.txtrappos1.Name = "txtrappos1";
            this.txtrappos1.ReadOnly = true;
            this.txtrappos1.Size = new System.Drawing.Size(84, 18);
            this.txtrappos1.TabIndex = 19;
            // 
            // txtmediap3
            // 
            this.txtmediap3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtmediap3.ForeColor = System.Drawing.Color.Blue;
            this.txtmediap3.Location = new System.Drawing.Point(376, 86);
            this.txtmediap3.Multiline = true;
            this.txtmediap3.Name = "txtmediap3";
            this.txtmediap3.ReadOnly = true;
            this.txtmediap3.Size = new System.Drawing.Size(94, 16);
            this.txtmediap3.TabIndex = 18;
            // 
            // txtmediap2
            // 
            this.txtmediap2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtmediap2.ForeColor = System.Drawing.Color.Blue;
            this.txtmediap2.Location = new System.Drawing.Point(286, 86);
            this.txtmediap2.Multiline = true;
            this.txtmediap2.Name = "txtmediap2";
            this.txtmediap2.ReadOnly = true;
            this.txtmediap2.Size = new System.Drawing.Size(85, 16);
            this.txtmediap2.TabIndex = 17;
            // 
            // txtmediap1
            // 
            this.txtmediap1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtmediap1.ForeColor = System.Drawing.Color.Blue;
            this.txtmediap1.Location = new System.Drawing.Point(196, 86);
            this.txtmediap1.Multiline = true;
            this.txtmediap1.Name = "txtmediap1";
            this.txtmediap1.ReadOnly = true;
            this.txtmediap1.Size = new System.Drawing.Size(84, 16);
            this.txtmediap1.TabIndex = 16;
            // 
            // txtprunit3arr
            // 
            this.txtprunit3arr.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprunit3arr.ForeColor = System.Drawing.Color.Blue;
            this.txtprunit3arr.Location = new System.Drawing.Point(376, 70);
            this.txtprunit3arr.Multiline = true;
            this.txtprunit3arr.Name = "txtprunit3arr";
            this.txtprunit3arr.Size = new System.Drawing.Size(94, 16);
            this.txtprunit3arr.TabIndex = 13;
            // 
            // txtprunit2arr
            // 
            this.txtprunit2arr.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprunit2arr.ForeColor = System.Drawing.Color.Blue;
            this.txtprunit2arr.Location = new System.Drawing.Point(286, 70);
            this.txtprunit2arr.Multiline = true;
            this.txtprunit2arr.Name = "txtprunit2arr";
            this.txtprunit2arr.Size = new System.Drawing.Size(85, 16);
            this.txtprunit2arr.TabIndex = 12;
            // 
            // txtprunit1arr
            // 
            this.txtprunit1arr.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprunit1arr.ForeColor = System.Drawing.Color.Blue;
            this.txtprunit1arr.Location = new System.Drawing.Point(196, 70);
            this.txtprunit1arr.Multiline = true;
            this.txtprunit1arr.Name = "txtprunit1arr";
            this.txtprunit1arr.Size = new System.Drawing.Size(84, 16);
            this.txtprunit1arr.TabIndex = 11;
            // 
            // txtprunit3
            // 
            this.txtprunit3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprunit3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.txtprunit3.Location = new System.Drawing.Point(377, 54);
            this.txtprunit3.Multiline = true;
            this.txtprunit3.Name = "txtprunit3";
            this.txtprunit3.ReadOnly = true;
            this.txtprunit3.Size = new System.Drawing.Size(93, 16);
            this.txtprunit3.TabIndex = 9;
            // 
            // txtprunit2
            // 
            this.txtprunit2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprunit2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.txtprunit2.Location = new System.Drawing.Point(286, 54);
            this.txtprunit2.Multiline = true;
            this.txtprunit2.Name = "txtprunit2";
            this.txtprunit2.ReadOnly = true;
            this.txtprunit2.Size = new System.Drawing.Size(85, 16);
            this.txtprunit2.TabIndex = 8;
            // 
            // txtprunit1
            // 
            this.txtprunit1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprunit1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.txtprunit1.Location = new System.Drawing.Point(196, 54);
            this.txtprunit1.Multiline = true;
            this.txtprunit1.Name = "txtprunit1";
            this.txtprunit1.ReadOnly = true;
            this.txtprunit1.Size = new System.Drawing.Size(84, 16);
            this.txtprunit1.TabIndex = 7;
            // 
            // txtsccsogg
            // 
            this.txtsccsogg.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtsccsogg.ForeColor = System.Drawing.Color.Blue;
            this.txtsccsogg.Location = new System.Drawing.Point(493, 38);
            this.txtsccsogg.Multiline = true;
            this.txtsccsogg.Name = "txtsccsogg";
            this.txtsccsogg.Size = new System.Drawing.Size(90, 16);
            this.txtsccsogg.TabIndex = 6;
            // 
            // txtscc3
            // 
            this.txtscc3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtscc3.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtscc3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.txtscc3.Location = new System.Drawing.Point(377, 37);
            this.txtscc3.Multiline = true;
            this.txtscc3.Name = "txtscc3";
            this.txtscc3.Size = new System.Drawing.Size(93, 16);
            this.txtscc3.TabIndex = 5;
            // 
            // txtscc2
            // 
            this.txtscc2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtscc2.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtscc2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.txtscc2.Location = new System.Drawing.Point(286, 38);
            this.txtscc2.Multiline = true;
            this.txtscc2.Name = "txtscc2";
            this.txtscc2.Size = new System.Drawing.Size(85, 16);
            this.txtscc2.TabIndex = 4;
            // 
            // txtscc1
            // 
            this.txtscc1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtscc1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtscc1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.txtscc1.Location = new System.Drawing.Point(196, 38);
            this.txtscc1.Multiline = true;
            this.txtscc1.Name = "txtscc1";
            this.txtscc1.Size = new System.Drawing.Size(84, 16);
            this.txtscc1.TabIndex = 3;
            // 
            // txtprz3
            // 
            this.txtprz3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprz3.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtprz3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.txtprz3.Location = new System.Drawing.Point(377, 21);
            this.txtprz3.Multiline = true;
            this.txtprz3.Name = "txtprz3";
            this.txtprz3.Size = new System.Drawing.Size(93, 17);
            this.txtprz3.TabIndex = 2;
            // 
            // txtprz2
            // 
            this.txtprz2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprz2.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtprz2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.txtprz2.Location = new System.Drawing.Point(286, 21);
            this.txtprz2.Multiline = true;
            this.txtprz2.Name = "txtprz2";
            this.txtprz2.Size = new System.Drawing.Size(85, 17);
            this.txtprz2.TabIndex = 1;
            // 
            // txtprz1
            // 
            this.txtprz1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprz1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtprz1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.txtprz1.Location = new System.Drawing.Point(196, 21);
            this.txtprz1.Multiline = true;
            this.txtprz1.Name = "txtprz1";
            this.txtprz1.Size = new System.Drawing.Size(84, 17);
            this.txtprz1.TabIndex = 0;
            // 
            // Calcola1
            // 
            this.Calcola1.BackColor = System.Drawing.Color.Yellow;
            this.Calcola1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Calcola1.ForeColor = System.Drawing.Color.Blue;
            this.Calcola1.Location = new System.Drawing.Point(493, 126);
            this.Calcola1.Name = "Calcola1";
            this.Calcola1.Size = new System.Drawing.Size(90, 52);
            this.Calcola1.TabIndex = 16;
            this.Calcola1.Text = "Calcola";
            this.Calcola1.UseVisualStyleBackColor = false;
            this.Calcola1.Click += new System.EventHandler(this.Calcola1_Click);
            // 
            // Label16
            // 
            this.Label16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label16.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label16.Location = new System.Drawing.Point(493, 4);
            this.Label16.Name = "Label16";
            this.Label16.Size = new System.Drawing.Size(90, 16);
            this.Label16.TabIndex = 15;
            this.Label16.Text = "Soggetto";
            this.Label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label15
            // 
            this.Label15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label15.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label15.Location = new System.Drawing.Point(376, 5);
            this.Label15.Name = "Label15";
            this.Label15.Size = new System.Drawing.Size(95, 16);
            this.Label15.TabIndex = 14;
            this.Label15.Text = "Comparabile 3";
            this.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label14
            // 
            this.Label14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label14.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label14.Location = new System.Drawing.Point(286, 6);
            this.Label14.Name = "Label14";
            this.Label14.Size = new System.Drawing.Size(85, 16);
            this.Label14.TabIndex = 13;
            this.Label14.Text = "Comparabile 2";
            this.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label13
            // 
            this.Label13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label13.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label13.Location = new System.Drawing.Point(195, 7);
            this.Label13.Name = "Label13";
            this.Label13.Size = new System.Drawing.Size(84, 16);
            this.Label13.TabIndex = 12;
            this.Label13.Text = "Comparabile 1";
            this.Label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label12
            // 
            this.Label12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label12.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label12.Location = new System.Drawing.Point(6, 215);
            this.Label12.Name = "Label12";
            this.Label12.Size = new System.Drawing.Size(184, 16);
            this.Label12.TabIndex = 11;
            this.Label12.Text = "Calcola media prezzi corretti";
            // 
            // Label11
            // 
            this.Label11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label11.Location = new System.Drawing.Point(6, 184);
            this.Label11.Name = "Label11";
            this.Label11.Size = new System.Drawing.Size(184, 27);
            this.Label11.TabIndex = 10;
            this.Label11.Text = "Prezzo corretto";
            // 
            // Label10
            // 
            this.Label10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label10.Location = new System.Drawing.Point(6, 164);
            this.Label10.Name = "Label10";
            this.Label10.Size = new System.Drawing.Size(184, 16);
            this.Label10.TabIndex = 9;
            this.Label10.Text = "Aggiustamento (SPC)";
            // 
            // Label9
            // 
            this.Label9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label9.Location = new System.Drawing.Point(6, 148);
            this.Label9.Name = "Label9";
            this.Label9.Size = new System.Drawing.Size(184, 16);
            this.Label9.TabIndex = 8;
            this.Label9.Text = "Differenziali";
            // 
            // Label8
            // 
            this.Label8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label8.Location = new System.Drawing.Point(6, 132);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(184, 16);
            this.Label8.TabIndex = 7;
            this.Label8.Text = "Calcolo prezzo marginale";
            // 
            // Label7
            // 
            this.Label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label7.Location = new System.Drawing.Point(6, 102);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(184, 30);
            this.Label7.TabIndex = 6;
            this.Label7.Text = "Rapp. Posizione (prezzo unitario min/prezzo unitario max)";
            // 
            // Label6
            // 
            this.Label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label6.Location = new System.Drawing.Point(6, 86);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(184, 16);
            this.Label6.TabIndex = 5;
            this.Label6.Text = "Media prezzi unitari";
            // 
            // Label5
            // 
            this.Label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label5.Location = new System.Drawing.Point(6, 70);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(184, 16);
            this.Label5.TabIndex = 4;
            this.Label5.Text = "Prezzo unitario arrotondato";
            // 
            // Label4
            // 
            this.Label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label4.Location = new System.Drawing.Point(6, 54);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(184, 16);
            this.Label4.TabIndex = 3;
            this.Label4.Text = "Prezzo unitario";
            // 
            // Label3
            // 
            this.Label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label3.Location = new System.Drawing.Point(6, 38);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(184, 16);
            this.Label3.TabIndex = 2;
            this.Label3.Text = "Superficie commerciale - SCC";
            // 
            // Label2
            // 
            this.Label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label2.Location = new System.Drawing.Point(6, 22);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(184, 16);
            this.Label2.TabIndex = 1;
            this.Label2.Text = "Prezzo - PRZ";
            // 
            // Label1
            // 
            this.Label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label1.Location = new System.Drawing.Point(6, 6);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(184, 16);
            this.Label1.TabIndex = 0;
            this.Label1.Text = "Caratteristica 1: superfici";
            // 
            // txtprzcar41
            // 
            this.txtprzcar41.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtprzcar41.ForeColor = System.Drawing.Color.Blue;
            this.txtprzcar41.Location = new System.Drawing.Point(196, 36);
            this.txtprzcar41.Multiline = true;
            this.txtprzcar41.Name = "txtprzcar41";
            this.txtprzcar41.Size = new System.Drawing.Size(84, 17);
            this.txtprzcar41.TabIndex = 0;
            // 
            // Calcola4
            // 
            this.Calcola4.BackColor = System.Drawing.Color.Yellow;
            this.Calcola4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Calcola4.ForeColor = System.Drawing.Color.Blue;
            this.Calcola4.Location = new System.Drawing.Point(508, 171);
            this.Calcola4.Name = "Calcola4";
            this.Calcola4.Size = new System.Drawing.Size(75, 53);
            this.Calcola4.TabIndex = 16;
            this.Calcola4.Text = "Calcola";
            this.Calcola4.UseVisualStyleBackColor = false;
            this.Calcola4.Click += new System.EventHandler(this.Calcola4_Click);
            // 
            // Label49
            // 
            this.Label49.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label49.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label49.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label49.Location = new System.Drawing.Point(488, 4);
            this.Label49.Name = "Label49";
            this.Label49.Size = new System.Drawing.Size(95, 16);
            this.Label49.TabIndex = 15;
            this.Label49.Text = "Soggetto";
            this.Label49.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label50
            // 
            this.Label50.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label50.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label50.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label50.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label50.Location = new System.Drawing.Point(387, 5);
            this.Label50.Name = "Label50";
            this.Label50.Size = new System.Drawing.Size(95, 16);
            this.Label50.TabIndex = 14;
            this.Label50.Text = "Comparabile 3";
            this.Label50.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label51
            // 
            this.Label51.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label51.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label51.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label51.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label51.Location = new System.Drawing.Point(286, 5);
            this.Label51.Name = "Label51";
            this.Label51.Size = new System.Drawing.Size(95, 16);
            this.Label51.TabIndex = 13;
            this.Label51.Text = "Comparabile 2";
            this.Label51.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Panel4
            // 
            this.Panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Panel4.Controls.Add(this.Label88);
            this.Panel4.Controls.Add(this.Label79);
            this.Panel4.Controls.Add(this.btncancella4);
            this.Panel4.Controls.Add(this.txtman4sogg);
            this.Panel4.Controls.Add(this.txtscc4sogg);
            this.Panel4.Controls.Add(this.txtagg43);
            this.Panel4.Controls.Add(this.txtprzmarg43);
            this.Panel4.Controls.Add(this.txtdiffcar43);
            this.Panel4.Controls.Add(this.txtpass43);
            this.Panel4.Controls.Add(this.txtspunit10car43);
            this.Panel4.Controls.Add(this.txtman43);
            this.Panel4.Controls.Add(this.txtscc43);
            this.Panel4.Controls.Add(this.txtprzcar43);
            this.Panel4.Controls.Add(this.txtagg42);
            this.Panel4.Controls.Add(this.txtprzmarg42);
            this.Panel4.Controls.Add(this.txtdiffcar42);
            this.Panel4.Controls.Add(this.txtpass42);
            this.Panel4.Controls.Add(this.txtspunit10car42);
            this.Panel4.Controls.Add(this.txtman42);
            this.Panel4.Controls.Add(this.txtscc42);
            this.Panel4.Controls.Add(this.txtprzcar42);
            this.Panel4.Controls.Add(this.txtagg41);
            this.Panel4.Controls.Add(this.txtprzmarg41);
            this.Panel4.Controls.Add(this.txtdiffcar41);
            this.Panel4.Controls.Add(this.txtpass41);
            this.Panel4.Controls.Add(this.txtspunit10car41);
            this.Panel4.Controls.Add(this.txtman41);
            this.Panel4.Controls.Add(this.txtscc41);
            this.Panel4.Controls.Add(this.txtprzcar41);
            this.Panel4.Controls.Add(this.Calcola4);
            this.Panel4.Controls.Add(this.Label49);
            this.Panel4.Controls.Add(this.Label50);
            this.Panel4.Controls.Add(this.Label51);
            this.Panel4.Controls.Add(this.Label52);
            this.Panel4.Controls.Add(this.Label53);
            this.Panel4.Controls.Add(this.Label55);
            this.Panel4.Controls.Add(this.Label56);
            this.Panel4.Controls.Add(this.Label57);
            this.Panel4.Controls.Add(this.Label59);
            this.Panel4.Controls.Add(this.Label60);
            this.Panel4.Controls.Add(this.Label61);
            this.Panel4.Controls.Add(this.Label62);
            this.Panel4.Controls.Add(this.Label64);
            this.Panel4.Location = new System.Drawing.Point(634, 245);
            this.Panel4.Name = "Panel4";
            this.Panel4.Size = new System.Drawing.Size(593, 232);
            this.Panel4.TabIndex = 24;
            // 
            // Label52
            // 
            this.Label52.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label52.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label52.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label52.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label52.Location = new System.Drawing.Point(196, 6);
            this.Label52.Name = "Label52";
            this.Label52.Size = new System.Drawing.Size(84, 16);
            this.Label52.TabIndex = 12;
            this.Label52.Text = "Comparabile 1";
            this.Label52.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Label53
            // 
            this.Label53.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label53.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label53.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label53.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label53.Location = new System.Drawing.Point(6, 164);
            this.Label53.Name = "Label53";
            this.Label53.Size = new System.Drawing.Size(184, 32);
            this.Label53.TabIndex = 11;
            this.Label53.Text = "Aggiustamento manutenzione (SMT)";
            // 
            // Label55
            // 
            this.Label55.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label55.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label55.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label55.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label55.Location = new System.Drawing.Point(6, 134);
            this.Label55.Name = "Label55";
            this.Label55.Size = new System.Drawing.Size(184, 30);
            this.Label55.TabIndex = 9;
            this.Label55.Text = "Prezzo marginale - manutenzione gen. SMT";
            // 
            // Label56
            // 
            this.Label56.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label56.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label56.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label56.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label56.Location = new System.Drawing.Point(6, 118);
            this.Label56.Name = "Label56";
            this.Label56.Size = new System.Drawing.Size(184, 16);
            this.Label56.TabIndex = 8;
            this.Label56.Text = "Differenziale";
            // 
            // Label57
            // 
            this.Label57.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label57.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label57.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label57.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label57.Location = new System.Drawing.Point(6, 102);
            this.Label57.Name = "Label57";
            this.Label57.Size = new System.Drawing.Size(184, 16);
            this.Label57.TabIndex = 7;
            this.Label57.Text = "Passaggio di scala €/mq.";
            // 
            // Label60
            // 
            this.Label60.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label60.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label60.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label60.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label60.Location = new System.Drawing.Point(6, 70);
            this.Label60.Name = "Label60";
            this.Label60.Size = new System.Drawing.Size(184, 16);
            this.Label60.TabIndex = 4;
            this.Label60.Text = "Manutenzione";
            // 
            // Label61
            // 
            this.Label61.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label61.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label61.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label61.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label61.Location = new System.Drawing.Point(6, 38);
            this.Label61.Name = "Label61";
            this.Label61.Size = new System.Drawing.Size(184, 16);
            this.Label61.TabIndex = 3;
            this.Label61.Text = "Prezzo";
            // 
            // Label62
            // 
            this.Label62.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label62.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label62.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label62.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label62.Location = new System.Drawing.Point(6, 54);
            this.Label62.Name = "Label62";
            this.Label62.Size = new System.Drawing.Size(184, 16);
            this.Label62.TabIndex = 2;
            this.Label62.Text = "Superficie commerciale - SCC";
            // 
            // Label64
            // 
            this.Label64.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Label64.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Label64.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label64.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Label64.Location = new System.Drawing.Point(6, 6);
            this.Label64.Name = "Label64";
            this.Label64.Size = new System.Drawing.Size(184, 32);
            this.Label64.TabIndex = 0;
            this.Label64.Text = "Caratteristica 4 : Manutenzione generale";
            this.Label64.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1370, 749);
            this.Controls.Add(this.Panel5);
            this.Controls.Add(this.Panel2);
            this.Controls.Add(this.Panel6);
            this.Controls.Add(this.Panel3);
            this.Controls.Add(this.Panel1);
            this.Controls.Add(this.Panel4);
            this.Name = "Form1";
            this.Text = "Metodo comparativo prospetto A- C#";
            this.Panel5.ResumeLayout(false);
            this.Panel5.PerformLayout();
            this.Panel2.ResumeLayout(false);
            this.Panel2.PerformLayout();
            this.Panel6.ResumeLayout(false);
            this.Panel6.PerformLayout();
            this.Panel3.ResumeLayout(false);
            this.Panel3.PerformLayout();
            this.Panel1.ResumeLayout(false);
            this.Panel1.PerformLayout();
            this.Panel4.ResumeLayout(false);
            this.Panel4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.Label Label88;
        internal System.Windows.Forms.Label Label79;
        internal System.Windows.Forms.Button btncancella4;
        internal System.Windows.Forms.TextBox txtman4sogg;
        internal System.Windows.Forms.TextBox txtscc4sogg;
        internal System.Windows.Forms.TextBox txtagg43;
        internal System.Windows.Forms.TextBox txtprzmarg43;
        internal System.Windows.Forms.TextBox txtdiffcar43;
        internal System.Windows.Forms.TextBox txtpass43;
        internal System.Windows.Forms.TextBox txtspunit10car43;
        internal System.Windows.Forms.TextBox txtman43;
        internal System.Windows.Forms.TextBox txtscc43;
        internal System.Windows.Forms.TextBox txtprzcar43;
        internal System.Windows.Forms.Label Label89;
        internal System.Windows.Forms.Label Label81;
        internal System.Windows.Forms.Button btncancella5;
        internal System.Windows.Forms.TextBox txtruvpcar5sogg;
        internal System.Windows.Forms.TextBox txtpuntcar5sogg;
        internal System.Windows.Forms.TextBox txtorientcar5sogg;
        internal System.Windows.Forms.TextBox txtagg53;
        internal System.Windows.Forms.TextBox txtdiff53;
        internal System.Windows.Forms.TextBox txtorient53;
        internal System.Windows.Forms.TextBox txtruvpcar53;
        internal System.Windows.Forms.TextBox txtrupncar53;
        internal System.Windows.Forms.TextBox txtKcar53;
        internal System.Windows.Forms.Panel Panel5;
        internal System.Windows.Forms.TextBox txtrvpocar53;
        internal System.Windows.Forms.TextBox txtpuntcar53;
        internal System.Windows.Forms.TextBox txtorientcar53;
        internal System.Windows.Forms.TextBox txtprunitcar53;
        internal System.Windows.Forms.TextBox txtagg52;
        internal System.Windows.Forms.TextBox txtdiff52;
        internal System.Windows.Forms.TextBox txtorient52;
        internal System.Windows.Forms.TextBox txtruvpcar52;
        internal System.Windows.Forms.TextBox txtrupncar52;
        internal System.Windows.Forms.TextBox txtKcar52;
        internal System.Windows.Forms.TextBox txtrvpocar52;
        internal System.Windows.Forms.TextBox txtpuntcar52;
        internal System.Windows.Forms.TextBox txtorientcar52;
        internal System.Windows.Forms.TextBox txtprunitcar52;
        internal System.Windows.Forms.TextBox txtagg51;
        internal System.Windows.Forms.TextBox txtdiff51;
        internal System.Windows.Forms.TextBox txtorient51;
        internal System.Windows.Forms.TextBox txtruvpcar51;
        internal System.Windows.Forms.TextBox txtrupncar51;
        internal System.Windows.Forms.TextBox txtKcar51;
        internal System.Windows.Forms.TextBox txtrvpocar51;
        internal System.Windows.Forms.TextBox txtpuntcar51;
        internal System.Windows.Forms.TextBox txtorientcar51;
        internal System.Windows.Forms.TextBox txtprunitcar51;
        internal System.Windows.Forms.Button Calcola5;
        internal System.Windows.Forms.Label Label23;
        internal System.Windows.Forms.Label Label65;
        internal System.Windows.Forms.Label Label66;
        internal System.Windows.Forms.Label Label67;
        internal System.Windows.Forms.Label Label68;
        internal System.Windows.Forms.Label Label69;
        internal System.Windows.Forms.Label Label70;
        internal System.Windows.Forms.Label Label71;
        internal System.Windows.Forms.Label Label72;
        internal System.Windows.Forms.Label Label73;
        internal System.Windows.Forms.Label Label74;
        internal System.Windows.Forms.Label Label75;
        internal System.Windows.Forms.Label Label76;
        internal System.Windows.Forms.Label Label77;
        internal System.Windows.Forms.Label Label80;
        internal System.Windows.Forms.TextBox txtagg42;
        internal System.Windows.Forms.TextBox txtprzmarg42;
        internal System.Windows.Forms.TextBox txtdiffcar42;
        internal System.Windows.Forms.TextBox txtpass42;
        internal System.Windows.Forms.TextBox txtspunit10car42;
        internal System.Windows.Forms.TextBox txtman41;
        internal System.Windows.Forms.TextBox txtspunit10car41;
        internal System.Windows.Forms.TextBox txtman42;
        internal System.Windows.Forms.TextBox txtpass41;
        internal System.Windows.Forms.TextBox txtprzcar42;
        internal System.Windows.Forms.TextBox txtagg41;
        internal System.Windows.Forms.TextBox txtprzmarg41;
        internal System.Windows.Forms.TextBox txtdiffcar41;
        internal System.Windows.Forms.TextBox txtscc42;
        internal System.Windows.Forms.Panel Panel2;
        internal System.Windows.Forms.Label Label86;
        internal System.Windows.Forms.Label Label63;
        internal System.Windows.Forms.Button btncancella2;
        internal System.Windows.Forms.Label Label28;
        internal System.Windows.Forms.TextBox txtsaggio;
        internal System.Windows.Forms.TextBox txtrendita2;
        internal System.Windows.Forms.TextBox txtrendita1;
        internal System.Windows.Forms.Button btnsaggio;
        internal System.Windows.Forms.TextBox txtsaggcarsogg;
        internal System.Windows.Forms.TextBox txtdatacarsogg;
        internal System.Windows.Forms.TextBox txtscccarsogg;
        internal System.Windows.Forms.TextBox txtagg23;
        internal System.Windows.Forms.TextBox txtdiff23;
        internal System.Windows.Forms.TextBox txtprzmarg23;
        internal System.Windows.Forms.TextBox txtagg22;
        internal System.Windows.Forms.TextBox txtdiff22;
        internal System.Windows.Forms.TextBox txtprzmarg22;
        internal System.Windows.Forms.TextBox txtagg21;
        internal System.Windows.Forms.TextBox txtdiff21;
        internal System.Windows.Forms.TextBox txtprzmarg21;
        internal System.Windows.Forms.TextBox txtsaggcar23;
        internal System.Windows.Forms.TextBox txtsaggcar22;
        internal System.Windows.Forms.TextBox txtsaggcar21;
        internal System.Windows.Forms.TextBox txtdatacar23;
        internal System.Windows.Forms.TextBox txtdatacar22;
        internal System.Windows.Forms.TextBox txtdatacar21;
        internal System.Windows.Forms.TextBox txtscccar23;
        internal System.Windows.Forms.TextBox txtscccar22;
        internal System.Windows.Forms.TextBox txtscccar21;
        internal System.Windows.Forms.TextBox txtprzcar23;
        internal System.Windows.Forms.TextBox txtprzcar22;
        internal System.Windows.Forms.TextBox txtprzcar21;
        internal System.Windows.Forms.Label Label38;
        internal System.Windows.Forms.Button Calcola2;
        internal System.Windows.Forms.Label Label17;
        internal System.Windows.Forms.Label Label18;
        internal System.Windows.Forms.Label Label19;
        internal System.Windows.Forms.Label Label20;
        internal System.Windows.Forms.Label Label25;
        internal System.Windows.Forms.Label Label26;
        internal System.Windows.Forms.Label Label27;
        internal System.Windows.Forms.Label Label29;
        internal System.Windows.Forms.Label Label30;
        internal System.Windows.Forms.Label Label31;
        internal System.Windows.Forms.Label Label32;
        internal System.Windows.Forms.Button btncancella6;
        internal System.Windows.Forms.Button btncalcola6;
        internal System.Windows.Forms.TextBox txtoprriass3;
        internal System.Windows.Forms.TextBox txtmanutriass3;
        internal System.Windows.Forms.TextBox txtprzldpriass3;
        internal System.Windows.Forms.TextBox txtprzdatariass3;
        internal System.Windows.Forms.TextBox txtsccriass3;
        internal System.Windows.Forms.TextBox txtprzriass3;
        internal System.Windows.Forms.TextBox txtoprriass2;
        internal System.Windows.Forms.TextBox txtmanutriass2;
        internal System.Windows.Forms.TextBox txtprzldpriass2;
        internal System.Windows.Forms.TextBox txtprzdatariass2;
        internal System.Windows.Forms.TextBox txtsccriass2;
        internal System.Windows.Forms.TextBox txtprzriass2;
        internal System.Windows.Forms.TextBox txtoprriass1;
        internal System.Windows.Forms.TextBox txtmanutriass1;
        internal System.Windows.Forms.TextBox txtprzldpriass1;
        internal System.Windows.Forms.Panel Panel6;
        internal System.Windows.Forms.TextBox txtprzdatariass1;
        internal System.Windows.Forms.TextBox txtsccriass1;
        internal System.Windows.Forms.TextBox txtprzriass1;
        internal System.Windows.Forms.Label Label24;
        internal System.Windows.Forms.Label Label82;
        internal System.Windows.Forms.Label Label83;
        internal System.Windows.Forms.Label Label84;
        internal System.Windows.Forms.Label Label90;
        internal System.Windows.Forms.Label Label91;
        internal System.Windows.Forms.Label Label92;
        internal System.Windows.Forms.Label Label93;
        internal System.Windows.Forms.Label Label94;
        internal System.Windows.Forms.Label Label95;
        internal System.Windows.Forms.Label Label96;
        internal System.Windows.Forms.TextBox txtscc41;
        internal System.Windows.Forms.Label Label97;
        internal System.Windows.Forms.Label Label85;
        internal System.Windows.Forms.Label Label58;
        internal System.Windows.Forms.Label Label54;
        internal System.Windows.Forms.Button btncancella1;
        internal System.Windows.Forms.TextBox txtprunitmax;
        internal System.Windows.Forms.TextBox txtprunitmin;
        internal System.Windows.Forms.Label Label37;
        internal System.Windows.Forms.TextBox txtprzmcorrsogg;
        internal System.Windows.Forms.TextBox txtprzmcorr3;
        internal System.Windows.Forms.TextBox txtprzmcorr2;
        internal System.Windows.Forms.TextBox txtprzmcorr1;
        internal System.Windows.Forms.TextBox txtprzcorr3;
        internal System.Windows.Forms.TextBox txtprzcorr2;
        internal System.Windows.Forms.TextBox txtAgg3;
        internal System.Windows.Forms.TextBox txtAgg2;
        internal System.Windows.Forms.TextBox txtAgg1;
        internal System.Windows.Forms.TextBox txtdiff3;
        internal System.Windows.Forms.TextBox txtdiff2;
        internal System.Windows.Forms.TextBox txtpiano3;
        internal System.Windows.Forms.Panel Panel3;
        internal System.Windows.Forms.Label Label87;
        internal System.Windows.Forms.Label Label78;
        internal System.Windows.Forms.Button btncancella3;
        internal System.Windows.Forms.TextBox txtpiano2;
        internal System.Windows.Forms.TextBox txtpiano1;
        internal System.Windows.Forms.TextBox txtprunitcar3arr3;
        internal System.Windows.Forms.TextBox txtprunitcar3arr2;
        internal System.Windows.Forms.TextBox txtprunitcar3arr1;
        internal System.Windows.Forms.Label Label39;
        internal System.Windows.Forms.TextBox txtsagrvupcar3sogg;
        internal System.Windows.Forms.TextBox txtlivccar3sogg;
        internal System.Windows.Forms.TextBox txtlivpcar3sogg;
        internal System.Windows.Forms.TextBox txtldpdiffcar33;
        internal System.Windows.Forms.TextBox txtldpdiffcar32;
        internal System.Windows.Forms.TextBox txtldpdiffcar31;
        internal System.Windows.Forms.TextBox txtprzmargldpcar33;
        internal System.Windows.Forms.TextBox txtprzmargldpcar32;
        internal System.Windows.Forms.TextBox txtprzmargldpcar31;
        internal System.Windows.Forms.TextBox txtsagrvupcar33;
        internal System.Windows.Forms.TextBox txtsagrvupcar32;
        internal System.Windows.Forms.TextBox txtsagrvupcar31;
        internal System.Windows.Forms.TextBox txtrupncar33;
        internal System.Windows.Forms.TextBox txtrupncar32;
        internal System.Windows.Forms.TextBox txtrupncar31;
        internal System.Windows.Forms.TextBox txtkcar33;
        internal System.Windows.Forms.TextBox txtkcar32;
        internal System.Windows.Forms.TextBox txtkcar31;
        internal System.Windows.Forms.TextBox txtrvppcar33;
        internal System.Windows.Forms.TextBox txtrvppcar32;
        internal System.Windows.Forms.TextBox txtrvppcar31;
        internal System.Windows.Forms.TextBox txtlivccar33;
        internal System.Windows.Forms.TextBox txtlivccar32;
        internal System.Windows.Forms.TextBox txtlivccar31;
        internal System.Windows.Forms.TextBox txtlivpcar33;
        internal System.Windows.Forms.TextBox txtlivpcar32;
        internal System.Windows.Forms.TextBox txtlivpcar31;
        internal System.Windows.Forms.TextBox txtprunitcar33;
        internal System.Windows.Forms.TextBox txtprunitcar32;
        internal System.Windows.Forms.TextBox txtprunitcar31;
        internal System.Windows.Forms.Button Calcola3;
        internal System.Windows.Forms.Label Label22;
        internal System.Windows.Forms.Label Label21;
        internal System.Windows.Forms.Label Label33;
        internal System.Windows.Forms.Label Label34;
        internal System.Windows.Forms.Label Label35;
        internal System.Windows.Forms.Label Label36;
        internal System.Windows.Forms.Label Label40;
        internal System.Windows.Forms.Label Label41;
        internal System.Windows.Forms.Label Label42;
        internal System.Windows.Forms.Label Label43;
        internal System.Windows.Forms.Label Label44;
        internal System.Windows.Forms.Label Label45;
        internal System.Windows.Forms.Label Label46;
        internal System.Windows.Forms.Label Label47;
        internal System.Windows.Forms.Label Label48;
        internal System.Windows.Forms.TextBox txtprzcorr1;
        internal System.Windows.Forms.Label Label59;
        internal System.Windows.Forms.TextBox txtdiff1;
        internal System.Windows.Forms.Panel Panel1;
        internal System.Windows.Forms.TextBox txtprzmarg3;
        internal System.Windows.Forms.TextBox txtprzmarg2;
        internal System.Windows.Forms.TextBox txtprzmarg1;
        internal System.Windows.Forms.TextBox txtrappos3;
        internal System.Windows.Forms.TextBox txtrappos2;
        internal System.Windows.Forms.TextBox txtrappos1;
        internal System.Windows.Forms.TextBox txtmediap3;
        internal System.Windows.Forms.TextBox txtmediap2;
        internal System.Windows.Forms.TextBox txtmediap1;
        internal System.Windows.Forms.TextBox txtprunit3arr;
        internal System.Windows.Forms.TextBox txtprunit2arr;
        internal System.Windows.Forms.TextBox txtprunit1arr;
        internal System.Windows.Forms.TextBox txtprunit3;
        internal System.Windows.Forms.TextBox txtprunit2;
        internal System.Windows.Forms.TextBox txtprunit1;
        internal System.Windows.Forms.TextBox txtsccsogg;
        internal System.Windows.Forms.TextBox txtscc3;
        internal System.Windows.Forms.TextBox txtscc2;
        internal System.Windows.Forms.TextBox txtscc1;
        internal System.Windows.Forms.TextBox txtprz3;
        internal System.Windows.Forms.TextBox txtprz2;
        internal System.Windows.Forms.TextBox txtprz1;
        internal System.Windows.Forms.Button Calcola1;
        internal System.Windows.Forms.Label Label16;
        internal System.Windows.Forms.Label Label15;
        internal System.Windows.Forms.Label Label14;
        internal System.Windows.Forms.Label Label13;
        internal System.Windows.Forms.Label Label12;
        internal System.Windows.Forms.Label Label11;
        internal System.Windows.Forms.Label Label10;
        internal System.Windows.Forms.Label Label9;
        internal System.Windows.Forms.Label Label8;
        internal System.Windows.Forms.Label Label7;
        internal System.Windows.Forms.Label Label6;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.TextBox txtprzcar41;
        internal System.Windows.Forms.Button Calcola4;
        internal System.Windows.Forms.Label Label49;
        internal System.Windows.Forms.Label Label50;
        internal System.Windows.Forms.Label Label51;
        internal System.Windows.Forms.Panel Panel4;
        internal System.Windows.Forms.Label Label52;
        internal System.Windows.Forms.Label Label53;
        internal System.Windows.Forms.Label Label55;
        internal System.Windows.Forms.Label Label56;
        internal System.Windows.Forms.Label Label57;
        internal System.Windows.Forms.Label Label60;
        internal System.Windows.Forms.Label Label61;
        internal System.Windows.Forms.Label Label62;
        internal System.Windows.Forms.Label Label64;
    }
}

